import { system, world } from "@minecraft/server";

const DEFAULT_FOV = 70;
const ZOOM_FOV = 30;
const HITBOX_MAX_DISTANCE = 8;
const HITBOX_UPDATE_TICKS = 5;
const EDGE_STEPS = [0, 1 / 3, 2 / 3, 1];
const playerSettings = new Map();

function getSettings(player) {
    let settings = playerSettings.get(player.id);
    if (!settings) {
        settings = {
            zoomEnabled: false,
            hitboxesEnabled: false,
            hitboxErrorReported: false,
        };
        playerSettings.set(player.id, settings);
    }
    return settings;
}

function printHelp(player) {
    player.sendMessage("Visual QoL: !zoom toggles zoom; !hitboxes toggles the visible target outline.");
}

function drawTargetOutline(player, target) {
    const bounds = target.getAABB();
    const center = bounds.center;
    const extent = bounds.extent;
    const corners = [
        { x: center.x - extent.x, y: center.y - extent.y, z: center.z - extent.z },
        { x: center.x + extent.x, y: center.y - extent.y, z: center.z - extent.z },
        { x: center.x - extent.x, y: center.y + extent.y, z: center.z - extent.z },
        { x: center.x + extent.x, y: center.y + extent.y, z: center.z - extent.z },
        { x: center.x - extent.x, y: center.y - extent.y, z: center.z + extent.z },
        { x: center.x + extent.x, y: center.y - extent.y, z: center.z + extent.z },
        { x: center.x - extent.x, y: center.y + extent.y, z: center.z + extent.z },
        { x: center.x + extent.x, y: center.y + extent.y, z: center.z + extent.z },
    ];
    const edges = [
        [0, 1], [0, 2], [0, 4], [1, 3], [1, 5], [2, 3],
        [2, 6], [3, 7], [4, 5], [4, 6], [5, 7], [6, 7],
    ];
    const points = new Map();

    for (const [startIndex, endIndex] of edges) {
        const start = corners[startIndex];
        const end = corners[endIndex];
        for (const step of EDGE_STEPS) {
            const point = {
                x: start.x + (end.x - start.x) * step,
                y: start.y + (end.y - start.y) * step,
                z: start.z + (end.z - start.z) * step,
            };
            const key = `${point.x.toFixed(2)}:${point.y.toFixed(2)}:${point.z.toFixed(2)}`;
            points.set(key, point);
        }
    }

    const dimension = player.dimension;
    for (const point of points.values()) {
        dimension.spawnParticle("minecraft:endrod", point);
    }
}

world.beforeEvents.chatSend.subscribe((event) => {
    const command = event.message.trim().toLowerCase();
    if (command !== "!qol" && command !== "!zoom" && command !== "!hitboxes") return;

    event.cancel = true;
    const player = event.sender;
    system.run(() => {
        const settings = getSettings(player);
        try {
            if (command === "!zoom") {
                settings.zoomEnabled = !settings.zoomEnabled;
                player.camera.setFov({ fov: settings.zoomEnabled ? ZOOM_FOV : DEFAULT_FOV });
                player.sendMessage(`Zoom ${settings.zoomEnabled ? "on" : "off"}.`);
            } else if (command === "!hitboxes") {
                settings.hitboxesEnabled = !settings.hitboxesEnabled;
                settings.hitboxErrorReported = false;
                player.sendMessage(`Target outline ${settings.hitboxesEnabled ? "on" : "off"}.`);
            } else {
                printHelp(player);
            }
        } catch (error) {
            player.sendMessage(`Visual QoL command failed: ${String(error)}. Check the Minecraft content log.`);
        }
    });
});

world.afterEvents.playerLeave.subscribe((event) => {
    playerSettings.delete(event.playerId);
});

system.runInterval(() => {
    for (const player of world.getPlayers()) {
        const settings = playerSettings.get(player.id);
        if (!settings?.hitboxesEnabled) continue;

        try {
            const hits = player.getEntitiesFromViewDirection({
                maxDistance: HITBOX_MAX_DISTANCE,
                ignoreBlockCollision: false,
            });
            const target = hits[0]?.entity;
            if (target) drawTargetOutline(player, target);
            settings.hitboxErrorReported = false;
        } catch (error) {
            if (!settings.hitboxErrorReported) {
                player.sendMessage(`Hitbox outline failed: ${String(error)}. Check the Minecraft content log.`);
                settings.hitboxErrorReported = true;
            }
        }
    }
}, HITBOX_UPDATE_TICKS);
