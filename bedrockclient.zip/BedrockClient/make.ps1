#Requires -Version 5.1
<#
  BedrockClient - one-shot generator + builder + injector.
  Usage:  powershell -ExecutionPolicy Bypass -File Make.ps1
  Switches:
    -SkipSources   don't overwrite src/* (use when you're editing Config.hpp)
    -BuildOnly     build but don't inject
    -Clean         wipe build/ and vendor/ first
#>
param(
    [switch]$SkipSources,
    [switch]$BuildOnly,
    [switch]$Clean
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root = $PSScriptRoot
if (-not $Root) { $Root = (Get-Location).Path }

$isAdmin = ([Security.Principal.WindowsPrincipal]::new(
    [Security.Principal.WindowsIdentity]::GetCurrent()
)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

function Say($m) { Write-Host "  $m" }
function Head($m) { Write-Host "`n=== $m ===" -ForegroundColor Cyan }

function Write-File([string]$rel, [string]$content) {
    $path = Join-Path $Root $rel
    $dir  = Split-Path $path -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Set-Content -LiteralPath $path -Value $content -Encoding UTF8
    Say "wrote $rel"
}

Head "0. environment"

if ($Clean) {
    foreach ($d in 'build', 'vendor') {
        $p = Join-Path $Root $d
        if (Test-Path $p) { Remove-Item $p -Recurse -Force; Say "removed $d" }
    }
}
if (-not $isAdmin) {
    Write-Host "  ! not running as Administrator - injection may fail with error 5" -ForegroundColor Yellow
}

# ---------------------------------------------------------------- locate VS --
function Find-VsPath {
    $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (-not (Test-Path $vswhere)) { return $null }
    $p = &$vswhere -latest -products * `
         -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
         -property installationPath 2>$null
    if ($p -and (Test-Path $p)) { return $p }
    return $null
}

function Find-CMake {
    $vs = Find-VsPath
    if ($vs) {
        $c = Join-Path $vs 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
        if (Test-Path $c) { return $c }
    }
    $g = Get-Command cmake -ErrorAction SilentlyContinue
    if ($g) { return $g.Source }
    return $null
}

$vsPath = Find-VsPath
$cmake = Find-CMake

if (-not $vsPath) {
    Write-Host "  Visual Studio C++ build tools not found." -ForegroundColor Yellow
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        $a = Read-Host "  Install VS 2022 Build Tools now? (~3.5 GB) [y/N]"
        if ($a -match '^[Yy]') {
            Head "installing VS 2022 Build Tools"
            winget install --id Microsoft.VisualStudio.2022.BuildTools --override `
                "--quiet --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
            $vsPath = Find-VsPath
            $cmake  = Find-CMake
        }
    }
    if (-not $vsPath) {
        Write-Host "  Install manually: https://visualstudio.microsoft.com/downloads/ -> Build Tools" -ForegroundColor Red
        exit 1
    }
}
if (-not $cmake) {
    Write-Host "  cmake.exe not found. Reinstall VS with 'C++ CMake tools for Windows'." -ForegroundColor Red
    exit 1
}
Say "compiler : $vsPath"
Say "cmake    : $cmake"

# -------------------------------------------------------------- dependencies --
Head "1. dependencies"

function Fetch-Dep([string]$name, [string]$url, [string]$folder) {
    $dest = Join-Path $Root "vendor\$folder"
    $hasSource = (Test-Path (Join-Path $dest 'CMakeLists.txt')) -or
                 (Test-Path (Join-Path $dest 'imgui.cpp')) -or
                 (Test-Path (Join-Path $dest 'include\MinHook.h')) -or
                 (Test-Path (Join-Path $dest 'src\hook.c'))
    if ($hasSource) {
        Say "$name already present"
        return
    }
    $tmp = Join-Path $Root "vendor\_tmp_$folder"
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    New-Item -ItemType Directory -Path $tmp -Force | Out-Null

    $zip = Join-Path $tmp 'dep.zip'
    Say "downloading $name ..."
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing

    $ex = Join-Path $tmp 'x'
    Expand-Archive -LiteralPath $zip -DestinationPath $ex -Force

    $inner = Get-ChildItem $ex -Directory |
        Where-Object {
            (Test-Path (Join-Path $_.FullName 'CMakeLists.txt')) -or
            (Test-Path (Join-Path $_.FullName 'imgui.cpp')) -or
            (Test-Path (Join-Path $_.FullName 'include\MinHook.h')) -or
            (Test-Path (Join-Path $_.FullName 'src\hook.c'))
        } |
        Select-Object -First 1
    if (-not $inner) {
        $inner = Get-ChildItem $ex -Recurse -Directory |
            Where-Object {
                (Test-Path (Join-Path $_.FullName 'CMakeLists.txt')) -or
                (Test-Path (Join-Path $_.FullName 'imgui.cpp')) -or
                (Test-Path (Join-Path $_.FullName 'include\MinHook.h')) -or
                (Test-Path (Join-Path $_.FullName 'src\hook.c'))
            } |
            Select-Object -First 1
    }
    if (-not $inner) { throw "unexpected archive layout for $name" }
    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
    New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null
    Move-Item -LiteralPath $inner.FullName -Destination $dest -Force
    Remove-Item $tmp -Recurse -Force
    Say "$name -> vendor\$folder"
}

Fetch-Dep 'ImGui'   'https://github.com/ocornut/imgui/archive/refs/tags/v1.90.9.zip' 'imgui'
Fetch-Dep 'MinHook' 'https://github.com/TsudaKageyu/minhook/archive/refs/tags/v1.3.3.zip' 'minhook'

# -------------------------------------------------------------------- source --
Head "2. source files"

if (-not $SkipSources) {

Write-File 'CMakeLists.txt' @'
cmake_minimum_required(VERSION 3.20)
project(BedrockClient C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded")

if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()

set(VENDOR ${CMAKE_SOURCE_DIR}/vendor)

add_library(imgui_lib STATIC
  ${VENDOR}/imgui/imgui.cpp
  ${VENDOR}/imgui/imgui_draw.cpp
  ${VENDOR}/imgui/imgui_tables.cpp
  ${VENDOR}/imgui/imgui_widgets.cpp
  ${VENDOR}/imgui/backends/imgui_impl_dx12.cpp
  ${VENDOR}/imgui/backends/imgui_impl_dx11.cpp
  ${VENDOR}/imgui/backends/imgui_impl_win32.cpp)
target_include_directories(imgui_lib PUBLIC
  ${VENDOR}/imgui ${VENDOR}/imgui/backends)

add_library(minhook STATIC
  ${VENDOR}/minhook/src/buffer.c
  ${VENDOR}/minhook/src/hook.c
  ${VENDOR}/minhook/src/trampoline.c
  ${VENDOR}/minhook/src/hde/hde32.c
  ${VENDOR}/minhook/src/hde/hde64.c)
target_include_directories(minhook PUBLIC ${VENDOR}/minhook/include)

add_library(BedrockClient SHARED
  src/dllmain.cpp
  src/Memory.cpp
  src/SDK.cpp
  src/Hooks.cpp
  src/GUI.cpp
  src/Module.cpp
  src/modules/Modules.cpp)

target_include_directories(BedrockClient PRIVATE src)
target_link_libraries(BedrockClient PRIVATE
  imgui_lib minhook d3d11 d3d12 dxgi dxguid dwmapi)
set_target_properties(BedrockClient PROPERTIES PREFIX "")

add_executable(Injector injector/Injector.cpp)
target_link_options(Injector PRIVATE /ENTRY:wmainCRTStartup)
target_link_libraries(Injector PRIVATE user32)
'@

Write-File 'src/Memory.hpp' @'
#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <cstdint>
#include <cstring>
#include <optional>
#include <string>
#include <vector>

namespace mem {

inline bool IsReadable(uintptr_t addr, size_t size) {
    uintptr_t a = addr;
    while (a < addr + size) {
        MEMORY_BASIC_INFORMATION mbi{};
        if (!VirtualQuery(reinterpret_cast<LPCVOID>(a), &mbi, sizeof(mbi))) return false;
        if (mbi.State != MEM_COMMIT) return false;
        if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return false;
        a = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
    }
    return true;
}

inline bool IsValid(uintptr_t addr, size_t size = 8) {
    return addr > 0x10000 && addr < 0x7FFFFFFFFFFFULL && IsReadable(addr, size);
}

template <typename T> inline T Read(uintptr_t addr) {
    if (!IsReadable(addr, sizeof(T))) return T{};
    return *reinterpret_cast<T*>(addr);
}

template <typename T> inline bool Write(uintptr_t addr, const T& v) {
    if (!IsReadable(addr, sizeof(T))) return false;
    *reinterpret_cast<T*>(addr) = v;
    return true;
}

template <typename T> inline bool WriteProtected(uintptr_t addr, const T& v) {
    DWORD old{};
    if (!VirtualProtect(reinterpret_cast<void*>(addr), sizeof(T),
                        PAGE_EXECUTE_READWRITE, &old)) return false;
    *reinterpret_cast<T*>(addr) = v;
    VirtualProtect(reinterpret_cast<void*>(addr), sizeof(T), old, &old);
    return true;
}

std::optional<MODULEENTRY32W> GetModuleEntry(const wchar_t* name);
uintptr_t GetModuleBase(const wchar_t* name);
size_t    GetModuleSize(const wchar_t* name);
uintptr_t GetMainModuleBase();
size_t    GetMainModuleSize();
std::vector<int> ParsePattern(const char* pattern);
uintptr_t ScanRange(uintptr_t start, size_t size, const std::vector<int>& pat);
uintptr_t ScanInModule(const wchar_t* module, const char* pattern);
uintptr_t ScanMainModule(const char* pattern);
uintptr_t ResolveRip(uintptr_t instrAddr, int dispOffset, int instrLength);
std::string ReadStdString(uintptr_t addr);

} // namespace mem
'@

Write-File 'src/Config.hpp' @'
#pragma once
#define NOMINMAX
#include <windows.h>
#include <cstdint>

// Every magic number lives here. Verify with the "Dump pointers" button,
// then edit this file and re-run Make.ps1 -SkipSources.

namespace cfg {

inline const char* Sig_ClientInstance =
    "48 8B 0D ? ? ? ? 48 8B 01 48 85 C0 74 ? 48 8B 88";
inline const char* Sig_GetFov[] = {
    "56 57 53 48 83 EC ? 44 0F 29 44 24 ? 0F 29 7C 24 ? 0F 29 74 24 ? 44 89 C3 0F 28 F1",
    "4C 8B DC 53 48 83 EC ? 0F 29 74 24",
    "? ? ? ? ? ? ? 48 89 ? ? 57 48 81 EC ? ? ? ? 0F 29 ? ? 0F 29 ? ? 44 0F ? ? ? 44 0F ? ? ? 48 8B ? ? ? ? ? 48 33 ? 48 89 ? ? ? 41 0F",
    "48 8B ? 48 89 ? ? 48 89 ? ? 57 48 81 EC ? ? ? ? 0F 29 ? ? 0F 29 ? ? 44 0F ? ? ? 44 0F ? ? ? 48 8B ? ? ? ? ? 48 33 ? 48 89 ? ? ? 41 0F"
};

constexpr uintptr_t CI_LocalPlayer   = 0x0A8;
constexpr uintptr_t CI_Level         = 0x150;
constexpr uintptr_t CI_GameMode      = 0x160;
constexpr uintptr_t CI_MinecraftGame = 0x0D8;

constexpr uintptr_t MG_Options = 0x0F0;
constexpr uintptr_t OPT_Gamma  = 0x1E0;

constexpr uintptr_t LV_EntityList = 0x2B0;

constexpr uintptr_t AC_Position     = 0x4A0;
constexpr uintptr_t AC_Velocity     = 0x3F0;
constexpr uintptr_t AC_OnGround     = 0x1F8;
constexpr uintptr_t AC_Sprinting    = 0x2C8;
constexpr uintptr_t AC_FallDistance = 0x3D0;
constexpr uintptr_t AC_NameTag      = 0x2F0;
constexpr uintptr_t AC_TypeId       = 0x1C0;
constexpr uintptr_t AC_Dead         = 0x1D0;
constexpr uintptr_t AC_Yaw          = 0x2A0;
constexpr uintptr_t AC_Pitch        = 0x2A4;

constexpr int VT_GameMode_attack       = 0x0C;
constexpr int VT_GameMode_destroyBlock = 0x0A;

constexpr float FlySpeed      = 1.4f;
constexpr float SpeedValue    = 1.6f;
constexpr float AuraRange     = 4.2f;
constexpr float AuraCPS       = 9.0f;
constexpr float NukerRange    = 4.0f;
constexpr int   NukerPerFrame = 6;
constexpr int   PlayerTypeId  = 319;

constexpr int KEY_MENU   = 'M';
constexpr int KEY_UNLOAD = VK_DELETE;

} // namespace cfg
'@

Write-File 'src/SDK.hpp' @'
#pragma once
#include <cstdint>
#include <string>
#include <vector>

struct Vec2 { float x, y; };

struct Vec3 {
    float x, y, z;
    Vec3 operator+(const Vec3& o) const { return {x + o.x, y + o.y, z + o.z}; }
    Vec3 operator-(const Vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    Vec3 operator*(float s) const { return {x * s, y * s, z * s}; }
    float length() const;
    Vec3 normalized() const;
};

struct AABB { Vec3 min, max; };

namespace sdk {

using Actor  = uintptr_t;
using Player = uintptr_t;
using Level  = uintptr_t;

uintptr_t GetClientInstance();
Player    GetLocalPlayer();
Level     GetLevel();
uintptr_t GetGameMode();

Vec3  GetPosition(Actor a);
void  SetPosition(Actor a, const Vec3& p);
Vec3  GetVelocity(Actor a);
void  SetVelocity(Actor a, const Vec3& v);
bool  IsOnGround(Actor a);
void  SetOnGround(Actor a, bool v);
bool  IsSprinting(Actor a);
void  SetSprinting(Actor a, bool v);
bool  IsDead(Actor a);
std::string GetNameTag(Actor a);
AABB  GetAABB(Actor a, Vec3* position = nullptr);
bool  IsLocalPlayer(Actor a);

std::vector<Actor> GetEntities(size_t maxCount = 8192);
Vec2  GetRotation(Player p);
Vec3  GetEyePosition(Player p);

void Attack(Actor target);
void DestroyBlock(const Vec3& blockCenter);

void Dump();

} // namespace sdk
'@

Write-File 'src/SDK.cpp' @'
#include "SDK.hpp"
#include "Memory.hpp"
#include "Config.hpp"
#include <cmath>
#include <cstdio>
#include <mutex>

float Vec3::length() const { return std::sqrt(x * x + y * y + z * z); }

Vec3 Vec3::normalized() const {
    float l = length();
    return l > 1e-6f ? Vec3{x / l, y / l, z / l} : Vec3{};
}

namespace sdk {

uintptr_t GetClientInstance() {
    static uintptr_t addr = 0;
    static std::once_flag scanOnce;
    std::call_once(scanOnce, []() {
        uintptr_t hit = mem::ScanMainModule(cfg::Sig_ClientInstance);
        if (hit) addr = mem::ResolveRip(hit, 3, 7);
    });
    return addr;
}

Player GetLocalPlayer() {
    uintptr_t ci = GetClientInstance();
    if (!mem::IsValid(ci)) return 0;
    Player p = mem::Read<Player>(ci + cfg::CI_LocalPlayer);
    return mem::IsValid(p, 0x100) ? p : 0;
}

Level GetLevel() {
    uintptr_t ci = GetClientInstance();
    if (!mem::IsValid(ci)) return 0;
    Level l = mem::Read<Level>(ci + cfg::CI_Level);
    return mem::IsValid(l, 0x100) ? l : 0;
}

uintptr_t GetGameMode() {
    uintptr_t ci = GetClientInstance();
    if (!mem::IsValid(ci)) return 0;
    uintptr_t gm = mem::Read<uintptr_t>(ci + cfg::CI_GameMode);
    return mem::IsValid(gm, 0x100) ? gm : 0;
}

Vec3 GetPosition(Actor a) { return mem::Read<Vec3>(a + cfg::AC_Position); }
void SetPosition(Actor a, const Vec3& p) { mem::Write(a + cfg::AC_Position, p); }
Vec3 GetVelocity(Actor a) { return mem::Read<Vec3>(a + cfg::AC_Velocity); }
void SetVelocity(Actor a, const Vec3& v) { mem::Write(a + cfg::AC_Velocity, v); }
bool IsOnGround(Actor a) { return mem::Read<bool>(a + cfg::AC_OnGround); }
void SetOnGround(Actor a, bool v) { mem::Write(a + cfg::AC_OnGround, v); }
bool IsSprinting(Actor a) { return mem::Read<bool>(a + cfg::AC_Sprinting); }
void SetSprinting(Actor a, bool v) { mem::Write(a + cfg::AC_Sprinting, v); }
bool IsDead(Actor a) { return mem::Read<bool>(a + cfg::AC_Dead); }
std::string GetNameTag(Actor a) { return mem::ReadStdString(a + cfg::AC_NameTag); }
bool IsLocalPlayer(Actor a) { return a == GetLocalPlayer(); }

AABB GetAABB(Actor a, Vec3* position) {
    Vec3 p = GetPosition(a);
    if (position) *position = p;
    return {{p.x - 0.3f, p.y,        p.z - 0.3f},
            {p.x + 0.3f, p.y + 1.8f, p.z + 0.3f}};
}

std::vector<Actor> GetEntities(size_t maxCount) {
    std::vector<Actor> out;
    Level lv = GetLevel();
    if (!lv) return out;

    auto* begin = mem::Read<Actor*>(lv + cfg::LV_EntityList);
    auto* end   = mem::Read<Actor*>(lv + cfg::LV_EntityList + sizeof(void*));
    if (!begin || !end || end < begin) return out;

    size_t count = static_cast<size_t>(end - begin);
    if (count > 8192) return out;
    if (count > maxCount) count = maxCount;
    if (!mem::IsValid(reinterpret_cast<uintptr_t>(begin), count * sizeof(void*)))
        return out;

    out.reserve(count);
    for (size_t i = 0; i < count; ++i) {
        Actor a = begin[i];
        if (mem::IsValid(a, 0x400)) out.push_back(a);
    }
    return out;
}

Vec2 GetRotation(Player p) {
    return {mem::Read<float>(p + cfg::AC_Yaw), mem::Read<float>(p + cfg::AC_Pitch)};
}

Vec3 GetEyePosition(Player p) {
    Vec3 pos = GetPosition(p);
    pos.y += 1.62f;
    return pos;
}

void Attack(Actor target) {
    uintptr_t gm = GetGameMode();
    if (!gm) return;
    auto vtbl = *reinterpret_cast<void***>(gm);
    using Fn = void(__fastcall*)(void*, void*);
    reinterpret_cast<Fn>(vtbl[cfg::VT_GameMode_attack])(
        reinterpret_cast<void*>(gm), reinterpret_cast<void*>(target));
}

void DestroyBlock(const Vec3& c) {
    uintptr_t gm = GetGameMode();
    if (!gm) return;
    auto vtbl = *reinterpret_cast<void***>(gm);
    using Fn = bool(__fastcall*)(void*, const Vec3*);
    reinterpret_cast<Fn>(vtbl[cfg::VT_GameMode_destroyBlock])(
        reinterpret_cast<void*>(gm), &c);
}

void Dump() {
    printf("\n===== BedrockClient dump =====\n");
    uintptr_t hit = mem::ScanMainModule(cfg::Sig_ClientInstance);
    printf("main module    : 0x%llX (%zu bytes)\n",
           static_cast<unsigned long long>(mem::GetMainModuleBase()),
           mem::GetMainModuleSize());
    printf("sig hit        : 0x%llX\n", (unsigned long long)hit);
    if (!hit)
        printf("!! client-instance signature did not match this game build\n");
    printf("clientInstance : 0x%llX\n", (unsigned long long)GetClientInstance());
    printf("localPlayer    : 0x%llX\n", (unsigned long long)GetLocalPlayer());
    printf("level          : 0x%llX\n", (unsigned long long)GetLevel());
    printf("gameMode       : 0x%llX\n", (unsigned long long)GetGameMode());

    Player lp = GetLocalPlayer();
    if (lp) {
        Vec3 p = GetPosition(lp);
        Vec3 v = GetVelocity(lp);
        printf("player pos     : %.2f %.2f %.2f\n", p.x, p.y, p.z);
        printf("player vel     : %.3f %.3f %.3f\n", v.x, v.y, v.z);
        printf("onGround       : %d\n", (int)IsOnGround(lp));
        printf("nameTag        : '%s'\n", GetNameTag(lp).c_str());
    } else {
        printf("!! localPlayer null - check CI_LocalPlayer\n");
    }

    auto ents = GetEntities();
    printf("entity count   : %zu\n", ents.size());
    for (size_t i = 0; i < ents.size() && i < 8; ++i) {
        Vec3 p = GetPosition(ents[i]);
        printf("  [%zu] 0x%llX type=%d pos=%.1f %.1f %.1f '%s'\n",
               i, (unsigned long long)ents[i],
               mem::Read<int>(ents[i] + cfg::AC_TypeId),
               p.x, p.y, p.z, GetNameTag(ents[i]).c_str());
    }
    printf("==============================\n\n");
}

} // namespace sdk
'@

Write-File 'src/Module.hpp' @'
#pragma once
#include <vector>

struct Module {
    const char* name;
    const char* desc;
    int  key = 0;
    bool enabled = false;

    Module(const char* n, const char* d, int k = 0) : name(n), desc(d), key(k) {}
    virtual ~Module() = default;

    void Toggle() { enabled = !enabled; }
    virtual void Tick(float dt) {}
    virtual void Render() {}
    virtual void DrawSettings() {}
};

class ModuleManager {
public:
    void Add(Module* m) { mods_.push_back(m); }
    void Tick(float dt);
    void Render();
    void HandleKey(int vk);
    std::vector<Module*>& All() { return mods_; }
    float accent[3] = {0.35f, 0.75f, 1.0f};
private:
    std::vector<Module*> mods_;
};

ModuleManager& Mods();
'@

Write-File 'src/Module.cpp' @'
#include "Module.hpp"

ModuleManager& Mods() {
    static ModuleManager m;
    return m;
}

void ModuleManager::Tick(float dt) {
    for (auto* m : mods_) if (m->enabled) m->Tick(dt);
}

void ModuleManager::Render() {
    for (auto* m : mods_) if (m->enabled) m->Render();
}

void ModuleManager::HandleKey(int vk) {
    for (auto* m : mods_) if (m->key && m->key == vk) m->Toggle();
}
'@

Write-File 'src/GUI.hpp' @'
#pragma once
#include <windows.h>
#include <d3d11.h>
#include <d3d12.h>

namespace gui {
bool Init(HWND hwnd, ID3D11Device* device, ID3D11DeviceContext* context);
bool InitD3D12(HWND hwnd, ID3D12Device* device, int framesInFlight,
               DXGI_FORMAT renderTargetFormat, ID3D12DescriptorHeap* srvHeap,
               D3D12_CPU_DESCRIPTOR_HANDLE fontCpuHandle,
               D3D12_GPU_DESCRIPTOR_HANDLE fontGpuHandle);
void Shutdown();
void NewFrame();
void RenderD3D12(ID3D12GraphicsCommandList* commandList);
void Render();
bool IsMenuOpen();
void ToggleMenu();
} // namespace gui
'@

Write-File 'src/GUI.cpp' @'
#include "GUI.hpp"
#include "Config.hpp"
#include "Module.hpp"
#include "SDK.hpp"

#include <imgui.h>
#include <imgui_impl_dx12.h>
#include <imgui_impl_dx11.h>
#include <imgui_impl_win32.h>
#include <cstdio>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace gui {

static bool s_menuOpen = false;
static bool s_ready    = false;
static bool s_initFailureReported = false;
static bool s_dx12 = false;

static void CreateContext() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr;

    ImGui::StyleColorsDark();
    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding = 6.0f;
    st.FrameRounding  = 4.0f;
    st.FramePadding   = ImVec2(6, 4);
}

bool Init(HWND hwnd, ID3D11Device* device, ID3D11DeviceContext* context) {
    CreateContext();
    if (!ImGui_ImplWin32_Init(hwnd)) {
        if (!s_initFailureReported) {
            printf("[BedrockClient] ImGui Win32 backend initialization failed.\n");
            s_initFailureReported = true;
        }
        ImGui::DestroyContext();
        return false;
    }
    if (!ImGui_ImplDX11_Init(device, context)) {
        if (!s_initFailureReported) {
            printf("[BedrockClient] ImGui Direct3D 11 backend initialization failed.\n");
            s_initFailureReported = true;
        }
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        return false;
    }
    s_dx12 = false;
    s_ready = true;
    return true;
}

bool InitD3D12(HWND hwnd, ID3D12Device* device, int framesInFlight,
               DXGI_FORMAT renderTargetFormat, ID3D12DescriptorHeap* srvHeap,
               D3D12_CPU_DESCRIPTOR_HANDLE fontCpuHandle,
               D3D12_GPU_DESCRIPTOR_HANDLE fontGpuHandle) {
    CreateContext();
    if (!ImGui_ImplWin32_Init(hwnd)) {
        if (!s_initFailureReported) {
            printf("[BedrockClient] ImGui Win32 backend initialization failed.\n");
            s_initFailureReported = true;
        }
        ImGui::DestroyContext();
        return false;
    }
    if (!ImGui_ImplDX12_Init(device, framesInFlight, renderTargetFormat, srvHeap,
                             fontCpuHandle, fontGpuHandle)) {
        if (!s_initFailureReported) {
            printf("[BedrockClient] ImGui Direct3D 12 backend initialization failed.\n");
            s_initFailureReported = true;
        }
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        return false;
    }
    s_dx12 = true;
    s_ready = true;
    return true;
}

void Shutdown() {
    if (!s_ready) return;
    if (s_dx12) ImGui_ImplDX12_Shutdown();
    else ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    s_ready = false;
}

void NewFrame() {
    if (s_dx12) ImGui_ImplDX12_NewFrame();
    else ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
}

void RenderD3D12(ID3D12GraphicsCommandList* commandList) {
    ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), commandList);
}

bool IsMenuOpen() { return s_menuOpen; }
void ToggleMenu() { s_menuOpen = !s_menuOpen; }

static void RenderWatermark() {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const char* text = "BedrockClient";
    ImVec2 sz = ImGui::CalcTextSize(text);
    dl->AddRectFilled({9, 9}, {19 + sz.x, 19 + sz.y}, IM_COL32(15, 15, 20, 190), 4.0f);
    dl->AddText({14, 14}, IM_COL32(255, 255, 255, 230), text);
    char fps[64];
    snprintf(fps, sizeof(fps), "%.0f fps", ImGui::GetIO().Framerate);
    dl->AddText({14, 14 + sz.y + 4}, IM_COL32(150, 200, 255, 220), fps);
}

static void RenderArrayList() {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    ImGuiIO& io = ImGui::GetIO();
    float y = 14.0f;
    for (auto* m : Mods().All()) {
        if (!m->enabled) continue;
        ImVec2 sz = ImGui::CalcTextSize(m->name);
        float x = io.DisplaySize.x - sz.x - 14.0f;
        dl->AddRectFilled({x - 6, y - 3}, {x + sz.x + 6, y + sz.y + 3},
                          IM_COL32(15, 15, 20, 170), 3.0f);
        dl->AddText({x + 1, y + 1}, IM_COL32(0, 0, 0, 200), m->name);
        dl->AddText({x, y}, ImGui::ColorConvertFloat4ToU32(
                     {Mods().accent[0], Mods().accent[1], Mods().accent[2], 1.0f}), m->name);
        y += sz.y + 6.0f;
    }
}

static void RenderMenu() {
    if (!s_menuOpen) return;
    ImGui::SetNextWindowSize({440, 420}, ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos({60, 60}, ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("BedrockClient", &s_menuOpen)) { ImGui::End(); return; }

    ImGui::TextColored({Mods().accent[0], Mods().accent[1], Mods().accent[2], 1.0f},
                       "BedrockClient   |   %.0f fps", ImGui::GetIO().Framerate);
    ImGui::Separator();
    ImGui::Spacing();

    for (auto* m : Mods().All()) {
        ImGui::Checkbox(m->name, &m->enabled);
        if (ImGui::IsItemHovered() && m->desc) ImGui::SetTooltip("%s", m->desc);
        if (m->key) {
            ImGui::SameLine(ImGui::GetWindowWidth() - 60);
            ImGui::TextDisabled("[%c]", (char)m->key);
        }
        if (m->enabled) {
            ImGui::Indent(18.0f);
            m->DrawSettings();
            ImGui::Unindent(18.0f);
        }
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::ColorEdit3("Accent", Mods().accent, ImGuiColorEditFlags_NoInputs);
    ImGui::SameLine();
    if (ImGui::Button("Dump pointers")) sdk::Dump();
    ImGui::End();
}

void Render() {
    RenderWatermark();
    RenderArrayList();
    RenderMenu();
}

} // namespace gui
'@

Write-File 'src/Hooks.hpp' @'
#pragma once
#include <windows.h>
#include <atomic>

namespace hooks {
HWND FindGameWindow();
bool Install();
void Uninstall();
float GetZoomMagnification();
void SetZoomMagnification(float value);
float GetZoomScrollStep();
void SetZoomScrollStep(float value);
bool IsZoomAvailable();
unsigned long long GetFovHookCallCount();
float GetLastZoomFov();
extern HWND g_hwnd;
extern std::atomic_bool g_presentSeen;
extern std::atomic_bool g_imguiReady;
} // namespace hooks
'@

Write-File 'src/Hooks.cpp' @'
#include "Hooks.hpp"
#include "Config.hpp"
#include "GUI.hpp"
#include "Memory.hpp"
#include "Module.hpp"

#include <imgui.h>
#include <imgui_impl_dx11.h>
#include <imgui_impl_win32.h>
#include <MinHook.h>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <thread>
#include <d3d11.h>
#include <d3d12.h>
#include <dxgi1_4.h>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace hooks {

static ID3D11Device*           g_device  = nullptr;
static ID3D11DeviceContext*    g_context = nullptr;
static ID3D11RenderTargetView* g_rtv     = nullptr;
static IDXGISwapChain*         g_swap    = nullptr;

using Present_t       = HRESULT(WINAPI*)(IDXGISwapChain*, UINT, UINT);
using ResizeBuffers_t = HRESULT(WINAPI*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
using WndProc_t       = LRESULT(CALLBACK*)(HWND, UINT, WPARAM, LPARAM);
using GetFov_t        = float(__fastcall*)(void*, float, void*, void*);
using ExecuteCommandLists_t =
    void(STDMETHODCALLTYPE*)(ID3D12CommandQueue*, UINT, ID3D12CommandList* const*);

static Present_t       oPresent       = nullptr;
static ResizeBuffers_t oResizeBuffers = nullptr;
static WndProc_t       oWndProc       = nullptr;
static GetFov_t        oGetFov        = nullptr;
static ExecuteCommandLists_t oExecuteCommandLists = nullptr;
static std::atomic_flag g_imguiInitializing = ATOMIC_FLAG_INIT;
static std::atomic_bool g_initFailureReported{false};
static std::atomic_bool g_deviceFailureReported{false};
static std::atomic_bool g_d3d12QueueHookInstalled{false};
static std::atomic_bool g_d3d12QueueWaitReported{false};
static std::atomic_bool g_fovHookAvailable{false};
static std::atomic_bool g_zoomActive{false};
static std::atomic<float> g_zoomMagnification{2.0f};
static std::atomic<float> g_zoomScrollStep{0.5f};
static std::atomic<unsigned long long> g_fovHookCallCount{0};
static std::atomic<float> g_lastZoomFov{0.0f};
static std::atomic<unsigned int> g_activeHookCalls{0};
static std::atomic_bool g_shuttingDown{false};

struct HookCallGuard {
    HookCallGuard() {
        g_activeHookCalls.fetch_add(1, std::memory_order_acq_rel);
    }
    ~HookCallGuard() {
        g_activeHookCalls.fetch_sub(1, std::memory_order_acq_rel);
    }
};

static constexpr UINT kMaxBackBuffers = 8;
struct D3D12Frame {
    ID3D12CommandAllocator* allocator = nullptr;
    UINT64 fenceValue = 0;
};

static ID3D12Device* g_device12 = nullptr;
static std::atomic<ID3D12CommandQueue*> g_queue12{nullptr};
static ID3D12DescriptorHeap* g_rtvHeap12 = nullptr;
static ID3D12DescriptorHeap* g_srvHeap12 = nullptr;
static ID3D12GraphicsCommandList* g_commandList12 = nullptr;
static ID3D12Fence* g_fence12 = nullptr;
static HANDLE g_fenceEvent12 = nullptr;
static UINT64 g_nextFenceValue12 = 0;
static UINT g_rtvDescriptorSize12 = 0;
static UINT g_bufferCount12 = 0;
static UINT g_frameCursor12 = 0;
static D3D12Frame g_frames12[kMaxBackBuffers]{};
static ID3D12Resource* g_backBuffers12[kMaxBackBuffers]{};
static DXGI_FORMAT g_renderTargetFormat12 = DXGI_FORMAT_UNKNOWN;
static std::atomic_bool g_usingD3D12{false};

HWND g_hwnd       = nullptr;
std::atomic_bool g_presentSeen{false};
std::atomic_bool g_imguiReady{false};
static auto g_last = std::chrono::steady_clock::now();
static bool g_keyDown[256]{};

static void SyncZoomActive();
static bool ZoomEnabled();

static void PollHotkeys() {
    HWND foreground = GetForegroundWindow();
    DWORD foregroundPid = 0;
    if (foreground) GetWindowThreadProcessId(foreground, &foregroundPid);
    bool focused = foregroundPid == GetCurrentProcessId() && foreground != GetConsoleWindow();
    auto pollKey = [focused](int vk) {
        if (vk <= 0 || vk >= 256) return;
        bool down = (GetAsyncKeyState(vk) & 0x8000) != 0;
        if (down && !g_keyDown[vk] && focused) {
            if (vk == cfg::KEY_MENU) gui::ToggleMenu();
            else                     Mods().HandleKey(vk);
        }
        g_keyDown[vk] = down;
    };
    pollKey(cfg::KEY_MENU);
    for (auto* module : Mods().All())
        if (module->key != cfg::KEY_MENU) pollKey(module->key);
    SyncZoomActive();
}

static void SyncZoomActive() {
    bool enabled = false;
    for (auto* module : Mods().All()) {
        if (std::strcmp(module->name, "Zoom") == 0) {
            enabled = module->enabled;
            break;
        }
    }
    g_zoomActive.store(enabled, std::memory_order_release);
}

float GetZoomMagnification() {
    return g_zoomMagnification.load(std::memory_order_acquire);
}

void SetZoomMagnification(float value) {
    g_zoomMagnification.store(std::clamp(value, 1.0f, 16.0f),
                              std::memory_order_release);
}

float GetZoomScrollStep() {
    return g_zoomScrollStep.load(std::memory_order_acquire);
}

bool IsZoomAvailable() {
    return g_fovHookAvailable.load(std::memory_order_acquire);
}

unsigned long long GetFovHookCallCount() {
    return g_fovHookCallCount.load(std::memory_order_acquire);
}

float GetLastZoomFov() {
    return g_lastZoomFov.load(std::memory_order_acquire);
}

void SetZoomScrollStep(float value) {
    g_zoomScrollStep.store(std::clamp(value, 0.1f, 4.0f),
                           std::memory_order_release);
}

static float __fastcall GetFov_h(void* self, float arg, void* a3, void* a4) {
    HookCallGuard guard;
    float fov = oGetFov(self, arg, a3, a4);
    g_fovHookCallCount.fetch_add(1, std::memory_order_relaxed);
    if (!std::isfinite(fov) || fov <= 1.0f || fov >= 179.0f) {
        g_lastZoomFov.store(fov, std::memory_order_release);
        return fov;
    }
    if (!g_zoomActive.load(std::memory_order_acquire)) {
        g_lastZoomFov.store(fov, std::memory_order_release);
        return fov;
    }

    constexpr float radiansPerDegree = 3.14159265358979323846f / 180.0f;
    float magnification = g_zoomMagnification.load(std::memory_order_acquire);
    float zoomedFov = 2.0f * std::atan(
        std::tan(fov * radiansPerDegree * 0.5f) / magnification) /
        radiansPerDegree;
    g_lastZoomFov.store(zoomedFov, std::memory_order_release);
    return zoomedFov;
}

HWND FindGameWindow() {
    struct Ctx { DWORD pid; HWND best; LONG area; };
    Ctx ctx{GetCurrentProcessId(), nullptr, 0};
    EnumWindows([](HWND hw, LPARAM lp) -> BOOL {
        auto* c = reinterpret_cast<Ctx*>(lp);
        DWORD pid = 0;
        GetWindowThreadProcessId(hw, &pid);
        if (pid != c->pid || hw == GetConsoleWindow() || !IsWindowVisible(hw))
            return TRUE;
        RECT r{};
        GetClientRect(hw, &r);
        LONG area = (r.right - r.left) * (r.bottom - r.top);
        if (area > c->area) { c->area = area; c->best = hw; }
        return TRUE;
    }, reinterpret_cast<LPARAM>(&ctx));
    return ctx.best;
}

static bool CreateRTV() {
    ID3D11Texture2D* back = nullptr;
    HRESULT result = g_swap->GetBuffer(0, __uuidof(ID3D11Texture2D),
                                       reinterpret_cast<void**>(&back));
    if (FAILED(result) || !back) return false;
    result = g_device->CreateRenderTargetView(back, nullptr, &g_rtv);
    back->Release();
    return SUCCEEDED(result) && g_rtv;
}

static void ReleaseD3DResources() {
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    if (g_context) { g_context->Release(); g_context = nullptr; }
    if (g_device) { g_device->Release(); g_device = nullptr; }
}

static void STDMETHODCALLTYPE ExecuteCommandLists_h(
    ID3D12CommandQueue* queue, UINT count, ID3D12CommandList* const* lists) {
    HookCallGuard guard;
    if (g_shuttingDown.load(std::memory_order_acquire)) {
        oExecuteCommandLists(queue, count, lists);
        return;
    }
    if (g_device12 && queue &&
        g_queue12.load(std::memory_order_acquire) == nullptr) {
        D3D12_COMMAND_QUEUE_DESC queueDesc = queue->GetDesc();
        if (queueDesc.Type == D3D12_COMMAND_LIST_TYPE_DIRECT) {
            ID3D12Device* queueDevice = nullptr;
            HRESULT result = queue->GetDevice(
                __uuidof(ID3D12Device), reinterpret_cast<void**>(&queueDevice));
            if (SUCCEEDED(result) && queueDevice == g_device12) {
                queue->AddRef();
                ID3D12CommandQueue* expected = nullptr;
                if (g_queue12.compare_exchange_strong(
                        expected, queue, std::memory_order_release,
                        std::memory_order_relaxed)) {
                    printf("[BedrockClient] captured Minecraft's Direct3D 12 command queue.\n");
                    fflush(stdout);
                } else {
                    queue->Release();
                }
            }
            if (queueDevice) queueDevice->Release();
        }
    }
    oExecuteCommandLists(queue, count, lists);
}

static bool InstallD3D12QueueCapture() {
    if (g_d3d12QueueHookInstalled.load(std::memory_order_acquire)) return true;

    D3D12_COMMAND_QUEUE_DESC desc{};
    desc.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
    ID3D12CommandQueue* temporaryQueue = nullptr;
    HRESULT result = g_device12->CreateCommandQueue(
        &desc, __uuidof(ID3D12CommandQueue),
        reinterpret_cast<void**>(&temporaryQueue));
    if (FAILED(result) || !temporaryQueue) {
        printf("[BedrockClient] could not create a Direct3D 12 queue capture target (0x%08lX).\n",
               static_cast<unsigned long>(result));
        fflush(stdout);
        return false;
    }
    void** vtable = *reinterpret_cast<void***>(temporaryQueue);
    void* target = vtable[10];
    MH_STATUS status = MH_CreateHook(
        target, ExecuteCommandLists_h,
        reinterpret_cast<void**>(&oExecuteCommandLists));
    if (status == MH_OK) status = MH_EnableHook(target);
    temporaryQueue->Release();
    if (status != MH_OK) {
        printf("[BedrockClient] could not hook Direct3D 12 command queue submissions (%d).\n",
               static_cast<int>(status));
        fflush(stdout);
        return false;
    }
    g_d3d12QueueHookInstalled.store(true, std::memory_order_release);
    printf("[BedrockClient] waiting to capture Minecraft's Direct3D 12 command queue...\n");
    fflush(stdout);
    return true;
}

static void ReleaseD3D12BackBuffers() {
    for (UINT i = 0; i < kMaxBackBuffers; ++i) {
        if (g_backBuffers12[i]) {
            g_backBuffers12[i]->Release();
            g_backBuffers12[i] = nullptr;
        }
        if (g_frames12[i].allocator) {
            g_frames12[i].allocator->Release();
            g_frames12[i].allocator = nullptr;
        }
        g_frames12[i].fenceValue = 0;
    }
    if (g_rtvHeap12) {
        g_rtvHeap12->Release();
        g_rtvHeap12 = nullptr;
    }
    g_bufferCount12 = 0;
}

static bool WaitForD3D12Fence(UINT64 value);
static void ReleaseD3D12Renderer();

static bool CreateD3D12BackBuffers(IDXGISwapChain* swapChain,
                                   const DXGI_SWAP_CHAIN_DESC& swapDesc) {
    UINT count = swapDesc.BufferCount;
    if (!count || count > kMaxBackBuffers) {
        printf("[BedrockClient] unsupported Direct3D 12 back-buffer count: %u.\n", count);
        fflush(stdout);
        return false;
    }

    D3D12_DESCRIPTOR_HEAP_DESC heapDesc{};
    heapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
    heapDesc.NumDescriptors = count;
    if (FAILED(g_device12->CreateDescriptorHeap(
            &heapDesc, __uuidof(ID3D12DescriptorHeap),
            reinterpret_cast<void**>(&g_rtvHeap12)))) {
        printf("[BedrockClient] could not create the Direct3D 12 render-target descriptor heap.\n");
        fflush(stdout);
        return false;
    }
    g_rtvDescriptorSize12 =
        g_device12->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
    D3D12_CPU_DESCRIPTOR_HANDLE handle = g_rtvHeap12->GetCPUDescriptorHandleForHeapStart();

    for (UINT i = 0; i < count; ++i) {
        if (FAILED(swapChain->GetBuffer(
                i, __uuidof(ID3D12Resource),
                reinterpret_cast<void**>(&g_backBuffers12[i])))) {
            printf("[BedrockClient] could not acquire Direct3D 12 back buffer %u.\n", i);
            fflush(stdout);
            ReleaseD3D12BackBuffers();
            return false;
        }
        g_device12->CreateRenderTargetView(g_backBuffers12[i], nullptr, handle);
        handle.ptr += g_rtvDescriptorSize12;
        if (FAILED(g_device12->CreateCommandAllocator(
                D3D12_COMMAND_LIST_TYPE_DIRECT,
                __uuidof(ID3D12CommandAllocator),
                reinterpret_cast<void**>(&g_frames12[i].allocator)))) {
            printf("[BedrockClient] could not create Direct3D 12 frame allocator %u.\n", i);
            fflush(stdout);
            ReleaseD3D12BackBuffers();
            return false;
        }
    }
    g_bufferCount12 = count;
    g_renderTargetFormat12 = swapDesc.BufferDesc.Format;
    return true;
}

static bool InitializeD3D12Renderer(IDXGISwapChain* swapChain,
                                    const DXGI_SWAP_CHAIN_DESC& swapDesc) {
    if (!g_device12) {
        HRESULT result = swapChain->GetDevice(
            __uuidof(ID3D12Device), reinterpret_cast<void**>(&g_device12));
        if (FAILED(result)) return false;
    }
    if (!InstallD3D12QueueCapture()) return false;

    ID3D12CommandQueue* queue = g_queue12.load(std::memory_order_acquire);
    if (!queue) {
        if (!g_d3d12QueueWaitReported.exchange(true, std::memory_order_acq_rel)) {
            printf("[BedrockClient] Direct3D 12 queue hook is installed; waiting for the game to submit a frame.\n");
            fflush(stdout);
        }
        return false;
    }

    if (!CreateD3D12BackBuffers(swapChain, swapDesc)) {
        ReleaseD3D12Renderer();
        return false;
    }

    D3D12_DESCRIPTOR_HEAP_DESC srvHeapDesc{};
    srvHeapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
    srvHeapDesc.NumDescriptors = 1;
    srvHeapDesc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    HRESULT result = g_device12->CreateDescriptorHeap(
        &srvHeapDesc, __uuidof(ID3D12DescriptorHeap),
        reinterpret_cast<void**>(&g_srvHeap12));
    if (FAILED(result)) {
        printf("[BedrockClient] could not create the Direct3D 12 shader descriptor heap.\n");
        fflush(stdout);
        ReleaseD3D12Renderer();
        return false;
    }
    result = g_device12->CreateCommandList(
        0, D3D12_COMMAND_LIST_TYPE_DIRECT, g_frames12[0].allocator, nullptr,
        __uuidof(ID3D12GraphicsCommandList),
        reinterpret_cast<void**>(&g_commandList12));
    if (FAILED(result)) {
        printf("[BedrockClient] could not create the Direct3D 12 overlay command list.\n");
        fflush(stdout);
        ReleaseD3D12Renderer();
        return false;
    }
    g_commandList12->Close();

    result = g_device12->CreateFence(
        0, D3D12_FENCE_FLAG_NONE, __uuidof(ID3D12Fence),
        reinterpret_cast<void**>(&g_fence12));
    if (FAILED(result)) {
        printf("[BedrockClient] could not create the Direct3D 12 overlay fence.\n");
        fflush(stdout);
        ReleaseD3D12Renderer();
        return false;
    }
    g_fenceEvent12 = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!g_fenceEvent12) {
        printf("[BedrockClient] could not create the Direct3D 12 fence event (%lu).\n",
               GetLastError());
        ReleaseD3D12Renderer();
        return false;
    }

    if (!gui::InitD3D12(
            g_hwnd, g_device12, static_cast<int>(g_bufferCount12),
            g_renderTargetFormat12, g_srvHeap12,
            g_srvHeap12->GetCPUDescriptorHandleForHeapStart(),
            g_srvHeap12->GetGPUDescriptorHandleForHeapStart())) {
        ReleaseD3D12Renderer();
        return false;
    }
    g_usingD3D12.store(true, std::memory_order_release);
    return true;
}

static bool WaitForD3D12Fence(UINT64 value) {
    if (!g_fence12 || !g_fenceEvent12) return false;
    if (g_fence12->GetCompletedValue() >= value) return true;
    HRESULT result = g_fence12->SetEventOnCompletion(value, g_fenceEvent12);
    if (FAILED(result)) return false;
    return WaitForSingleObject(g_fenceEvent12, 2000) == WAIT_OBJECT_0;
}

static void WaitForD3D12QueueIdle() {
    ID3D12CommandQueue* queue = g_queue12.load(std::memory_order_acquire);
    if (!queue || !g_fence12 || !g_fenceEvent12) return;
    UINT64 value = ++g_nextFenceValue12;
    if (SUCCEEDED(queue->Signal(g_fence12, value)))
        WaitForD3D12Fence(value);
}

static void ReleaseD3D12Renderer() {
    WaitForD3D12QueueIdle();
    gui::Shutdown();
    ReleaseD3D12BackBuffers();
    if (g_commandList12) { g_commandList12->Release(); g_commandList12 = nullptr; }
    if (g_srvHeap12) { g_srvHeap12->Release(); g_srvHeap12 = nullptr; }
    if (g_fence12) { g_fence12->Release(); g_fence12 = nullptr; }
    if (g_fenceEvent12) { CloseHandle(g_fenceEvent12); g_fenceEvent12 = nullptr; }
    g_nextFenceValue12 = 0;
    g_frameCursor12 = 0;
    g_usingD3D12.store(false, std::memory_order_release);
}

static void ReleaseD3D12Capture() {
    ID3D12CommandQueue* queue = g_queue12.exchange(nullptr, std::memory_order_acq_rel);
    if (queue) queue->Release();
    if (g_device12) { g_device12->Release(); g_device12 = nullptr; }
}

static bool RenderD3D12(IDXGISwapChain* swapChain) {
    ID3D12CommandQueue* queue = g_queue12.load(std::memory_order_acquire);
    if (!queue || !g_commandList12 || !g_fence12 || !g_bufferCount12)
        return false;

    UINT frameIndex = g_frameCursor12++ % g_bufferCount12;
    IDXGISwapChain3* swapChain3 = nullptr;
    if (SUCCEEDED(swapChain->QueryInterface(
            __uuidof(IDXGISwapChain3), reinterpret_cast<void**>(&swapChain3)))) {
        frameIndex = swapChain3->GetCurrentBackBufferIndex();
        swapChain3->Release();
    }
    if (frameIndex >= g_bufferCount12) return false;

    D3D12Frame& frame = g_frames12[frameIndex];
    if (frame.fenceValue && !WaitForD3D12Fence(frame.fenceValue)) {
        printf("[BedrockClient] timed out waiting for a Direct3D 12 frame allocator.\n");
        fflush(stdout);
        return false;
    }
    if (FAILED(frame.allocator->Reset()) ||
        FAILED(g_commandList12->Reset(frame.allocator, nullptr)))
        return false;

    D3D12_RESOURCE_BARRIER barrier{};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Transition.pResource = g_backBuffers12[frameIndex];
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
    g_commandList12->ResourceBarrier(1, &barrier);

    D3D12_CPU_DESCRIPTOR_HANDLE rtv =
        g_rtvHeap12->GetCPUDescriptorHandleForHeapStart();
    rtv.ptr += static_cast<SIZE_T>(frameIndex) * g_rtvDescriptorSize12;
    g_commandList12->OMSetRenderTargets(1, &rtv, FALSE, nullptr);
    ID3D12DescriptorHeap* heaps[] = {g_srvHeap12};
    g_commandList12->SetDescriptorHeaps(1, heaps);

    gui::RenderD3D12(g_commandList12);

    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_PRESENT;
    g_commandList12->ResourceBarrier(1, &barrier);
    if (FAILED(g_commandList12->Close())) return false;

    ID3D12CommandList* lists[] = {g_commandList12};
    queue->ExecuteCommandLists(1, lists);
    frame.fenceValue = ++g_nextFenceValue12;
    if (FAILED(queue->Signal(g_fence12, frame.fenceValue))) return false;
    return true;
}

static bool ZoomEnabled() {
    return g_zoomActive.load(std::memory_order_acquire);
}

static LRESULT CALLBACK WndProc_h(HWND h, UINT m, WPARAM w, LPARAM l) {
    HookCallGuard guard;
    if (g_shuttingDown.load(std::memory_order_acquire))
        return CallWindowProcW(oWndProc, h, m, w, l);

    if (m == WM_MOUSEWHEEL &&
        g_fovHookAvailable.load(std::memory_order_acquire) && ZoomEnabled()) {
        int delta = GET_WHEEL_DELTA_WPARAM(w);
        float steps = static_cast<float>(delta) / WHEEL_DELTA;
        SetZoomMagnification(GetZoomMagnification() +
            steps * GetZoomScrollStep());
        if (!gui::IsMenuOpen()) return 0;
    }

    if (gui::IsMenuOpen()) {
        ImGui_ImplWin32_WndProcHandler(h, m, w, l);
        ImGui::GetIO().MouseDrawCursor = true;
        switch (m) {
            case WM_MOUSEMOVE:
            case WM_LBUTTONDOWN: case WM_LBUTTONUP:
            case WM_RBUTTONDOWN: case WM_RBUTTONUP:
            case WM_MOUSEWHEEL:
                return 0;
            default: break;
        }
    } else {
        ImGui::GetIO().MouseDrawCursor = false;
        ImGui_ImplWin32_WndProcHandler(h, m, w, l);
    }
    return CallWindowProcW(oWndProc, h, m, w, l);
}

static bool InitImGui() {
    DXGI_SWAP_CHAIN_DESC desc{};
    HRESULT result = g_swap->GetDesc(&desc);
    if (FAILED(result)) {
        if (!g_deviceFailureReported.exchange(true, std::memory_order_acq_rel)) {
            printf("[BedrockClient] swap-chain GetDesc failed (0x%08lX).\n",
                   static_cast<unsigned long>(result));
            fflush(stdout);
        }
        return false;
    }

    HWND swapWindow = desc.OutputWindow;
    DWORD swapWindowPid = 0;
    if (swapWindow) GetWindowThreadProcessId(swapWindow, &swapWindowPid);
    if (!swapWindow || swapWindow != g_hwnd ||
        swapWindowPid != GetCurrentProcessId()) {
        return false;
    }

    result = g_swap->GetDevice(__uuidof(ID3D11Device),
                               reinterpret_cast<void**>(&g_device));
    if (FAILED(result)) {
        ID3D12Device* device12 = nullptr;
        HRESULT d3d12Result = g_swap->GetDevice(
            __uuidof(ID3D12Device), reinterpret_cast<void**>(&device12));
        if (FAILED(d3d12Result) || !device12) {
            if (!g_deviceFailureReported.exchange(true, std::memory_order_acq_rel)) {
                printf("[BedrockClient] Minecraft swap chain is not Direct3D 11 or Direct3D 12 (0x%08lX).\n",
                       static_cast<unsigned long>(result));
                fflush(stdout);
            }
            return false;
        }
        if (!g_device12) g_device12 = device12;
        else device12->Release();
        if (!InstallD3D12QueueCapture()) return false;
        if (!g_queue12.load(std::memory_order_acquire)) return false;
        if (!InitializeD3D12Renderer(g_swap, desc)) return false;
    } else {
        g_device->GetImmediateContext(&g_context);
        g_hwnd = swapWindow;
        if (!CreateRTV()) {
            if (!g_deviceFailureReported.exchange(true, std::memory_order_acq_rel)) {
                printf("[BedrockClient] could not create a render target for the Minecraft swap chain.\n");
                fflush(stdout);
            }
            ReleaseD3DResources();
            return false;
        }
        if (!gui::Init(g_hwnd, g_device, g_context)) {
            ReleaseD3DResources();
            return false;
        }
    }

    SetLastError(ERROR_SUCCESS);
    LONG_PTR previousWndProc = SetWindowLongPtrW(
        g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(WndProc_h));
    if (!previousWndProc && GetLastError() != ERROR_SUCCESS) {
        printf("[BedrockClient] replacing the game window procedure failed (%lu).\n",
               GetLastError());
        gui::Shutdown();
        if (g_usingD3D12.load(std::memory_order_acquire)) {
            ReleaseD3D12Renderer();
        } else {
            ReleaseD3DResources();
        }
        return false;
    }
    oWndProc = reinterpret_cast<WndProc_t>(previousWndProc);
    return true;
}

static HRESULT WINAPI Present_h(IDXGISwapChain* sc, UINT sync, UINT flags) {
    HookCallGuard guard;
    if (g_shuttingDown.load(std::memory_order_acquire))
        return oPresent(sc, sync, flags);

    DXGI_SWAP_CHAIN_DESC desc{};
    if (FAILED(sc->GetDesc(&desc)) || desc.OutputWindow != g_hwnd)
        return oPresent(sc, sync, flags);
    g_presentSeen.store(true, std::memory_order_release);
    g_swap = sc;
    if (!g_imguiReady.load(std::memory_order_acquire) &&
        !g_imguiInitializing.test_and_set(std::memory_order_acquire)) {
        bool initialized = InitImGui();
        if (!initialized && !g_initFailureReported.exchange(true, std::memory_order_acq_rel)) {
            printf("[BedrockClient] overlay initialization failed; retrying on the next game frame.\n");
            fflush(stdout);
        }
        g_imguiReady.store(initialized, std::memory_order_release);
        g_imguiInitializing.clear(std::memory_order_release);
    }
    if (g_imguiReady.load(std::memory_order_acquire)) {
        PollHotkeys();
        auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - g_last).count();
        g_last = now;
        if (dt > 0.25f) dt = 0.25f;
        Mods().Tick(dt);
        gui::NewFrame();
        gui::Render();
        SyncZoomActive();
        Mods().Render();
        ImGui::Render();
        if (g_usingD3D12.load(std::memory_order_acquire)) {
            RenderD3D12(sc);
        } else {
            g_context->OMSetRenderTargets(1, &g_rtv, nullptr);
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        }
    }
    return oPresent(sc, sync, flags);
}

static HRESULT WINAPI ResizeBuffers_h(IDXGISwapChain* sc, UINT n, UINT w, UINT h,
                                      DXGI_FORMAT f, UINT fl) {
    HookCallGuard guard;
    if (g_shuttingDown.load(std::memory_order_acquire))
        return oResizeBuffers(sc, n, w, h, f, fl);

    if (sc != g_swap) return oResizeBuffers(sc, n, w, h, f, fl);
    if (g_usingD3D12.load(std::memory_order_acquire)) {
        WaitForD3D12QueueIdle();
        ReleaseD3D12BackBuffers();
        HRESULT result = oResizeBuffers(sc, n, w, h, f, fl);
        if (SUCCEEDED(result)) {
            DXGI_SWAP_CHAIN_DESC desc{};
            if (SUCCEEDED(sc->GetDesc(&desc)) &&
                !CreateD3D12BackBuffers(sc, desc)) {
                printf("[BedrockClient] failed to recreate Direct3D 12 back buffers after resize.\n");
                fflush(stdout);
            }
        }
        return result;
    }

    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    HRESULT r = oResizeBuffers(sc, n, w, h, f, fl);
    if (g_device && !CreateRTV())
        printf("[BedrockClient] failed to recreate the Direct3D render target after resize.\n");
    return r;
}

bool Install() {
    printf("[BedrockClient] finding the game window...\n");
    fflush(stdout);
    HWND gameWindow = FindGameWindow();
    if (!gameWindow) {
        printf("[BedrockClient] no visible game window was found.\n");
        fflush(stdout);
        return false;
    }
    printf("[BedrockClient] game window found; initializing MinHook...\n");
    fflush(stdout);
    MH_STATUS status = MH_Initialize();
    if (status != MH_OK) {
        printf("[BedrockClient] MH_Initialize failed (%d).\n", static_cast<int>(status));
        fflush(stdout);
        return false;
    }
    bool fovSignatureFound = false;
    MH_STATUS fovHookStatus = MH_OK;
    for (const char* signature : cfg::Sig_GetFov) {
        uintptr_t fovTarget = mem::ScanMainModule(signature);
        if (!fovTarget) continue;

        fovSignatureFound = true;
        fovHookStatus = MH_CreateHook(
            reinterpret_cast<void*>(fovTarget), GetFov_h,
            reinterpret_cast<void**>(&oGetFov));
        if (fovHookStatus == MH_OK) {
            g_fovHookAvailable.store(true, std::memory_order_release);
            printf("[BedrockClient] camera FOV hook created at 0x%llX.\n",
                   static_cast<unsigned long long>(fovTarget));
            break;
        }
    }
    if (!g_fovHookAvailable.load(std::memory_order_acquire)) {
        uintptr_t moduleBase = mem::GetMainModuleBase();
        size_t moduleSize = mem::GetMainModuleSize();
        if (!fovSignatureFound)
            printf("[BedrockClient] no supported camera FOV signature matched (game module 0x%llX, %zu bytes); Zoom is unavailable.\n",
                   static_cast<unsigned long long>(moduleBase), moduleSize);
        else
            printf("[BedrockClient] camera FOV hook creation failed (%d); Zoom is unavailable.\n",
                   static_cast<int>(fovHookStatus));
        fflush(stdout);
    }

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount       = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage       = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow      = gameWindow;
    sd.SampleDesc.Count  = 1;
    sd.Windowed          = TRUE;
    sd.SwapEffect        = DXGI_SWAP_EFFECT_DISCARD;

    ID3D11Device* d = nullptr;
    ID3D11DeviceContext* c = nullptr;
    IDXGISwapChain* s = nullptr;
    D3D_FEATURE_LEVEL fl{};
    printf("[BedrockClient] creating a Direct3D hook target...\n");
    fflush(stdout);
    HRESULT result = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
        D3D11_SDK_VERSION, &sd, &s, &d, &fl, &c);
    if (FAILED(result)) {
        printf("[BedrockClient] Direct3D initialization failed (0x%08lX).\n",
               static_cast<unsigned long>(result));
        fflush(stdout);
        g_fovHookAvailable.store(false, std::memory_order_release);
        MH_Uninitialize();
        return false;
    }

    void** vt = *reinterpret_cast<void***>(s);
    status = MH_CreateHook(vt[8], Present_h, reinterpret_cast<void**>(&oPresent));
    if (status == MH_OK)
        status = MH_CreateHook(vt[13], ResizeBuffers_h,
                               reinterpret_cast<void**>(&oResizeBuffers));
    if (status == MH_OK) status = MH_EnableHook(MH_ALL_HOOKS);
    s->Release(); c->Release(); d->Release();
    if (status != MH_OK) {
        g_fovHookAvailable.store(false, std::memory_order_release);
        printf("[BedrockClient] Direct3D hook setup failed (%d).\n",
               static_cast<int>(status));
        fflush(stdout);
        MH_Uninitialize();
        return false;
    }
    printf("[BedrockClient] Direct3D hooks installed; waiting for the game to render...\n");
    if (g_fovHookAvailable.load(std::memory_order_acquire))
        printf("[BedrockClient] camera FOV hook installed; Zoom wheel control is available.\n");
    fflush(stdout);
    return true;
}

static void PrintUnloadProgress(int percent, const char* step) {
    constexpr int barWidth = 20;
    int filled = percent * barWidth / 100;
    printf("[BedrockClient] [");
    for (int i = 0; i < barWidth; ++i) printf(i < filled ? "#" : "-");
    printf("] %3d%% %s\n", percent, step);
    fflush(stdout);
}

void Uninstall() {
    HWND console = GetConsoleWindow();
    if (console) {
        ShowWindow(console, SW_SHOW);
        SetForegroundWindow(console);
    }
    PrintUnloadProgress(0, "Starting unload");
    g_shuttingDown.store(true, std::memory_order_release);
    MH_STATUS status = MH_DisableHook(MH_ALL_HOOKS);
    if (status != MH_OK && status != MH_ERROR_DISABLED)
        printf("[BedrockClient] disabling hooks returned status %d.\n",
               static_cast<int>(status));
    PrintUnloadProgress(20, "Disabled hooks");
    if (g_hwnd && oWndProc)
        SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(oWndProc));
    PrintUnloadProgress(35, "Restored game window procedure");
    Sleep(50);
    while (g_activeHookCalls.load(std::memory_order_acquire) != 0)
        Sleep(1);
    PrintUnloadProgress(45, "Waited for active callbacks");
    if (g_usingD3D12.load(std::memory_order_acquire))
        ReleaseD3D12Renderer();
    else {
        gui::Shutdown();
        ReleaseD3DResources();
    }
    ReleaseD3D12Capture();
    PrintUnloadProgress(55, "Shut down menu renderer");
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    PrintUnloadProgress(75, "Released render target");
    PrintUnloadProgress(90, "Disabled hooks");
    MH_Uninitialize();
    PrintUnloadProgress(100, "Unload complete");
}

} // namespace hooks
'@

Write-File 'src/modules/Modules.hpp' @'
#pragma once
void RegisterModules();
'@

Write-File 'src/modules/Modules.cpp' @'
#include "Modules.hpp"
#include "Config.hpp"
#include "Hooks.hpp"
#include "Memory.hpp"
#include "Module.hpp"
#include "SDK.hpp"

#include <imgui.h>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <algorithm>

#if 0
namespace {

struct Fly : Module {
    float speed = cfg::FlySpeed;
    Fly() : Module("Fly", "Hover, Space to rise, Shift to descend", 'F') {}
    void DrawSettings() override { ImGui::SliderFloat("Speed##fly", &speed, 0.2f, 8.0f, "%.2f"); }
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        Vec3 v = sdk::GetVelocity(lp);
        v.y = 0.0f;
        if (GetAsyncKeyState(VK_SPACE) & 0x8000) v.y =  speed;
        if (GetAsyncKeyState(VK_SHIFT) & 0x8000) v.y = -speed;
        sdk::SetVelocity(lp, v);
        sdk::SetOnGround(lp, false);
    }
};

struct Speed : Module {
    float value = cfg::SpeedValue;
    Speed() : Module("Speed", "Scales horizontal velocity to a fixed value", 'G') {}
    void DrawSettings() override { ImGui::SliderFloat("Speed##spd", &value, 0.5f, 6.0f, "%.2f"); }
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        Vec3 v = sdk::GetVelocity(lp);
        float h = std::sqrt(v.x * v.x + v.z * v.z);
        if (h < 1e-3f) return;
        v.x = v.x / h * value;
        v.z = v.z / h * value;
        sdk::SetVelocity(lp, v);
    }
};

struct AutoSprint : Module {
    AutoSprint() : Module("AutoSprint", "Keeps the sprint flag set", 'V') {}
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (lp) sdk::SetSprinting(lp, true);
    }
};

struct NoFall : Module {
    NoFall() : Module("NoFall", "Cancels fall damage by grounding mid-air", 'N') {}
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        if (sdk::GetVelocity(lp).y < -0.1f) sdk::SetOnGround(lp, true);
    }
};

struct FullBright : Module {
    float gamma = 5.0f;
    FullBright() : Module("FullBright", "Writes a high gamma into game options", 'B') {}
    void DrawSettings() override { ImGui::SliderFloat("Gamma##fb", &gamma, 1.0f, 15.0f, "%.1f"); }
    void Tick(float) override {
        uintptr_t ci = sdk::GetClientInstance();
        if (!ci) return;
        uintptr_t mg = mem::Read<uintptr_t>(ci + cfg::CI_MinecraftGame);
        if (!mg) return;
        uintptr_t opt = mem::Read<uintptr_t>(mg + cfg::MG_Options);
        if (!opt) return;
        mem::Write(opt + cfg::OPT_Gamma, gamma);
    }
};

struct ESP : Module {
    bool players = true;
    bool mobs    = true;
    float col[3] = {0.15f, 1.0f, 0.4f};
    ESP() : Module("ESP", "Wall-through boxes, nametags and distance", 'X') {}
    void DrawSettings() override {
        ImGui::Checkbox("Players##esp", &players);
        ImGui::SameLine();
        ImGui::Checkbox("Mobs##esp", &mobs);
        ImGui::ColorEdit3("Box##esp", col, ImGuiColorEditFlags_NoInputs);
    }
    static bool WorldToScreen(const Vec3& w, const Vec3& eye, const Vec2& rot,
                              const ImVec2& disp, ImVec2& out);
    void Render() override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        Vec2 rot = sdk::GetRotation(lp);
        Vec3 eye = sdk::GetEyePosition(lp);
        ImVec2 disp = ImGui::GetIO().DisplaySize;
        ImDrawList* dl = ImGui::GetForegroundDrawList();
        ImU32 color = ImGui::ColorConvertFloat4ToU32({col[0], col[1], col[2], 1.0f});

        for (auto e : sdk::GetEntities()) {
            if (e == lp || sdk::IsDead(e)) continue;
            bool isPlayer = (mem::Read<int>(e + cfg::AC_TypeId) == cfg::PlayerTypeId);
            if (isPlayer && !players) continue;
            if (!isPlayer && !mobs)   continue;

            AABB box = sdk::GetAABB(e);
            Vec3 corners[8] = {
                {box.min.x, box.min.y, box.min.z}, {box.max.x, box.min.y, box.min.z},
                {box.min.x, box.max.y, box.min.z}, {box.max.x, box.max.y, box.min.z},
                {box.min.x, box.min.y, box.max.z}, {box.max.x, box.min.y, box.max.z},
                {box.min.x, box.max.y, box.max.z}, {box.max.x, box.max.y, box.max.z},
            };
            ImVec2 pts[8];
            bool visible = true;
            for (int i = 0; i < 8; ++i) {
                if (!WorldToScreen(corners[i], eye, rot, disp, pts[i])) { visible = false; break; }
            }
            if (!visible) continue;

            float minX = pts[0].x, maxX = pts[0].x, minY = pts[0].y, maxY = pts[0].y;
            for (auto& p : pts) {
                minX = std::min(minX, p.x); maxX = std::max(maxX, p.x);
                minY = std::min(minY, p.y); maxY = std::max(maxY, p.y);
            }
            dl->AddRect({minX, minY}, {maxX, maxY}, color, 0.0f, 0, 1.6f);

            Vec3 pos = sdk::GetPosition(e);
            float dist = (pos - eye).length();
            std::string nm = sdk::GetNameTag(e);
            char label[128];
            snprintf(label, sizeof(label), "%s [%.1fm]", nm.empty() ? "?" : nm.c_str(), dist);
            dl->AddText({minX, minY - 15.0f}, color, label);
        }
    }
};

struct KillAura : Module {
    float range = cfg::AuraRange;
    float cps   = cfg::AuraCPS;
    std::chrono::steady_clock::time_point last{};
    KillAura() : Module("KillAura", "Attacks the nearest entity in range", 'R') {}
    void DrawSettings() override {
        ImGui::SliderFloat("Range##ka", &range, 2.0f, 8.0f, "%.1f");
        ImGui::SliderFloat("CPS##ka",   &cps,   1.0f, 20.0f, "%.0f");
    }
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration<float>(now - last).count() < 1.0f / cps) return;
        Vec3 eye = sdk::GetEyePosition(lp);
        uintptr_t best = 0;
        float bestDist = range;
        for (auto e : sdk::GetEntities()) {
            if (e == lp || sdk::IsDead(e)) continue;
            float d = (sdk::GetPosition(e) - eye).length();
            if (d < bestDist) { bestDist = d; best = e; }
        }
        if (best) { sdk::Attack(best); last = now; }
    }
};

struct Nuker : Module {
    float range = cfg::NukerRange;
    Nuker() : Module("Nuker", "Destroys blocks in a radius around you", 'K') {}
    void DrawSettings() override { ImGui::SliderFloat("Range##nk", &range, 1.0f, 8.0f, "%.1f"); }
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        Vec3 p = sdk::GetPosition(lp);
        int rad = static_cast<int>(range);
        int sent = 0;
        for (int dx = -rad; dx <= rad && sent < cfg::NukerPerFrame; ++dx)
        for (int dy = -rad; dy <= rad && sent < cfg::NukerPerFrame; ++dy)
        for (int dz = -rad; dz <= rad && sent < cfg::NukerPerFrame; ++dz) {
            Vec3 c{std::floor(p.x) + dx + 0.5f,
                   std::floor(p.y) + dy + 0.5f,
                   std::floor(p.z) + dz + 0.5f};
            if ((c - p).length() > range) continue;
            sdk::DestroyBlock(c);
            ++sent;
        }
    }
};

} // namespace

static void MulMat(const float A[16], const float B[16], float C[16]) {
    for (int i = 0; i < 4; ++i)
        for (int j = 0; j < 4; ++j) {
            float s = 0.0f;
            for (int k = 0; k < 4; ++k) s += A[i * 4 + k] * B[k * 4 + j];
            C[i * 4 + j] = s;
        }
}

static void LookAt(const Vec3& eye, const Vec3& f, float M[16]) {
    Vec3 F = f.normalized();
    Vec3 up{0, 1, 0};
    Vec3 S{F.y * up.z - F.z * up.y, F.z * up.x - F.x * up.z, F.x * up.y - F.y * up.x};
    S = S.normalized();
    Vec3 U{S.y * F.z - S.z * F.y, S.z * F.x - S.x * F.z, S.x * F.y - S.y * F.x};
    M[0] = S.x;  M[1] = S.y;  M[2] = S.z;  M[3] = -(S.x * eye.x + S.y * eye.y + S.z * eye.z);
    M[4] = U.x;  M[5] = U.y;  M[6] = U.z;  M[7] = -(U.x * eye.x + U.y * eye.y + U.z * eye.z);
    M[8] = -F.x; M[9] = -F.y; M[10] = -F.z; M[11] = (F.x * eye.x + F.y * eye.y + F.z * eye.z);
    M[12] = 0;   M[13] = 0;   M[14] = 0;   M[15] = 1;
}

static void Perspective(float fovDeg, float aspect, float n, float f, float M[16]) {
    constexpr float PI = 3.14159265f;
    float h = 1.0f / std::tan(fovDeg * 0.5f * PI / 180.0f);
    float w = h / aspect;
    M[0] = w;  M[1] = 0;  M[2] = 0;             M[3] = 0;
    M[4] = 0;  M[5] = h;  M[6] = 0;             M[7] = 0;
    M[8] = 0;  M[9] = 0;  M[10] = f / (n - f);  M[11] = n * f / (n - f);
    M[12] = 0; M[13] = 0; M[14] = -1;           M[15] = 0;
}

bool ESP::WorldToScreen(const Vec3& w, const Vec3& eye, const Vec2& rot,
                        const ImVec2& disp, ImVec2& out) {
    constexpr float PI = 3.14159265f;
    float yaw   = rot.x * PI / 180.0f;
    float pitch = rot.y * PI / 180.0f;
    Vec3 fwd{-std::sin(yaw) * std::cos(pitch),
             -std::sin(pitch),
              std::cos(yaw) * std::cos(pitch)};
    float V[16], P[16], VP[16];
    LookAt(eye, fwd, V);
    Perspective(70.0f, disp.x / disp.y, 0.05f, 1000.0f, P);
    MulMat(P, V, VP);

    float x  = VP[0] * w.x + VP[1] * w.y + VP[2]  * w.z + VP[3];
    float y  = VP[4] * w.x + VP[5] * w.y + VP[6]  * w.z + VP[7];
    float wc = VP[12] * w.x + VP[13] * w.y + VP[14] * w.z + VP[15];
    if (wc < 0.001f) return false;
    out.x = ((x / wc) * 0.5f + 0.5f) * disp.x;
    out.y = (0.5f - (y / wc) * 0.5f) * disp.y;
    return true;
}

#endif
namespace {

struct CameraProjection {
    Vec3 eye;
    float sinYaw;
    float cosYaw;
    float sinPitch;
    float cosPitch;
    float focal;
    ImVec2 display;

    CameraProjection(const Vec3& cameraEye, const Vec2& rotation,
                     float fovDegrees, const ImVec2& screen)
        : eye(cameraEye),
          sinYaw(std::sin(rotation.x * 0.017453292519943295f)),
          cosYaw(std::cos(rotation.x * 0.017453292519943295f)),
          sinPitch(std::sin(rotation.y * 0.017453292519943295f)),
          cosPitch(std::cos(rotation.y * 0.017453292519943295f)),
          focal(screen.y * 0.5f /
                std::tan(fovDegrees * 0.008726646259971648f)),
          display(screen) {}

    Vec3 ToCamera(const Vec3& point) const {
        Vec3 delta = point - eye;
        float forwardX = -sinYaw * cosPitch;
        float forwardY = -sinPitch;
        float forwardZ = cosYaw * cosPitch;
        return {
            cosYaw * delta.x + sinYaw * delta.z,
            -sinPitch * sinYaw * delta.x + cosPitch * delta.y +
                sinPitch * cosYaw * delta.z,
            forwardX * delta.x + forwardY * delta.y + forwardZ * delta.z
        };
    }

    bool ProjectCameraPoint(const Vec3& point, ImVec2& screen) const {
        if (point.z < 0.05f) return false;
        screen.x = display.x * 0.5f + focal * point.x / point.z;
        screen.y = display.y * 0.5f - focal * point.y / point.z;
        return std::isfinite(screen.x) && std::isfinite(screen.y);
    }

    bool DrawSegment(ImDrawList* drawList, const Vec3& start, const Vec3& end,
                     ImU32 color, float thickness) const {
        return DrawCameraSegment(drawList, ToCamera(start), ToCamera(end),
                                 color, thickness);
    }

    bool DrawCameraSegment(ImDrawList* drawList, Vec3 a, Vec3 b,
                           ImU32 color, float thickness) const {
        constexpr float nearPlane = 0.05f;
        if (a.z < nearPlane && b.z < nearPlane) return false;
        if (a.z < nearPlane || b.z < nearPlane) {
            float t = (nearPlane - a.z) / (b.z - a.z);
            Vec3 clipped = a + (b - a) * t;
            if (a.z < nearPlane) a = clipped;
            else b = clipped;
        }

        ImVec2 screenA, screenB;
        if (!ProjectCameraPoint(a, screenA) || !ProjectCameraPoint(b, screenB))
            return false;
        drawList->AddLine(screenA, screenB, color, thickness);
        return true;
    }
};

static bool DrawAabb(ImDrawList* drawList, const CameraProjection& camera,
                     const AABB& box, ImU32 color) {
    const Vec3 worldCorners[8] = {
        {box.min.x, box.min.y, box.min.z}, {box.max.x, box.min.y, box.min.z},
        {box.min.x, box.max.y, box.min.z}, {box.max.x, box.max.y, box.min.z},
        {box.min.x, box.min.y, box.max.z}, {box.max.x, box.min.y, box.max.z},
        {box.min.x, box.max.y, box.max.z}, {box.max.x, box.max.y, box.max.z}
    };
    Vec3 corners[8];
    for (int i = 0; i < 8; ++i)
        corners[i] = camera.ToCamera(worldCorners[i]);
    constexpr int edges[12][2] = {
        {0, 1}, {0, 2}, {0, 4}, {1, 3}, {1, 5}, {2, 3},
        {2, 6}, {3, 7}, {4, 5}, {4, 6}, {5, 7}, {6, 7}
    };
    bool drawn = false;
    for (const auto& edge : edges)
        drawn = camera.DrawCameraSegment(drawList, corners[edge[0]],
                                          corners[edge[1]], color, 1.5f) || drawn;
    return drawn;
}

struct ZoomModule : Module {
    ZoomModule()
        : Module("Zoom", "Changes the game camera FOV; scroll while enabled", 'Z') {}

    void DrawSettings() override {
        if (!hooks::IsZoomAvailable()) {
            ImGui::TextColored({1.0f, 0.55f, 0.3f, 1.0f},
                               "Camera FOV hook unavailable; check startup log.");
        } else if (hooks::GetFovHookCallCount() == 0) {
            ImGui::TextColored({1.0f, 0.75f, 0.3f, 1.0f},
                               "FOV hook installed; waiting for its first call.");
        } else {
            ImGui::Text("FOV hook calls: %llu | camera FOV: %.1f degrees",
                        hooks::GetFovHookCallCount(), hooks::GetLastZoomFov());
        }

        float magnification = hooks::GetZoomMagnification();
        if (ImGui::SliderFloat("Magnification##zoom", &magnification, 1.0f, 16.0f, "%.1fx"))
            hooks::SetZoomMagnification(magnification);

        float scrollStep = hooks::GetZoomScrollStep();
        if (ImGui::SliderFloat("Wheel step##zoom", &scrollStep, 0.1f, 4.0f, "%.1fx"))
            hooks::SetZoomScrollStep(scrollStep);
        if (hooks::IsZoomAvailable())
            ImGui::TextDisabled("Scroll to change magnification; menu may stay open.");
    }
};

struct HitboxesModule : Module {
    static constexpr size_t MaxScannedEntities = 256;
    static constexpr size_t MaxDrawnEntities = 64;

    struct EntitySnapshot {
        AABB box;
        Vec2 rotation{};
        bool hasRotation = false;
        float distanceSquared = 0.0f;
    };

    bool players = true;
    bool mobs = true;
    bool includeSelf = true;
    bool showBoxes = true;
    bool showLookDirection = true;
    float lineLength = 10.0f;
    float boxColor[3] = {1.0f, 1.0f, 1.0f};
    float lookColor[3] = {0.2f, 0.45f, 1.0f};
    std::vector<EntitySnapshot> nearbyEntities;
    std::chrono::steady_clock::time_point lastSample{};
    std::chrono::steady_clock::time_point nextLocalPlayerCheck{};
    std::chrono::microseconds lastSampleDuration{0};
    std::chrono::microseconds lastRenderDuration{0};
    sdk::Player cachedLocalPlayer = 0;
    bool hasCheckedLocalPlayer = false;
    sdk::Player sampledLocalPlayer = 0;
    bool sampledPlayers = true;
    bool sampledMobs = true;
    bool sampledIncludeSelf = true;
    bool sampledLookDirection = true;
    size_t scannedEntities = 0;
    size_t boxesProjected = 0;
    size_t lookLinesProjected = 0;
    size_t outOfRangeEntities = 0;
    size_t invalidPositionEntities = 0;

    HitboxesModule()
        : Module("Hitboxes", "Shows entity hitbox outlines and look direction") {}

    void DrawSettings() override {
        ImGui::Checkbox("Players##hitboxes", &players);
        ImGui::SameLine();
        ImGui::Checkbox("Mobs / projectiles##hitboxes", &mobs);
        ImGui::Checkbox("My player##hitboxes", &includeSelf);
        ImGui::Checkbox("Hitbox outlines##hitboxes", &showBoxes);
        ImGui::Checkbox("Look direction##hitboxes", &showLookDirection);
        if (showLookDirection)
            ImGui::SliderFloat("Look line length##hitboxes", &lineLength,
                               1.0f, 50.0f, "%.0f blocks");
        if (showBoxes)
            ImGui::ColorEdit3("Hitbox color##hitboxes", boxColor,
                              ImGuiColorEditFlags_NoInputs);
        if (showLookDirection)
            ImGui::ColorEdit3("Look direction color##hitboxes", lookColor,
                              ImGuiColorEditFlags_NoInputs);
        ImGui::Text("Actors: %zu%s | nearby: %zu | boxes: %zu | lines: %zu",
                    scannedEntities,
                    scannedEntities >= MaxScannedEntities ? "+" : "",
                    nearbyEntities.size(), boxesProjected, lookLinesProjected);
        ImGui::Text("Scan: %lld us | render: %lld us | range rejected: %zu | invalid: %zu",
                    static_cast<long long>(lastSampleDuration.count()),
                    static_cast<long long>(lastRenderDuration.count()),
                    outOfRangeEntities, invalidPositionEntities);
        if (hasCheckedLocalPlayer && !cachedLocalPlayer)
            ImGui::TextColored({1.0f, 0.55f, 0.3f, 1.0f},
                               "Game client pointer unresolved; this build cannot read Hitboxes.");
        ImGui::TextDisabled("Look lines are blue by default.");
    }

    void Render() override {
        if ((!showBoxes && !showLookDirection) ||
            (!players && !mobs && !includeSelf))
            return;

        auto now = std::chrono::steady_clock::now();
        if (now >= nextLocalPlayerCheck) {
            sdk::Player currentLocalPlayer = sdk::GetLocalPlayer();
            if (currentLocalPlayer != cachedLocalPlayer) {
                cachedLocalPlayer = currentLocalPlayer;
                lastSample = {};
            }
            hasCheckedLocalPlayer = true;
            nextLocalPlayerCheck = now + std::chrono::milliseconds(500);
        }
        auto localPlayer = cachedLocalPlayer;
        if (!localPlayer) {
            nearbyEntities.clear();
            scannedEntities = 0;
            boxesProjected = 0;
            lookLinesProjected = 0;
            lastRenderDuration = std::chrono::microseconds(0);
            return;
        }

        auto sampleInterval = std::max(std::chrono::milliseconds(1000),
                                       std::chrono::duration_cast<std::chrono::milliseconds>(
                                           lastSampleDuration * 4));
        bool refresh = localPlayer != sampledLocalPlayer ||
                       players != sampledPlayers || mobs != sampledMobs ||
                       includeSelf != sampledIncludeSelf ||
                       showLookDirection != sampledLookDirection ||
                       now - lastSample >= sampleInterval;
        if (refresh) {
            auto sampleStart = std::chrono::steady_clock::now();
            nearbyEntities.clear();
            outOfRangeEntities = 0;
            invalidPositionEntities = 0;
            Vec3 localPosition = sdk::GetPosition(localPlayer);
            auto entities = sdk::GetEntities(MaxScannedEntities);
            scannedEntities = entities.size();
            if (includeSelf && players) {
                Vec3 position;
                AABB box = sdk::GetAABB(localPlayer, &position);
                EntitySnapshot snapshot{box, {}, false, 0.0f};
                if (showLookDirection) {
                    snapshot.rotation = sdk::GetRotation(localPlayer);
                    snapshot.hasRotation = true;
                }
                nearbyEntities.push_back(snapshot);
            }
            for (auto entity : entities) {
                if (entity == localPlayer) continue;
                bool isPlayer =
                    mem::Read<int>(entity + cfg::AC_TypeId) == cfg::PlayerTypeId;
                if ((isPlayer && !players) || (!isPlayer && !mobs)) continue;

                Vec3 position;
                AABB box = sdk::GetAABB(entity, &position);
                if (!std::isfinite(position.x) || !std::isfinite(position.y) ||
                    !std::isfinite(position.z)) {
                    ++invalidPositionEntities;
                    continue;
                }
                Vec3 offset = position - localPosition;
                float distanceSquared = offset.x * offset.x +
                                        offset.y * offset.y +
                                        offset.z * offset.z;
                if (!std::isfinite(distanceSquared) ||
                    distanceSquared > 900.0f) {
                    ++outOfRangeEntities;
                    continue;
                }
                if (!std::isfinite(box.min.x) || !std::isfinite(box.max.x) ||
                    !std::isfinite(box.min.y) || !std::isfinite(box.max.y) ||
                    !std::isfinite(box.min.z) || !std::isfinite(box.max.z) ||
                    box.max.x <= box.min.x || box.max.y <= box.min.y ||
                    box.max.z <= box.min.z)
                    continue;

                EntitySnapshot snapshot{box, {}, false, distanceSquared};
                if (showLookDirection) {
                    snapshot.rotation = sdk::GetRotation(entity);
                    snapshot.hasRotation = true;
                }
                nearbyEntities.push_back(snapshot);
            }
            if (nearbyEntities.size() > MaxDrawnEntities) {
                std::partial_sort(
                    nearbyEntities.begin(),
                    nearbyEntities.begin() + MaxDrawnEntities,
                    nearbyEntities.end(),
                    [](const EntitySnapshot& a, const EntitySnapshot& b) {
                        return a.distanceSquared < b.distanceSquared;
                    });
                nearbyEntities.resize(MaxDrawnEntities);
            }
            sampledLocalPlayer = localPlayer;
            sampledPlayers = players;
            sampledMobs = mobs;
            sampledIncludeSelf = includeSelf;
            sampledLookDirection = showLookDirection;
            lastSample = std::chrono::steady_clock::now();
            lastSampleDuration =
                std::chrono::duration_cast<std::chrono::microseconds>(
                    lastSample - sampleStart);
        }

        auto renderStart = std::chrono::steady_clock::now();
        ImVec2 display = ImGui::GetIO().DisplaySize;
        if (display.x <= 0.0f || display.y <= 0.0f) return;
        float fov = hooks::GetLastZoomFov();
        if (!std::isfinite(fov) || fov <= 1.0f || fov >= 179.0f)
            fov = 70.0f;

        CameraProjection camera(sdk::GetEyePosition(localPlayer),
                                sdk::GetRotation(localPlayer), fov, display);
        boxesProjected = 0;
        lookLinesProjected = 0;
        ImDrawList* drawList = ImGui::GetForegroundDrawList();
        ImU32 boxes = ImGui::ColorConvertFloat4ToU32(
            {boxColor[0], boxColor[1], boxColor[2], 1.0f});
        ImU32 look = ImGui::ColorConvertFloat4ToU32(
            {lookColor[0], lookColor[1], lookColor[2], 1.0f});

        for (const auto& entity : nearbyEntities) {
            if (showBoxes && DrawAabb(drawList, camera, entity.box, boxes))
                ++boxesProjected;

            if (showLookDirection && entity.hasRotation) {
                Vec2 rotation = entity.rotation;
                float yaw = rotation.x * 0.017453292519943295f;
                float pitch = rotation.y * 0.017453292519943295f;
                float eyeHeight = entity.box.min.y +
                                  (entity.box.max.y - entity.box.min.y) * 0.85f;
                Vec3 eye{(entity.box.min.x + entity.box.max.x) * 0.5f,
                         eyeHeight,
                         (entity.box.min.z + entity.box.max.z) * 0.5f};
                float cosPitch = std::cos(pitch);
                Vec3 end = eye + Vec3{
                    -std::sin(yaw) * cosPitch,
                    -std::sin(pitch),
                    std::cos(yaw) * cosPitch
                } * lineLength;
                if (camera.DrawSegment(drawList, eye, end, look, 2.0f))
                    ++lookLinesProjected;
            }
        }
        lastRenderDuration =
            std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::steady_clock::now() - renderStart);
    }
};

}

void RegisterModules() {
    Mods().Add(new ZoomModule());
    Mods().Add(new HitboxesModule());
    Mods().Add(new Module("Fly", "Removed; placeholder only"));
    Mods().Add(new Module("Speed", "Removed; placeholder only"));
    Mods().Add(new Module("AutoSprint", "Removed; placeholder only"));
    Mods().Add(new Module("NoFall", "Removed; placeholder only"));
    Mods().Add(new Module("FullBright", "Removed; placeholder only"));
    Mods().Add(new Module("KillAura", "Removed; placeholder only"));
    Mods().Add(new Module("Nuker", "Removed; placeholder only"));
}
'@

Write-File 'src/dllmain.cpp' @'
#include <windows.h>
#include <conio.h>
#include <cstdio>
#include <iterator>

#include "Config.hpp"
#include "Hooks.hpp"
#include "Module.hpp"
#include "SDK.hpp"
#include "modules/Modules.hpp"

static HMODULE g_self   = nullptr;
static bool    g_unload = false;
static constexpr wchar_t kInjectedWindowTitle[] =
    L"BedrockClient [Minecraft Bedrock]v1.0";

static void OpenConsole() {
    AllocConsole();
    FILE* f = nullptr;
    freopen_s(&f, "CONIN$", "r", stdin);
    freopen_s(&f, "CONOUT$", "w", stdout);
    freopen_s(&f, "CONOUT$", "w", stderr);
    SetConsoleTitleW(L"BedrockClient");
}

static void PrintModuleList() {
    printf("\n[BedrockClient] Modules\n");
    for (auto* module : Mods().All()) {
        printf("  %-18s [%c] %s\n", module->name,
               module->key ? static_cast<char>(module->key) : '-',
               module->enabled ? "ON" : "OFF");
    }
    printf("\n");
}

static char ToUpperAscii(char character) {
    return character >= 'a' && character <= 'z'
        ? static_cast<char>(character - 'a' + 'A')
        : character;
}

static bool ModuleNameMatches(const char* command, const char* name) {
    int index = 0;
    while (command[index] && name[index] &&
           ToUpperAscii(command[index]) == ToUpperAscii(name[index]))
        ++index;
    return command[index] == '\0' && name[index] == '\0';
}

static bool ToggleModuleCommand(const char* command, int commandLength) {
    for (auto* module : Mods().All()) {
        bool keyMatches = commandLength == 1 && module->key &&
                          ToUpperAscii(command[0]) == module->key;
        if (keyMatches || ModuleNameMatches(command, module->name)) {
            module->Toggle();
            printf("%s: %s\n", module->name, module->enabled ? "ON" : "OFF");
            return true;
        }
    }
    return false;
}

static DWORD WINAPI Main(LPVOID) {
    OpenConsole();
    printf("[BedrockClient] DLL loaded; initializing inside the current game process...\n");
    fflush(stdout);
    RegisterModules();
    HWND gameWindow = hooks::FindGameWindow();
    if (!gameWindow) {
        printf("[BedrockClient] no visible Minecraft window was found.\n");
        fflush(stdout);
        return 0;
    }
    hooks::g_hwnd = gameWindow;

    if (!hooks::Install()) {
        printf("[BedrockClient] hook install failed.\n");
        fflush(stdout);
        return 0;
    }

    ULONGLONG renderDeadline = GetTickCount64() + 10000;
    while (!hooks::g_imguiReady.load(std::memory_order_acquire) &&
           !g_unload && GetTickCount64() < renderDeadline) {
        if (GetAsyncKeyState(cfg::KEY_UNLOAD) & 0x8000) g_unload = true;
        Sleep(50);
    }

    wchar_t originalWindowTitle[256]{};
    bool windowTitleChanged = false;
    if (hooks::g_imguiReady.load(std::memory_order_acquire)) {
        GetWindowTextW(gameWindow, originalWindowTitle,
                       static_cast<int>(std::size(originalWindowTitle)));
        windowTitleChanged = SetWindowTextW(gameWindow, kInjectedWindowTitle) != FALSE;
        if (windowTitleChanged) {
            printf("[BedrockClient] game window title updated.\n");
        } else {
            printf("[BedrockClient] setting the game window title failed (%lu).\n",
                   GetLastError());
        }
        printf("[BedrockClient] rendering hook is active.\n");
    } else if (!g_unload && !hooks::g_presentSeen.load(std::memory_order_acquire)) {
        printf("[BedrockClient] timed out: Minecraft did not call the Direct3D Present hook.\n");
        printf("[BedrockClient] the DLL loaded, but the rendering hook is not active.\n");
    } else if (!g_unload) {
        printf("[BedrockClient] timed out: Present was called, but the overlay could not initialize; see the diagnostic above.\n");
        printf("[BedrockClient] the DLL loaded, but the rendering hook is not active.\n");
    }

    printf("  M in Minecraft = toggle panel\n");
    printf("  Type M here = list modules\n");
    printf("  Type D here = dump game pointers\n");
    printf("  Type a module name here to toggle it\n");
    printf("  Z in Minecraft = Zoom\n");
    printf("  DELETE = eject\n");
    printf("> ");
    fflush(stdout);
    char command[32]{};
    int commandLength = 0;

    while (!g_unload) {
        if (_kbhit()) {
            int keyStroke = _getch();
            if (keyStroke == 0 || keyStroke == 0xE0) {
                if (_kbhit()) _getch();
            } else if (keyStroke == '\r') {
                command[commandLength] = '\0';
                printf("\n");
                if (commandLength == 1 &&
                    (command[0] == 'm' || command[0] == 'M')) {
                    PrintModuleList();
                } else if (commandLength == 1 &&
                           (command[0] == 'd' || command[0] == 'D')) {
                    sdk::Dump();
                } else if (commandLength > 0 &&
                           ToggleModuleCommand(command, commandLength)) {
                } else if (commandLength > 0) {
                    printf("Unknown command. Use M, D, or a module name/hotkey.\n");
                }
                commandLength = 0;
                printf("> ");
                fflush(stdout);
            } else if (keyStroke == '\b' && commandLength > 0) {
                --commandLength;
                printf("\b \b");
                fflush(stdout);
            } else if (keyStroke >= 32 && keyStroke <= 126 &&
                       commandLength < static_cast<int>(sizeof(command)) - 1) {
                command[commandLength++] = static_cast<char>(keyStroke);
                putchar(keyStroke);
                fflush(stdout);
            }
        }
        if (GetAsyncKeyState(cfg::KEY_UNLOAD) & 0x8000) g_unload = true;
        Sleep(50);
    }

    if (windowTitleChanged && IsWindow(gameWindow))
        SetWindowTextW(gameWindow, originalWindowTitle);
    hooks::Uninstall();
    printf("[BedrockClient] unhooked, ejecting.\n");
    Sleep(400);
    FreeLibraryAndExitThread(g_self, 0);
    return 0;
}

extern "C" BOOL WINAPI DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h;
        DisableThreadLibraryCalls(h);
        CreateThread(nullptr, 0, Main, nullptr, 0, nullptr);
    }
    return TRUE;
}
'@

Write-File 'injector/Injector.cpp' @'
// Usage: Injector.exe <path-to-dll>
#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>

static void ShowResult(const wchar_t* title, const wchar_t* message, UINT icon) {
    MessageBoxW(nullptr, message, title, MB_OK | icon | MB_SETFOREGROUND | MB_TOPMOST);
}

static void ShowWin32Error(const wchar_t* operation, DWORD error) {
    wchar_t message[256]{};
    swprintf_s(message, L"%s failed (error %lu).", operation, error);
    ShowResult(L"Injection failed", message, MB_ICONERROR);
}

static DWORD FindPid(const wchar_t* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    DWORD pid = 0;
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, name) == 0) { pid = pe.th32ProcessID; break; }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

static bool AlreadyInjected(DWORD pid) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
    if (snap == INVALID_HANDLE_VALUE) return false;
    MODULEENTRY32W me{};
    me.dwSize = sizeof(me);
    bool found = false;
    if (Module32FirstW(snap, &me)) {
        do {
            if (_wcsicmp(me.szModule, L"BedrockClient.dll") == 0) { found = true; break; }
        } while (Module32NextW(snap, &me));
    }
    CloseHandle(snap);
    return found;
}

int wmain(int argc, wchar_t** argv) {
    if (argc < 2) {
        const wchar_t* message = L"Usage: Injector.exe <path to BedrockClient.dll>";
        wprintf(L"%s\n", message);
        ShowResult(L"Injection failed", message, MB_ICONERROR);
        return 1;
    }

    wchar_t full[MAX_PATH]{};
    DWORD pathLength = GetFullPathNameW(argv[1], MAX_PATH, full, nullptr);
    if (!pathLength || pathLength >= MAX_PATH) {
        const wchar_t* message = L"The DLL path is invalid or too long.";
        wprintf(L"%s\n", message);
        ShowResult(L"Injection failed", message, MB_ICONERROR);
        return 1;
    }
    if (GetFileAttributesW(full) == INVALID_FILE_ATTRIBUTES) {
        wprintf(L"dll not found: %s\n", full);
        ShowResult(L"Injection failed", L"The DLL file could not be found.", MB_ICONERROR);
        return 1;
    }

    DWORD pid = FindPid(L"Minecraft.Windows.exe");
    if (!pid) {
        const wchar_t* message = L"Minecraft.Windows.exe is not running.";
        wprintf(L"%s\n", message);
        ShowResult(L"Injection failed", message, MB_ICONERROR);
        return 1;
    }
    wprintf(L"found Minecraft.Windows.exe, pid = %lu\n", pid);

    if (AlreadyInjected(pid)) {
        wprintf(L"BedrockClient.dll is already loaded in that process.\n");
        ShowResult(L"Already injected",
                   L"BedrockClient.dll is already loaded in the game. No new injection was performed.",
                   MB_ICONINFORMATION);
        return 1;
    }

    HANDLE proc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!proc) {
        DWORD error = GetLastError();
        wprintf(L"OpenProcess failed (%lu) - run this as Administrator.\n", error);
        ShowWin32Error(L"Opening the game process", error);
        return 1;
    }

    const SIZE_T bytes = (wcslen(full) + 1) * sizeof(wchar_t);
    void* remote = VirtualAllocEx(proc, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote) {
        DWORD error = GetLastError();
        wprintf(L"VirtualAllocEx failed (%lu)\n", error);
        ShowWin32Error(L"Allocating memory in the game process", error);
        CloseHandle(proc);
        return 1;
    }

    SIZE_T bytesWritten = 0;
    BOOL writeSucceeded = WriteProcessMemory(proc, remote, full, bytes, &bytesWritten);
    if (!writeSucceeded || bytesWritten != bytes) {
        DWORD error = writeSucceeded ? ERROR_PARTIAL_COPY : GetLastError();
        wprintf(L"WriteProcessMemory failed (%lu)\n", error);
        ShowWin32Error(L"Writing the DLL path to the game process", error);
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(proc);
        return 1;
    }

    HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
    auto loadLib = k32
        ? reinterpret_cast<LPTHREAD_START_ROUTINE>(GetProcAddress(k32, "LoadLibraryW"))
        : nullptr;
    if (!loadLib) {
        DWORD error = GetLastError();
        wprintf(L"GetProcAddress failed (%lu)\n", error);
        ShowWin32Error(L"Finding LoadLibraryW", error);
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(proc);
        return 1;
    }

    HANDLE th = CreateRemoteThread(proc, nullptr, 0, loadLib, remote, 0, nullptr);
    if (!th) {
        DWORD error = GetLastError();
        wprintf(L"CreateRemoteThread failed (%lu)\n", error);
        ShowWin32Error(L"Starting the DLL load in the game process", error);
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(proc);
        return 1;
    }

    DWORD waitResult = WaitForSingleObject(th, 10000);
    if (waitResult != WAIT_OBJECT_0) {
        DWORD error = waitResult == WAIT_FAILED ? GetLastError() : ERROR_TIMEOUT;
        if (waitResult == WAIT_TIMEOUT) {
            wprintf(L"Timed out waiting for the DLL load to finish.\n");
            ShowResult(L"Injection status unknown",
                       L"The DLL load did not finish within 10 seconds, so injection could not be confirmed.",
                       MB_ICONWARNING);
        } else {
            wprintf(L"Waiting for the DLL load failed (%lu)\n", error);
            ShowWin32Error(L"Waiting for the DLL load", error);
        }
        CloseHandle(th);
        CloseHandle(proc);
        return 1;
    }

    DWORD code = 0;
    if (!GetExitCodeThread(th, &code)) {
        DWORD error = GetLastError();
        wprintf(L"GetExitCodeThread failed (%lu)\n", error);
        ShowWin32Error(L"Checking the DLL load result", error);
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(th);
        CloseHandle(proc);
        return 1;
    }

    if (code == 0) {
        wprintf(L"injection FAILED - check the game console window\n");
        ShowResult(L"Injection failed",
                   L"Windows could not load BedrockClient.dll. Check the DLL and game console for details.",
                   MB_ICONERROR);
    } else {
        wprintf(L"DLL load requested; check the game window title for confirmation. Module base = 0x%lX\n",
                code);
    }

    VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
    CloseHandle(th);
    CloseHandle(proc);
    return code == 0 ? 1 : 0;
}
'@

} else {
    Say "sources left untouched (-SkipSources)"
}

# --------------------------------------------------------------------- build --
Head "3. build"

$buildDir = Join-Path $Root 'build'
& $cmake -B $buildDir -S $Root -G "Visual Studio 17 2022" -A x64
if ($LASTEXITCODE -ne 0) { Write-Host "configure failed" -ForegroundColor Red; exit 1 }

& $cmake --build $buildDir --config Release
if ($LASTEXITCODE -ne 0) { Write-Host "build failed" -ForegroundColor Red; exit 1 }

$dll = Join-Path $buildDir 'Release\BedrockClient.dll'
$inj = Join-Path $buildDir 'Release\Injector.exe'
if (-not (Test-Path $dll)) { Write-Host "dll missing" -ForegroundColor Red; exit 1 }
Say "built $dll"

# --------------------------------------------------------------------- inject --
Head "4. inject"

if ($BuildOnly) { Say "skipped (-BuildOnly)"; exit 0 }

$mc = Get-Process 'Minecraft.Windows' -ErrorAction SilentlyContinue
if (-not $mc) {
    Write-Host "  Minecraft Bedrock is not running." -ForegroundColor Yellow
    Write-Host "  Launch it, get in a world, then run:" -ForegroundColor Yellow
    Write-Host "    `"$inj`" `"$dll`"" -ForegroundColor White
    exit 0
}

if ($isAdmin) {
    & $inj $dll
} else {
    Write-Host "  relaunching injector elevated..." -ForegroundColor Yellow
    Start-Process -FilePath $inj -ArgumentList "`"$dll`"" -Verb RunAs -Wait
}

Write-Host "`nDone. INSERT = menu, DELETE = eject." -ForegroundColor Green