@echo off
setlocal
cd /d "%~dp0"

echo Checking Minecraft Bedrock...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference = 'Stop'; $package = Get-AppxPackage -Name 'Microsoft.MinecraftUWP'; if (-not $package) { Write-Error 'Minecraft for Windows is not installed for this user.'; exit 2 }; $deadline = (Get-Date).AddMinutes(2); $game = Get-Process -Name 'Minecraft.Windows' -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1; if (-not $game) { Write-Host 'Launching Minecraft Bedrock...'; $aumid = $package.PackageFamilyName + '!Game'; Start-Process -FilePath 'explorer.exe' -ArgumentList ('shell:AppsFolder\' + $aumid) }; while (-not $game -and (Get-Date) -lt $deadline) { Start-Sleep -Seconds 2; $game = Get-Process -Name 'Minecraft.Windows' -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1 }; if (-not $game) { Write-Error 'Minecraft did not open a game window within 2 minutes.'; exit 3 }; Write-Host 'Minecraft window is ready.'"
if errorlevel 1 goto finish

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Make.ps1"

:finish
pause
