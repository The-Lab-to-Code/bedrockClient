﻿// Usage: Injector.exe <path-to-dll>
#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>

static void ShowResult(const wchar_t* title, const wchar_t* message, UINT icon) {
    MessageBoxW(nullptr, message, title, MB_OK | icon | MB_SETFOREGROUND | MB_TOPMOST);
}

static void ShowWin32Error(const wchar_t* operation, DWORD error) {
    wchar_t message[256]{};
    swprintf_s(message, L"%s failed (error %lu).", operation, error);
    ShowResult(L"Injection failed", message, MB_ICONERROR);
}

static DWORD FindPid(const wchar_t* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    DWORD pid = 0;
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, name) == 0) { pid = pe.th32ProcessID; break; }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

static bool AlreadyInjected(DWORD pid) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
    if (snap == INVALID_HANDLE_VALUE) return false;
    MODULEENTRY32W me{};
    me.dwSize = sizeof(me);
    bool found = false;
    if (Module32FirstW(snap, &me)) {
        do {
            if (_wcsicmp(me.szModule, L"BedrockClient.dll") == 0) { found = true; break; }
        } while (Module32NextW(snap, &me));
    }
    CloseHandle(snap);
    return found;
}

int wmain(int argc, wchar_t** argv) {
    if (argc < 2) {
        const wchar_t* message = L"Usage: Injector.exe <path to BedrockClient.dll>";
        wprintf(L"%s\n", message);
        ShowResult(L"Injection failed", message, MB_ICONERROR);
        return 1;
    }

    wchar_t full[MAX_PATH]{};
    DWORD pathLength = GetFullPathNameW(argv[1], MAX_PATH, full, nullptr);
    if (!pathLength || pathLength >= MAX_PATH) {
        const wchar_t* message = L"The DLL path is invalid or too long.";
        wprintf(L"%s\n", message);
        ShowResult(L"Injection failed", message, MB_ICONERROR);
        return 1;
    }
    if (GetFileAttributesW(full) == INVALID_FILE_ATTRIBUTES) {
        wprintf(L"dll not found: %s\n", full);
        ShowResult(L"Injection failed", L"The DLL file could not be found.", MB_ICONERROR);
        return 1;
    }

    DWORD pid = FindPid(L"Minecraft.Windows.exe");
    if (!pid) {
        const wchar_t* message = L"Minecraft.Windows.exe is not running.";
        wprintf(L"%s\n", message);
        ShowResult(L"Injection failed", message, MB_ICONERROR);
        return 1;
    }
    wprintf(L"found Minecraft.Windows.exe, pid = %lu\n", pid);

    if (AlreadyInjected(pid)) {
        wprintf(L"BedrockClient.dll is already loaded in that process.\n");
        ShowResult(L"Already injected",
                   L"BedrockClient.dll is already loaded in the game. No new injection was performed.",
                   MB_ICONINFORMATION);
        return 1;
    }

    HANDLE proc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!proc) {
        DWORD error = GetLastError();
        wprintf(L"OpenProcess failed (%lu) - run this as Administrator.\n", error);
        ShowWin32Error(L"Opening the game process", error);
        return 1;
    }

    const SIZE_T bytes = (wcslen(full) + 1) * sizeof(wchar_t);
    void* remote = VirtualAllocEx(proc, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote) {
        DWORD error = GetLastError();
        wprintf(L"VirtualAllocEx failed (%lu)\n", error);
        ShowWin32Error(L"Allocating memory in the game process", error);
        CloseHandle(proc);
        return 1;
    }

    SIZE_T bytesWritten = 0;
    BOOL writeSucceeded = WriteProcessMemory(proc, remote, full, bytes, &bytesWritten);
    if (!writeSucceeded || bytesWritten != bytes) {
        DWORD error = writeSucceeded ? ERROR_PARTIAL_COPY : GetLastError();
        wprintf(L"WriteProcessMemory failed (%lu)\n", error);
        ShowWin32Error(L"Writing the DLL path to the game process", error);
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(proc);
        return 1;
    }

    HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
    auto loadLib = k32
        ? reinterpret_cast<LPTHREAD_START_ROUTINE>(GetProcAddress(k32, "LoadLibraryW"))
        : nullptr;
    if (!loadLib) {
        DWORD error = GetLastError();
        wprintf(L"GetProcAddress failed (%lu)\n", error);
        ShowWin32Error(L"Finding LoadLibraryW", error);
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(proc);
        return 1;
    }

    HANDLE th = CreateRemoteThread(proc, nullptr, 0, loadLib, remote, 0, nullptr);
    if (!th) {
        DWORD error = GetLastError();
        wprintf(L"CreateRemoteThread failed (%lu)\n", error);
        ShowWin32Error(L"Starting the DLL load in the game process", error);
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(proc);
        return 1;
    }

    DWORD waitResult = WaitForSingleObject(th, 10000);
    if (waitResult != WAIT_OBJECT_0) {
        DWORD error = waitResult == WAIT_FAILED ? GetLastError() : ERROR_TIMEOUT;
        if (waitResult == WAIT_TIMEOUT) {
            wprintf(L"Timed out waiting for the DLL load to finish.\n");
            ShowResult(L"Injection status unknown",
                       L"The DLL load did not finish within 10 seconds, so injection could not be confirmed.",
                       MB_ICONWARNING);
        } else {
            wprintf(L"Waiting for the DLL load failed (%lu)\n", error);
            ShowWin32Error(L"Waiting for the DLL load", error);
        }
        CloseHandle(th);
        CloseHandle(proc);
        return 1;
    }

    DWORD code = 0;
    if (!GetExitCodeThread(th, &code)) {
        DWORD error = GetLastError();
        wprintf(L"GetExitCodeThread failed (%lu)\n", error);
        ShowWin32Error(L"Checking the DLL load result", error);
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(th);
        CloseHandle(proc);
        return 1;
    }

    if (code == 0) {
        wprintf(L"injection FAILED - check the game console window\n");
        ShowResult(L"Injection failed",
                   L"Windows could not load BedrockClient.dll. Check the DLL and game console for details.",
                   MB_ICONERROR);
    } else {
        wprintf(L"DLL load requested; check the game window title for confirmation. Module base = 0x%lX\n",
                code);
    }

    VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
    CloseHandle(th);
    CloseHandle(proc);
    return code == 0 ? 1 : 0;
}
