﻿#pragma once
#include <windows.h>
#include <atomic>

namespace hooks {
HWND FindGameWindow();
bool Install();
void Uninstall();
float GetZoomMagnification();
void SetZoomMagnification(float value);
float GetZoomScrollStep();
void SetZoomScrollStep(float value);
bool IsZoomAvailable();
unsigned long long GetFovHookCallCount();
float GetLastZoomFov();
extern HWND g_hwnd;
extern std::atomic_bool g_presentSeen;
extern std::atomic_bool g_imguiReady;
} // namespace hooks
