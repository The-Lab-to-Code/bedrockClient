﻿#pragma once
#include <windows.h>
#include <d3d11.h>
#include <d3d12.h>

namespace gui {
bool Init(HWND hwnd, ID3D11Device* device, ID3D11DeviceContext* context);
bool InitD3D12(HWND hwnd, ID3D12Device* device, int framesInFlight,
               DXGI_FORMAT renderTargetFormat, ID3D12DescriptorHeap* srvHeap,
               D3D12_CPU_DESCRIPTOR_HANDLE fontCpuHandle,
               D3D12_GPU_DESCRIPTOR_HANDLE fontGpuHandle);
void Shutdown();
void NewFrame();
void RenderD3D12(ID3D12GraphicsCommandList* commandList);
void Render();
bool IsMenuOpen();
void ToggleMenu();
} // namespace gui
