﻿#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <cstdint>
#include <cstring>
#include <optional>
#include <string>
#include <vector>

namespace mem {

inline bool IsReadable(uintptr_t addr, size_t size) {
    uintptr_t a = addr;
    while (a < addr + size) {
        MEMORY_BASIC_INFORMATION mbi{};
        if (!VirtualQuery(reinterpret_cast<LPCVOID>(a), &mbi, sizeof(mbi))) return false;
        if (mbi.State != MEM_COMMIT) return false;
        if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return false;
        a = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
    }
    return true;
}

inline bool IsValid(uintptr_t addr, size_t size = 8) {
    return addr > 0x10000 && addr < 0x7FFFFFFFFFFFULL && IsReadable(addr, size);
}

template <typename T> inline T Read(uintptr_t addr) {
    if (!IsReadable(addr, sizeof(T))) return T{};
    return *reinterpret_cast<T*>(addr);
}

template <typename T> inline bool Write(uintptr_t addr, const T& v) {
    if (!IsReadable(addr, sizeof(T))) return false;
    *reinterpret_cast<T*>(addr) = v;
    return true;
}

template <typename T> inline bool WriteProtected(uintptr_t addr, const T& v) {
    DWORD old{};
    if (!VirtualProtect(reinterpret_cast<void*>(addr), sizeof(T),
                        PAGE_EXECUTE_READWRITE, &old)) return false;
    *reinterpret_cast<T*>(addr) = v;
    VirtualProtect(reinterpret_cast<void*>(addr), sizeof(T), old, &old);
    return true;
}

std::optional<MODULEENTRY32W> GetModuleEntry(const wchar_t* name);
uintptr_t GetModuleBase(const wchar_t* name);
size_t    GetModuleSize(const wchar_t* name);
uintptr_t GetMainModuleBase();
size_t    GetMainModuleSize();
std::vector<int> ParsePattern(const char* pattern);
uintptr_t ScanRange(uintptr_t start, size_t size, const std::vector<int>& pat);
uintptr_t ScanInModule(const wchar_t* module, const char* pattern);
uintptr_t ScanMainModule(const char* pattern);
uintptr_t ResolveRip(uintptr_t instrAddr, int dispOffset, int instrLength);
std::string ReadStdString(uintptr_t addr);

} // namespace mem
