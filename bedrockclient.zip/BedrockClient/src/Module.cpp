﻿#include "Module.hpp"

ModuleManager& Mods() {
    static ModuleManager m;
    return m;
}

void ModuleManager::Tick(float dt) {
    for (auto* m : mods_) if (m->enabled) m->Tick(dt);
}

void ModuleManager::Render() {
    for (auto* m : mods_) if (m->enabled) m->Render();
}

void ModuleManager::HandleKey(int vk) {
    for (auto* m : mods_) if (m->key && m->key == vk) m->Toggle();
}
