﻿#include "GUI.hpp"
#include "Config.hpp"
#include "Module.hpp"
#include "SDK.hpp"

#include <imgui.h>
#include <imgui_impl_dx12.h>
#include <imgui_impl_dx11.h>
#include <imgui_impl_win32.h>
#include <cstdio>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace gui {

static bool s_menuOpen = false;
static bool s_ready    = false;
static bool s_initFailureReported = false;
static bool s_dx12 = false;

static void CreateContext() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr;

    ImGui::StyleColorsDark();
    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding = 6.0f;
    st.FrameRounding  = 4.0f;
    st.FramePadding   = ImVec2(6, 4);
}

bool Init(HWND hwnd, ID3D11Device* device, ID3D11DeviceContext* context) {
    CreateContext();
    if (!ImGui_ImplWin32_Init(hwnd)) {
        if (!s_initFailureReported) {
            printf("[BedrockClient] ImGui Win32 backend initialization failed.\n");
            s_initFailureReported = true;
        }
        ImGui::DestroyContext();
        return false;
    }
    if (!ImGui_ImplDX11_Init(device, context)) {
        if (!s_initFailureReported) {
            printf("[BedrockClient] ImGui Direct3D 11 backend initialization failed.\n");
            s_initFailureReported = true;
        }
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        return false;
    }
    s_dx12 = false;
    s_ready = true;
    return true;
}

bool InitD3D12(HWND hwnd, ID3D12Device* device, int framesInFlight,
               DXGI_FORMAT renderTargetFormat, ID3D12DescriptorHeap* srvHeap,
               D3D12_CPU_DESCRIPTOR_HANDLE fontCpuHandle,
               D3D12_GPU_DESCRIPTOR_HANDLE fontGpuHandle) {
    CreateContext();
    if (!ImGui_ImplWin32_Init(hwnd)) {
        if (!s_initFailureReported) {
            printf("[BedrockClient] ImGui Win32 backend initialization failed.\n");
            s_initFailureReported = true;
        }
        ImGui::DestroyContext();
        return false;
    }
    if (!ImGui_ImplDX12_Init(device, framesInFlight, renderTargetFormat, srvHeap,
                             fontCpuHandle, fontGpuHandle)) {
        if (!s_initFailureReported) {
            printf("[BedrockClient] ImGui Direct3D 12 backend initialization failed.\n");
            s_initFailureReported = true;
        }
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        return false;
    }
    s_dx12 = true;
    s_ready = true;
    return true;
}

void Shutdown() {
    if (!s_ready) return;
    if (s_dx12) ImGui_ImplDX12_Shutdown();
    else ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    s_ready = false;
}

void NewFrame() {
    if (s_dx12) ImGui_ImplDX12_NewFrame();
    else ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
}

void RenderD3D12(ID3D12GraphicsCommandList* commandList) {
    ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), commandList);
}

bool IsMenuOpen() { return s_menuOpen; }
void ToggleMenu() { s_menuOpen = !s_menuOpen; }

static void RenderWatermark() {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const char* text = "BedrockClient";
    ImVec2 sz = ImGui::CalcTextSize(text);
    dl->AddRectFilled({9, 9}, {19 + sz.x, 19 + sz.y}, IM_COL32(15, 15, 20, 190), 4.0f);
    dl->AddText({14, 14}, IM_COL32(255, 255, 255, 230), text);
    char fps[64];
    snprintf(fps, sizeof(fps), "%.0f fps", ImGui::GetIO().Framerate);
    dl->AddText({14, 14 + sz.y + 4}, IM_COL32(150, 200, 255, 220), fps);
}

static void RenderArrayList() {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    ImGuiIO& io = ImGui::GetIO();
    float y = 14.0f;
    for (auto* m : Mods().All()) {
        if (!m->enabled) continue;
        ImVec2 sz = ImGui::CalcTextSize(m->name);
        float x = io.DisplaySize.x - sz.x - 14.0f;
        dl->AddRectFilled({x - 6, y - 3}, {x + sz.x + 6, y + sz.y + 3},
                          IM_COL32(15, 15, 20, 170), 3.0f);
        dl->AddText({x + 1, y + 1}, IM_COL32(0, 0, 0, 200), m->name);
        dl->AddText({x, y}, ImGui::ColorConvertFloat4ToU32(
                     {Mods().accent[0], Mods().accent[1], Mods().accent[2], 1.0f}), m->name);
        y += sz.y + 6.0f;
    }
}

static void RenderMenu() {
    if (!s_menuOpen) return;
    ImGui::SetNextWindowSize({440, 420}, ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos({60, 60}, ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("BedrockClient", &s_menuOpen)) { ImGui::End(); return; }

    ImGui::TextColored({Mods().accent[0], Mods().accent[1], Mods().accent[2], 1.0f},
                       "BedrockClient   |   %.0f fps", ImGui::GetIO().Framerate);
    ImGui::Separator();
    ImGui::Spacing();

    for (auto* m : Mods().All()) {
        ImGui::Checkbox(m->name, &m->enabled);
        if (ImGui::IsItemHovered() && m->desc) ImGui::SetTooltip("%s", m->desc);
        if (m->key) {
            ImGui::SameLine(ImGui::GetWindowWidth() - 60);
            ImGui::TextDisabled("[%c]", (char)m->key);
        }
        if (m->enabled) {
            ImGui::Indent(18.0f);
            m->DrawSettings();
            ImGui::Unindent(18.0f);
        }
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::ColorEdit3("Accent", Mods().accent, ImGuiColorEditFlags_NoInputs);
    ImGui::SameLine();
    if (ImGui::Button("Dump pointers")) sdk::Dump();
    ImGui::End();
}

void Render() {
    RenderWatermark();
    RenderArrayList();
    RenderMenu();
}

} // namespace gui
