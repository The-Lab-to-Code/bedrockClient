﻿#include "SDK.hpp"
#include "Memory.hpp"
#include "Config.hpp"
#include <cmath>
#include <cstdio>
#include <mutex>

float Vec3::length() const { return std::sqrt(x * x + y * y + z * z); }

Vec3 Vec3::normalized() const {
    float l = length();
    return l > 1e-6f ? Vec3{x / l, y / l, z / l} : Vec3{};
}

namespace sdk {

uintptr_t GetClientInstance() {
    static uintptr_t addr = 0;
    static std::once_flag scanOnce;
    std::call_once(scanOnce, []() {
        uintptr_t hit = mem::ScanMainModule(cfg::Sig_ClientInstance);
        if (hit) addr = mem::ResolveRip(hit, 3, 7);
    });
    return addr;
}

Player GetLocalPlayer() {
    uintptr_t ci = GetClientInstance();
    if (!mem::IsValid(ci)) return 0;
    Player p = mem::Read<Player>(ci + cfg::CI_LocalPlayer);
    return mem::IsValid(p, 0x100) ? p : 0;
}

Level GetLevel() {
    uintptr_t ci = GetClientInstance();
    if (!mem::IsValid(ci)) return 0;
    Level l = mem::Read<Level>(ci + cfg::CI_Level);
    return mem::IsValid(l, 0x100) ? l : 0;
}

uintptr_t GetGameMode() {
    uintptr_t ci = GetClientInstance();
    if (!mem::IsValid(ci)) return 0;
    uintptr_t gm = mem::Read<uintptr_t>(ci + cfg::CI_GameMode);
    return mem::IsValid(gm, 0x100) ? gm : 0;
}

Vec3 GetPosition(Actor a) { return mem::Read<Vec3>(a + cfg::AC_Position); }
void SetPosition(Actor a, const Vec3& p) { mem::Write(a + cfg::AC_Position, p); }
Vec3 GetVelocity(Actor a) { return mem::Read<Vec3>(a + cfg::AC_Velocity); }
void SetVelocity(Actor a, const Vec3& v) { mem::Write(a + cfg::AC_Velocity, v); }
bool IsOnGround(Actor a) { return mem::Read<bool>(a + cfg::AC_OnGround); }
void SetOnGround(Actor a, bool v) { mem::Write(a + cfg::AC_OnGround, v); }
bool IsSprinting(Actor a) { return mem::Read<bool>(a + cfg::AC_Sprinting); }
void SetSprinting(Actor a, bool v) { mem::Write(a + cfg::AC_Sprinting, v); }
bool IsDead(Actor a) { return mem::Read<bool>(a + cfg::AC_Dead); }
std::string GetNameTag(Actor a) { return mem::ReadStdString(a + cfg::AC_NameTag); }
bool IsLocalPlayer(Actor a) { return a == GetLocalPlayer(); }

AABB GetAABB(Actor a, Vec3* position) {
    Vec3 p = GetPosition(a);
    if (position) *position = p;
    return {{p.x - 0.3f, p.y,        p.z - 0.3f},
            {p.x + 0.3f, p.y + 1.8f, p.z + 0.3f}};
}

std::vector<Actor> GetEntities(size_t maxCount) {
    std::vector<Actor> out;
    Level lv = GetLevel();
    if (!lv) return out;

    auto* begin = mem::Read<Actor*>(lv + cfg::LV_EntityList);
    auto* end   = mem::Read<Actor*>(lv + cfg::LV_EntityList + sizeof(void*));
    if (!begin || !end || end < begin) return out;

    size_t count = static_cast<size_t>(end - begin);
    if (count > 8192) return out;
    if (count > maxCount) count = maxCount;
    if (!mem::IsValid(reinterpret_cast<uintptr_t>(begin), count * sizeof(void*)))
        return out;

    out.reserve(count);
    for (size_t i = 0; i < count; ++i) {
        Actor a = begin[i];
        if (mem::IsValid(a, 0x400)) out.push_back(a);
    }
    return out;
}

Vec2 GetRotation(Player p) {
    return {mem::Read<float>(p + cfg::AC_Yaw), mem::Read<float>(p + cfg::AC_Pitch)};
}

Vec3 GetEyePosition(Player p) {
    Vec3 pos = GetPosition(p);
    pos.y += 1.62f;
    return pos;
}

void Attack(Actor target) {
    uintptr_t gm = GetGameMode();
    if (!gm) return;
    auto vtbl = *reinterpret_cast<void***>(gm);
    using Fn = void(__fastcall*)(void*, void*);
    reinterpret_cast<Fn>(vtbl[cfg::VT_GameMode_attack])(
        reinterpret_cast<void*>(gm), reinterpret_cast<void*>(target));
}

void DestroyBlock(const Vec3& c) {
    uintptr_t gm = GetGameMode();
    if (!gm) return;
    auto vtbl = *reinterpret_cast<void***>(gm);
    using Fn = bool(__fastcall*)(void*, const Vec3*);
    reinterpret_cast<Fn>(vtbl[cfg::VT_GameMode_destroyBlock])(
        reinterpret_cast<void*>(gm), &c);
}

void Dump() {
    printf("\n===== BedrockClient dump =====\n");
    uintptr_t hit = mem::ScanMainModule(cfg::Sig_ClientInstance);
    printf("main module    : 0x%llX (%zu bytes)\n",
           static_cast<unsigned long long>(mem::GetMainModuleBase()),
           mem::GetMainModuleSize());
    printf("sig hit        : 0x%llX\n", (unsigned long long)hit);
    if (!hit)
        printf("!! client-instance signature did not match this game build\n");
    printf("clientInstance : 0x%llX\n", (unsigned long long)GetClientInstance());
    printf("localPlayer    : 0x%llX\n", (unsigned long long)GetLocalPlayer());
    printf("level          : 0x%llX\n", (unsigned long long)GetLevel());
    printf("gameMode       : 0x%llX\n", (unsigned long long)GetGameMode());

    Player lp = GetLocalPlayer();
    if (lp) {
        Vec3 p = GetPosition(lp);
        Vec3 v = GetVelocity(lp);
        printf("player pos     : %.2f %.2f %.2f\n", p.x, p.y, p.z);
        printf("player vel     : %.3f %.3f %.3f\n", v.x, v.y, v.z);
        printf("onGround       : %d\n", (int)IsOnGround(lp));
        printf("nameTag        : '%s'\n", GetNameTag(lp).c_str());
    } else {
        printf("!! localPlayer null - check CI_LocalPlayer\n");
    }

    auto ents = GetEntities();
    printf("entity count   : %zu\n", ents.size());
    for (size_t i = 0; i < ents.size() && i < 8; ++i) {
        Vec3 p = GetPosition(ents[i]);
        printf("  [%zu] 0x%llX type=%d pos=%.1f %.1f %.1f '%s'\n",
               i, (unsigned long long)ents[i],
               mem::Read<int>(ents[i] + cfg::AC_TypeId),
               p.x, p.y, p.z, GetNameTag(ents[i]).c_str());
    }
    printf("==============================\n\n");
}

} // namespace sdk
