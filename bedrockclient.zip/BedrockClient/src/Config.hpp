﻿#pragma once
#define NOMINMAX
#include <windows.h>
#include <cstdint>

// Every magic number lives here. Verify with the "Dump pointers" button,
// then edit this file and re-run Make.ps1 -SkipSources.

namespace cfg {

inline const char* Sig_ClientInstance =
    "48 8B 0D ? ? ? ? 48 8B 01 48 85 C0 74 ? 48 8B 88";
inline const char* Sig_GetFov[] = {
    "56 57 53 48 83 EC ? 44 0F 29 44 24 ? 0F 29 7C 24 ? 0F 29 74 24 ? 44 89 C3 0F 28 F1",
    "4C 8B DC 53 48 83 EC ? 0F 29 74 24",
    "? ? ? ? ? ? ? 48 89 ? ? 57 48 81 EC ? ? ? ? 0F 29 ? ? 0F 29 ? ? 44 0F ? ? ? 44 0F ? ? ? 48 8B ? ? ? ? ? 48 33 ? 48 89 ? ? ? 41 0F",
    "48 8B ? 48 89 ? ? 48 89 ? ? 57 48 81 EC ? ? ? ? 0F 29 ? ? 0F 29 ? ? 44 0F ? ? ? 44 0F ? ? ? 48 8B ? ? ? ? ? 48 33 ? 48 89 ? ? ? 41 0F"
};

constexpr uintptr_t CI_LocalPlayer   = 0x0A8;
constexpr uintptr_t CI_Level         = 0x150;
constexpr uintptr_t CI_GameMode      = 0x160;
constexpr uintptr_t CI_MinecraftGame = 0x0D8;

constexpr uintptr_t MG_Options = 0x0F0;
constexpr uintptr_t OPT_Gamma  = 0x1E0;

constexpr uintptr_t LV_EntityList = 0x2B0;

constexpr uintptr_t AC_Position     = 0x4A0;
constexpr uintptr_t AC_Velocity     = 0x3F0;
constexpr uintptr_t AC_OnGround     = 0x1F8;
constexpr uintptr_t AC_Sprinting    = 0x2C8;
constexpr uintptr_t AC_FallDistance = 0x3D0;
constexpr uintptr_t AC_NameTag      = 0x2F0;
constexpr uintptr_t AC_TypeId       = 0x1C0;
constexpr uintptr_t AC_Dead         = 0x1D0;
constexpr uintptr_t AC_Yaw          = 0x2A0;
constexpr uintptr_t AC_Pitch        = 0x2A4;

constexpr int VT_GameMode_attack       = 0x0C;
constexpr int VT_GameMode_destroyBlock = 0x0A;

constexpr float FlySpeed      = 1.4f;
constexpr float SpeedValue    = 1.6f;
constexpr float AuraRange     = 4.2f;
constexpr float AuraCPS       = 9.0f;
constexpr float NukerRange    = 4.0f;
constexpr int   NukerPerFrame = 6;
constexpr int   PlayerTypeId  = 319;

constexpr int KEY_MENU   = 'M';
constexpr int KEY_UNLOAD = VK_DELETE;

} // namespace cfg
