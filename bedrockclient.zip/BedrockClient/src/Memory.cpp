﻿#include "Memory.hpp"
#include <tlhelp32.h>
#include <cstdlib>

namespace mem {

std::optional<MODULEENTRY32W> GetModuleEntry(const wchar_t* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32,
                                           GetCurrentProcessId());
    if (snap == INVALID_HANDLE_VALUE) return std::nullopt;
    MODULEENTRY32W me{};
    me.dwSize = sizeof(me);
    std::optional<MODULEENTRY32W> out;
    if (Module32FirstW(snap, &me)) {
        do {
            if (_wcsicmp(me.szModule, name) == 0) { out = me; break; }
        } while (Module32NextW(snap, &me));
    }
    CloseHandle(snap);
    return out;
}

uintptr_t GetModuleBase(const wchar_t* name) {
    auto e = GetModuleEntry(name);
    return e ? reinterpret_cast<uintptr_t>(e->modBaseAddr) : 0;
}

size_t GetModuleSize(const wchar_t* name) {
    auto e = GetModuleEntry(name);
    return e ? static_cast<size_t>(e->modBaseSize) : 0;
}

static bool GetMainModuleRange(uintptr_t& base, size_t& size) {
    HMODULE module = GetModuleHandleW(nullptr);
    if (!module) return false;

    base = reinterpret_cast<uintptr_t>(module);
    IMAGE_DOS_HEADER dos = Read<IMAGE_DOS_HEADER>(base);
    if (dos.e_magic != IMAGE_DOS_SIGNATURE || dos.e_lfanew <= 0)
        return false;

    uintptr_t ntAddress = base + static_cast<uintptr_t>(dos.e_lfanew);
    if (ntAddress < base) return false;
    IMAGE_NT_HEADERS64 nt = Read<IMAGE_NT_HEADERS64>(ntAddress);
    if (nt.Signature != IMAGE_NT_SIGNATURE ||
        nt.OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC ||
        nt.OptionalHeader.SizeOfImage == 0)
        return false;

    size = nt.OptionalHeader.SizeOfImage;
    return true;
}

uintptr_t GetMainModuleBase() {
    uintptr_t base = 0;
    size_t size = 0;
    return GetMainModuleRange(base, size) ? base : 0;
}

size_t GetMainModuleSize() {
    uintptr_t base = 0;
    size_t size = 0;
    return GetMainModuleRange(base, size) ? size : 0;
}

std::vector<int> ParsePattern(const char* pattern) {
    std::vector<int> bytes;
    const char* p = pattern;
    while (*p) {
        while (*p == ' ') ++p;
        if (!*p) break;
        if (*p == '?') {
            bytes.push_back(-1);
            while (*p && *p != ' ') ++p;
            continue;
        }
        char* end = nullptr;
        bytes.push_back(static_cast<int>(strtol(p, &end, 16)));
        p = end;
    }
    return bytes;
}

uintptr_t ScanRange(uintptr_t start, size_t size, const std::vector<int>& pat) {
    if (pat.empty() || size < pat.size()) return 0;
    const uintptr_t end = start + size;
    if (end < start) return 0;

    uintptr_t cursor = start;
    while (cursor < end) {
        MEMORY_BASIC_INFORMATION mbi{};
        if (!VirtualQuery(reinterpret_cast<LPCVOID>(cursor), &mbi, sizeof(mbi)))
            return 0;
        uintptr_t regionStart = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
        uintptr_t regionEnd = regionStart + mbi.RegionSize;
        if (regionEnd <= cursor) return 0;
        uintptr_t scanEnd = (regionEnd < end) ? regionEnd : end;

        DWORD protection = mbi.Protect & 0xff;
        bool readableProtection =
            protection == PAGE_READONLY ||
            protection == PAGE_READWRITE ||
            protection == PAGE_WRITECOPY ||
            protection == PAGE_EXECUTE_READ ||
            protection == PAGE_EXECUTE_READWRITE ||
            protection == PAGE_EXECUTE_WRITECOPY;
        if (mbi.State == MEM_COMMIT && readableProtection &&
            !(mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) &&
            scanEnd - cursor >= pat.size()) {
            uintptr_t last = scanEnd - pat.size();
            for (uintptr_t address = cursor; address <= last; ++address) {
                bool matched = true;
                for (size_t i = 0; i < pat.size(); ++i) {
                    if (pat[i] != -1 &&
                        *reinterpret_cast<const uint8_t*>(address + i) !=
                            static_cast<uint8_t>(pat[i])) {
                        matched = false;
                        break;
                    }
                }
                if (matched) return address;
            }
        }
        cursor = scanEnd;
    }
    return 0;
}

uintptr_t ScanInModule(const wchar_t* module, const char* pattern) {
    uintptr_t base = GetModuleBase(module);
    size_t    size = GetModuleSize(module);
    if (!base || !size) return 0;
    return ScanRange(base, size, ParsePattern(pattern));
}

uintptr_t ScanMainModule(const char* pattern) {
    uintptr_t base = 0;
    size_t imageSize = 0;
    if (!GetMainModuleRange(base, imageSize)) return 0;

    IMAGE_DOS_HEADER dos = Read<IMAGE_DOS_HEADER>(base);
    uintptr_t ntAddress = base + static_cast<uintptr_t>(dos.e_lfanew);
    IMAGE_NT_HEADERS64 nt = Read<IMAGE_NT_HEADERS64>(ntAddress);
    uintptr_t sectionAddress = ntAddress + sizeof(DWORD) +
        sizeof(IMAGE_FILE_HEADER) + nt.FileHeader.SizeOfOptionalHeader;

    std::vector<int> parsed = ParsePattern(pattern);
    for (WORD i = 0; i < nt.FileHeader.NumberOfSections; ++i) {
        uintptr_t headerAddress = sectionAddress +
            static_cast<uintptr_t>(i) * sizeof(IMAGE_SECTION_HEADER);
        IMAGE_SECTION_HEADER section = Read<IMAGE_SECTION_HEADER>(headerAddress);
        if (std::strncmp(reinterpret_cast<const char*>(section.Name), ".text", 5) != 0)
            continue;

        size_t sectionSize = section.Misc.VirtualSize;
        if (sectionSize == 0) sectionSize = section.SizeOfRawData;
        if (section.VirtualAddress >= imageSize ||
            sectionSize > imageSize - section.VirtualAddress)
            return 0;

        return ScanRange(base + section.VirtualAddress, sectionSize, parsed);
    }
    return 0;
}

uintptr_t ResolveRip(uintptr_t instrAddr, int dispOffset, int instrLength) {
    if (!instrAddr) return 0;
    int32_t disp = Read<int32_t>(instrAddr + dispOffset);
    return instrAddr + instrLength + disp;
}

std::string ReadStdString(uintptr_t addr) {
    if (!IsValid(addr, 0x20)) return {};
    size_t size = Read<size_t>(addr + 0x10);
    if (size == 0 || size > 0x400) return {};
    const char* data = (size < 16) ? reinterpret_cast<const char*>(addr)
                                   : Read<const char*>(addr);
    if (!IsValid(reinterpret_cast<uintptr_t>(data), size)) return {};
    return std::string(data, size);
}

} // namespace mem
