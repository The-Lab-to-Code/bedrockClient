﻿#include "Hooks.hpp"
#include "Config.hpp"
#include "GUI.hpp"
#include "Memory.hpp"
#include "Module.hpp"

#include <imgui.h>
#include <imgui_impl_dx11.h>
#include <imgui_impl_win32.h>
#include <MinHook.h>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <thread>
#include <d3d11.h>
#include <d3d12.h>
#include <dxgi1_4.h>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace hooks {

static ID3D11Device*           g_device  = nullptr;
static ID3D11DeviceContext*    g_context = nullptr;
static ID3D11RenderTargetView* g_rtv     = nullptr;
static IDXGISwapChain*         g_swap    = nullptr;

using Present_t       = HRESULT(WINAPI*)(IDXGISwapChain*, UINT, UINT);
using ResizeBuffers_t = HRESULT(WINAPI*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
using WndProc_t       = LRESULT(CALLBACK*)(HWND, UINT, WPARAM, LPARAM);
using GetFov_t        = float(__fastcall*)(void*, float, void*, void*);
using ExecuteCommandLists_t =
    void(STDMETHODCALLTYPE*)(ID3D12CommandQueue*, UINT, ID3D12CommandList* const*);

static Present_t       oPresent       = nullptr;
static ResizeBuffers_t oResizeBuffers = nullptr;
static WndProc_t       oWndProc       = nullptr;
static GetFov_t        oGetFov        = nullptr;
static ExecuteCommandLists_t oExecuteCommandLists = nullptr;
static std::atomic_flag g_imguiInitializing = ATOMIC_FLAG_INIT;
static std::atomic_bool g_initFailureReported{false};
static std::atomic_bool g_deviceFailureReported{false};
static std::atomic_bool g_d3d12QueueHookInstalled{false};
static std::atomic_bool g_d3d12QueueWaitReported{false};
static std::atomic_bool g_fovHookAvailable{false};
static std::atomic_bool g_zoomActive{false};
static std::atomic<float> g_zoomMagnification{2.0f};
static std::atomic<float> g_zoomScrollStep{0.5f};
static std::atomic<unsigned long long> g_fovHookCallCount{0};
static std::atomic<float> g_lastZoomFov{0.0f};
static std::atomic<unsigned int> g_activeHookCalls{0};
static std::atomic_bool g_shuttingDown{false};

struct HookCallGuard {
    HookCallGuard() {
        g_activeHookCalls.fetch_add(1, std::memory_order_acq_rel);
    }
    ~HookCallGuard() {
        g_activeHookCalls.fetch_sub(1, std::memory_order_acq_rel);
    }
};

static constexpr UINT kMaxBackBuffers = 8;
struct D3D12Frame {
    ID3D12CommandAllocator* allocator = nullptr;
    UINT64 fenceValue = 0;
};

static ID3D12Device* g_device12 = nullptr;
static std::atomic<ID3D12CommandQueue*> g_queue12{nullptr};
static ID3D12DescriptorHeap* g_rtvHeap12 = nullptr;
static ID3D12DescriptorHeap* g_srvHeap12 = nullptr;
static ID3D12GraphicsCommandList* g_commandList12 = nullptr;
static ID3D12Fence* g_fence12 = nullptr;
static HANDLE g_fenceEvent12 = nullptr;
static UINT64 g_nextFenceValue12 = 0;
static UINT g_rtvDescriptorSize12 = 0;
static UINT g_bufferCount12 = 0;
static UINT g_frameCursor12 = 0;
static D3D12Frame g_frames12[kMaxBackBuffers]{};
static ID3D12Resource* g_backBuffers12[kMaxBackBuffers]{};
static DXGI_FORMAT g_renderTargetFormat12 = DXGI_FORMAT_UNKNOWN;
static std::atomic_bool g_usingD3D12{false};

HWND g_hwnd       = nullptr;
std::atomic_bool g_presentSeen{false};
std::atomic_bool g_imguiReady{false};
static auto g_last = std::chrono::steady_clock::now();
static bool g_keyDown[256]{};

static void SyncZoomActive();
static bool ZoomEnabled();

static void PollHotkeys() {
    HWND foreground = GetForegroundWindow();
    DWORD foregroundPid = 0;
    if (foreground) GetWindowThreadProcessId(foreground, &foregroundPid);
    bool focused = foregroundPid == GetCurrentProcessId() && foreground != GetConsoleWindow();
    auto pollKey = [focused](int vk) {
        if (vk <= 0 || vk >= 256) return;
        bool down = (GetAsyncKeyState(vk) & 0x8000) != 0;
        if (down && !g_keyDown[vk] && focused) {
            if (vk == cfg::KEY_MENU) gui::ToggleMenu();
            else                     Mods().HandleKey(vk);
        }
        g_keyDown[vk] = down;
    };
    pollKey(cfg::KEY_MENU);
    for (auto* module : Mods().All())
        if (module->key != cfg::KEY_MENU) pollKey(module->key);
    SyncZoomActive();
}

static void SyncZoomActive() {
    bool enabled = false;
    for (auto* module : Mods().All()) {
        if (std::strcmp(module->name, "Zoom") == 0) {
            enabled = module->enabled;
            break;
        }
    }
    g_zoomActive.store(enabled, std::memory_order_release);
}

float GetZoomMagnification() {
    return g_zoomMagnification.load(std::memory_order_acquire);
}

void SetZoomMagnification(float value) {
    g_zoomMagnification.store(std::clamp(value, 1.0f, 16.0f),
                              std::memory_order_release);
}

float GetZoomScrollStep() {
    return g_zoomScrollStep.load(std::memory_order_acquire);
}

bool IsZoomAvailable() {
    return g_fovHookAvailable.load(std::memory_order_acquire);
}

unsigned long long GetFovHookCallCount() {
    return g_fovHookCallCount.load(std::memory_order_acquire);
}

float GetLastZoomFov() {
    return g_lastZoomFov.load(std::memory_order_acquire);
}

void SetZoomScrollStep(float value) {
    g_zoomScrollStep.store(std::clamp(value, 0.1f, 4.0f),
                           std::memory_order_release);
}

static float __fastcall GetFov_h(void* self, float arg, void* a3, void* a4) {
    HookCallGuard guard;
    float fov = oGetFov(self, arg, a3, a4);
    g_fovHookCallCount.fetch_add(1, std::memory_order_relaxed);
    if (!std::isfinite(fov) || fov <= 1.0f || fov >= 179.0f) {
        g_lastZoomFov.store(fov, std::memory_order_release);
        return fov;
    }
    if (!g_zoomActive.load(std::memory_order_acquire)) {
        g_lastZoomFov.store(fov, std::memory_order_release);
        return fov;
    }

    constexpr float radiansPerDegree = 3.14159265358979323846f / 180.0f;
    float magnification = g_zoomMagnification.load(std::memory_order_acquire);
    float zoomedFov = 2.0f * std::atan(
        std::tan(fov * radiansPerDegree * 0.5f) / magnification) /
        radiansPerDegree;
    g_lastZoomFov.store(zoomedFov, std::memory_order_release);
    return zoomedFov;
}

HWND FindGameWindow() {
    struct Ctx { DWORD pid; HWND best; LONG area; };
    Ctx ctx{GetCurrentProcessId(), nullptr, 0};
    EnumWindows([](HWND hw, LPARAM lp) -> BOOL {
        auto* c = reinterpret_cast<Ctx*>(lp);
        DWORD pid = 0;
        GetWindowThreadProcessId(hw, &pid);
        if (pid != c->pid || hw == GetConsoleWindow() || !IsWindowVisible(hw))
            return TRUE;
        RECT r{};
        GetClientRect(hw, &r);
        LONG area = (r.right - r.left) * (r.bottom - r.top);
        if (area > c->area) { c->area = area; c->best = hw; }
        return TRUE;
    }, reinterpret_cast<LPARAM>(&ctx));
    return ctx.best;
}

static bool CreateRTV() {
    ID3D11Texture2D* back = nullptr;
    HRESULT result = g_swap->GetBuffer(0, __uuidof(ID3D11Texture2D),
                                       reinterpret_cast<void**>(&back));
    if (FAILED(result) || !back) return false;
    result = g_device->CreateRenderTargetView(back, nullptr, &g_rtv);
    back->Release();
    return SUCCEEDED(result) && g_rtv;
}

static void ReleaseD3DResources() {
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    if (g_context) { g_context->Release(); g_context = nullptr; }
    if (g_device) { g_device->Release(); g_device = nullptr; }
}

static void STDMETHODCALLTYPE ExecuteCommandLists_h(
    ID3D12CommandQueue* queue, UINT count, ID3D12CommandList* const* lists) {
    HookCallGuard guard;
    if (g_shuttingDown.load(std::memory_order_acquire)) {
        oExecuteCommandLists(queue, count, lists);
        return;
    }
    if (g_device12 && queue &&
        g_queue12.load(std::memory_order_acquire) == nullptr) {
        D3D12_COMMAND_QUEUE_DESC queueDesc = queue->GetDesc();
        if (queueDesc.Type == D3D12_COMMAND_LIST_TYPE_DIRECT) {
            ID3D12Device* queueDevice = nullptr;
            HRESULT result = queue->GetDevice(
                __uuidof(ID3D12Device), reinterpret_cast<void**>(&queueDevice));
            if (SUCCEEDED(result) && queueDevice == g_device12) {
                queue->AddRef();
                ID3D12CommandQueue* expected = nullptr;
                if (g_queue12.compare_exchange_strong(
                        expected, queue, std::memory_order_release,
                        std::memory_order_relaxed)) {
                    printf("[BedrockClient] captured Minecraft's Direct3D 12 command queue.\n");
                    fflush(stdout);
                } else {
                    queue->Release();
                }
            }
            if (queueDevice) queueDevice->Release();
        }
    }
    oExecuteCommandLists(queue, count, lists);
}

static bool InstallD3D12QueueCapture() {
    if (g_d3d12QueueHookInstalled.load(std::memory_order_acquire)) return true;

    D3D12_COMMAND_QUEUE_DESC desc{};
    desc.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
    ID3D12CommandQueue* temporaryQueue = nullptr;
    HRESULT result = g_device12->CreateCommandQueue(
        &desc, __uuidof(ID3D12CommandQueue),
        reinterpret_cast<void**>(&temporaryQueue));
    if (FAILED(result) || !temporaryQueue) {
        printf("[BedrockClient] could not create a Direct3D 12 queue capture target (0x%08lX).\n",
               static_cast<unsigned long>(result));
        fflush(stdout);
        return false;
    }
    void** vtable = *reinterpret_cast<void***>(temporaryQueue);
    void* target = vtable[10];
    MH_STATUS status = MH_CreateHook(
        target, ExecuteCommandLists_h,
        reinterpret_cast<void**>(&oExecuteCommandLists));
    if (status == MH_OK) status = MH_EnableHook(target);
    temporaryQueue->Release();
    if (status != MH_OK) {
        printf("[BedrockClient] could not hook Direct3D 12 command queue submissions (%d).\n",
               static_cast<int>(status));
        fflush(stdout);
        return false;
    }
    g_d3d12QueueHookInstalled.store(true, std::memory_order_release);
    printf("[BedrockClient] waiting to capture Minecraft's Direct3D 12 command queue...\n");
    fflush(stdout);
    return true;
}

static void ReleaseD3D12BackBuffers() {
    for (UINT i = 0; i < kMaxBackBuffers; ++i) {
        if (g_backBuffers12[i]) {
            g_backBuffers12[i]->Release();
            g_backBuffers12[i] = nullptr;
        }
        if (g_frames12[i].allocator) {
            g_frames12[i].allocator->Release();
            g_frames12[i].allocator = nullptr;
        }
        g_frames12[i].fenceValue = 0;
    }
    if (g_rtvHeap12) {
        g_rtvHeap12->Release();
        g_rtvHeap12 = nullptr;
    }
    g_bufferCount12 = 0;
}

static bool WaitForD3D12Fence(UINT64 value);
static void ReleaseD3D12Renderer();

static bool CreateD3D12BackBuffers(IDXGISwapChain* swapChain,
                                   const DXGI_SWAP_CHAIN_DESC& swapDesc) {
    UINT count = swapDesc.BufferCount;
    if (!count || count > kMaxBackBuffers) {
        printf("[BedrockClient] unsupported Direct3D 12 back-buffer count: %u.\n", count);
        fflush(stdout);
        return false;
    }

    D3D12_DESCRIPTOR_HEAP_DESC heapDesc{};
    heapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
    heapDesc.NumDescriptors = count;
    if (FAILED(g_device12->CreateDescriptorHeap(
            &heapDesc, __uuidof(ID3D12DescriptorHeap),
            reinterpret_cast<void**>(&g_rtvHeap12)))) {
        printf("[BedrockClient] could not create the Direct3D 12 render-target descriptor heap.\n");
        fflush(stdout);
        return false;
    }
    g_rtvDescriptorSize12 =
        g_device12->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
    D3D12_CPU_DESCRIPTOR_HANDLE handle = g_rtvHeap12->GetCPUDescriptorHandleForHeapStart();

    for (UINT i = 0; i < count; ++i) {
        if (FAILED(swapChain->GetBuffer(
                i, __uuidof(ID3D12Resource),
                reinterpret_cast<void**>(&g_backBuffers12[i])))) {
            printf("[BedrockClient] could not acquire Direct3D 12 back buffer %u.\n", i);
            fflush(stdout);
            ReleaseD3D12BackBuffers();
            return false;
        }
        g_device12->CreateRenderTargetView(g_backBuffers12[i], nullptr, handle);
        handle.ptr += g_rtvDescriptorSize12;
        if (FAILED(g_device12->CreateCommandAllocator(
                D3D12_COMMAND_LIST_TYPE_DIRECT,
                __uuidof(ID3D12CommandAllocator),
                reinterpret_cast<void**>(&g_frames12[i].allocator)))) {
            printf("[BedrockClient] could not create Direct3D 12 frame allocator %u.\n", i);
            fflush(stdout);
            ReleaseD3D12BackBuffers();
            return false;
        }
    }
    g_bufferCount12 = count;
    g_renderTargetFormat12 = swapDesc.BufferDesc.Format;
    return true;
}

static bool InitializeD3D12Renderer(IDXGISwapChain* swapChain,
                                    const DXGI_SWAP_CHAIN_DESC& swapDesc) {
    if (!g_device12) {
        HRESULT result = swapChain->GetDevice(
            __uuidof(ID3D12Device), reinterpret_cast<void**>(&g_device12));
        if (FAILED(result)) return false;
    }
    if (!InstallD3D12QueueCapture()) return false;

    ID3D12CommandQueue* queue = g_queue12.load(std::memory_order_acquire);
    if (!queue) {
        if (!g_d3d12QueueWaitReported.exchange(true, std::memory_order_acq_rel)) {
            printf("[BedrockClient] Direct3D 12 queue hook is installed; waiting for the game to submit a frame.\n");
            fflush(stdout);
        }
        return false;
    }

    if (!CreateD3D12BackBuffers(swapChain, swapDesc)) {
        ReleaseD3D12Renderer();
        return false;
    }

    D3D12_DESCRIPTOR_HEAP_DESC srvHeapDesc{};
    srvHeapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
    srvHeapDesc.NumDescriptors = 1;
    srvHeapDesc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    HRESULT result = g_device12->CreateDescriptorHeap(
        &srvHeapDesc, __uuidof(ID3D12DescriptorHeap),
        reinterpret_cast<void**>(&g_srvHeap12));
    if (FAILED(result)) {
        printf("[BedrockClient] could not create the Direct3D 12 shader descriptor heap.\n");
        fflush(stdout);
        ReleaseD3D12Renderer();
        return false;
    }
    result = g_device12->CreateCommandList(
        0, D3D12_COMMAND_LIST_TYPE_DIRECT, g_frames12[0].allocator, nullptr,
        __uuidof(ID3D12GraphicsCommandList),
        reinterpret_cast<void**>(&g_commandList12));
    if (FAILED(result)) {
        printf("[BedrockClient] could not create the Direct3D 12 overlay command list.\n");
        fflush(stdout);
        ReleaseD3D12Renderer();
        return false;
    }
    g_commandList12->Close();

    result = g_device12->CreateFence(
        0, D3D12_FENCE_FLAG_NONE, __uuidof(ID3D12Fence),
        reinterpret_cast<void**>(&g_fence12));
    if (FAILED(result)) {
        printf("[BedrockClient] could not create the Direct3D 12 overlay fence.\n");
        fflush(stdout);
        ReleaseD3D12Renderer();
        return false;
    }
    g_fenceEvent12 = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!g_fenceEvent12) {
        printf("[BedrockClient] could not create the Direct3D 12 fence event (%lu).\n",
               GetLastError());
        ReleaseD3D12Renderer();
        return false;
    }

    if (!gui::InitD3D12(
            g_hwnd, g_device12, static_cast<int>(g_bufferCount12),
            g_renderTargetFormat12, g_srvHeap12,
            g_srvHeap12->GetCPUDescriptorHandleForHeapStart(),
            g_srvHeap12->GetGPUDescriptorHandleForHeapStart())) {
        ReleaseD3D12Renderer();
        return false;
    }
    g_usingD3D12.store(true, std::memory_order_release);
    return true;
}

static bool WaitForD3D12Fence(UINT64 value) {
    if (!g_fence12 || !g_fenceEvent12) return false;
    if (g_fence12->GetCompletedValue() >= value) return true;
    HRESULT result = g_fence12->SetEventOnCompletion(value, g_fenceEvent12);
    if (FAILED(result)) return false;
    return WaitForSingleObject(g_fenceEvent12, 2000) == WAIT_OBJECT_0;
}

static void WaitForD3D12QueueIdle() {
    ID3D12CommandQueue* queue = g_queue12.load(std::memory_order_acquire);
    if (!queue || !g_fence12 || !g_fenceEvent12) return;
    UINT64 value = ++g_nextFenceValue12;
    if (SUCCEEDED(queue->Signal(g_fence12, value)))
        WaitForD3D12Fence(value);
}

static void ReleaseD3D12Renderer() {
    WaitForD3D12QueueIdle();
    gui::Shutdown();
    ReleaseD3D12BackBuffers();
    if (g_commandList12) { g_commandList12->Release(); g_commandList12 = nullptr; }
    if (g_srvHeap12) { g_srvHeap12->Release(); g_srvHeap12 = nullptr; }
    if (g_fence12) { g_fence12->Release(); g_fence12 = nullptr; }
    if (g_fenceEvent12) { CloseHandle(g_fenceEvent12); g_fenceEvent12 = nullptr; }
    g_nextFenceValue12 = 0;
    g_frameCursor12 = 0;
    g_usingD3D12.store(false, std::memory_order_release);
}

static void ReleaseD3D12Capture() {
    ID3D12CommandQueue* queue = g_queue12.exchange(nullptr, std::memory_order_acq_rel);
    if (queue) queue->Release();
    if (g_device12) { g_device12->Release(); g_device12 = nullptr; }
}

static bool RenderD3D12(IDXGISwapChain* swapChain) {
    ID3D12CommandQueue* queue = g_queue12.load(std::memory_order_acquire);
    if (!queue || !g_commandList12 || !g_fence12 || !g_bufferCount12)
        return false;

    UINT frameIndex = g_frameCursor12++ % g_bufferCount12;
    IDXGISwapChain3* swapChain3 = nullptr;
    if (SUCCEEDED(swapChain->QueryInterface(
            __uuidof(IDXGISwapChain3), reinterpret_cast<void**>(&swapChain3)))) {
        frameIndex = swapChain3->GetCurrentBackBufferIndex();
        swapChain3->Release();
    }
    if (frameIndex >= g_bufferCount12) return false;

    D3D12Frame& frame = g_frames12[frameIndex];
    if (frame.fenceValue && !WaitForD3D12Fence(frame.fenceValue)) {
        printf("[BedrockClient] timed out waiting for a Direct3D 12 frame allocator.\n");
        fflush(stdout);
        return false;
    }
    if (FAILED(frame.allocator->Reset()) ||
        FAILED(g_commandList12->Reset(frame.allocator, nullptr)))
        return false;

    D3D12_RESOURCE_BARRIER barrier{};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Transition.pResource = g_backBuffers12[frameIndex];
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
    g_commandList12->ResourceBarrier(1, &barrier);

    D3D12_CPU_DESCRIPTOR_HANDLE rtv =
        g_rtvHeap12->GetCPUDescriptorHandleForHeapStart();
    rtv.ptr += static_cast<SIZE_T>(frameIndex) * g_rtvDescriptorSize12;
    g_commandList12->OMSetRenderTargets(1, &rtv, FALSE, nullptr);
    ID3D12DescriptorHeap* heaps[] = {g_srvHeap12};
    g_commandList12->SetDescriptorHeaps(1, heaps);

    gui::RenderD3D12(g_commandList12);

    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_PRESENT;
    g_commandList12->ResourceBarrier(1, &barrier);
    if (FAILED(g_commandList12->Close())) return false;

    ID3D12CommandList* lists[] = {g_commandList12};
    queue->ExecuteCommandLists(1, lists);
    frame.fenceValue = ++g_nextFenceValue12;
    if (FAILED(queue->Signal(g_fence12, frame.fenceValue))) return false;
    return true;
}

static bool ZoomEnabled() {
    return g_zoomActive.load(std::memory_order_acquire);
}

static LRESULT CALLBACK WndProc_h(HWND h, UINT m, WPARAM w, LPARAM l) {
    HookCallGuard guard;
    if (g_shuttingDown.load(std::memory_order_acquire))
        return CallWindowProcW(oWndProc, h, m, w, l);

    if (m == WM_MOUSEWHEEL &&
        g_fovHookAvailable.load(std::memory_order_acquire) && ZoomEnabled()) {
        int delta = GET_WHEEL_DELTA_WPARAM(w);
        float steps = static_cast<float>(delta) / WHEEL_DELTA;
        SetZoomMagnification(GetZoomMagnification() +
            steps * GetZoomScrollStep());
        if (!gui::IsMenuOpen()) return 0;
    }

    if (gui::IsMenuOpen()) {
        ImGui_ImplWin32_WndProcHandler(h, m, w, l);
        ImGui::GetIO().MouseDrawCursor = true;
        switch (m) {
            case WM_MOUSEMOVE:
            case WM_LBUTTONDOWN: case WM_LBUTTONUP:
            case WM_RBUTTONDOWN: case WM_RBUTTONUP:
            case WM_MOUSEWHEEL:
                return 0;
            default: break;
        }
    } else {
        ImGui::GetIO().MouseDrawCursor = false;
        ImGui_ImplWin32_WndProcHandler(h, m, w, l);
    }
    return CallWindowProcW(oWndProc, h, m, w, l);
}

static bool InitImGui() {
    DXGI_SWAP_CHAIN_DESC desc{};
    HRESULT result = g_swap->GetDesc(&desc);
    if (FAILED(result)) {
        if (!g_deviceFailureReported.exchange(true, std::memory_order_acq_rel)) {
            printf("[BedrockClient] swap-chain GetDesc failed (0x%08lX).\n",
                   static_cast<unsigned long>(result));
            fflush(stdout);
        }
        return false;
    }

    HWND swapWindow = desc.OutputWindow;
    DWORD swapWindowPid = 0;
    if (swapWindow) GetWindowThreadProcessId(swapWindow, &swapWindowPid);
    if (!swapWindow || swapWindow != g_hwnd ||
        swapWindowPid != GetCurrentProcessId()) {
        return false;
    }

    result = g_swap->GetDevice(__uuidof(ID3D11Device),
                               reinterpret_cast<void**>(&g_device));
    if (FAILED(result)) {
        ID3D12Device* device12 = nullptr;
        HRESULT d3d12Result = g_swap->GetDevice(
            __uuidof(ID3D12Device), reinterpret_cast<void**>(&device12));
        if (FAILED(d3d12Result) || !device12) {
            if (!g_deviceFailureReported.exchange(true, std::memory_order_acq_rel)) {
                printf("[BedrockClient] Minecraft swap chain is not Direct3D 11 or Direct3D 12 (0x%08lX).\n",
                       static_cast<unsigned long>(result));
                fflush(stdout);
            }
            return false;
        }
        if (!g_device12) g_device12 = device12;
        else device12->Release();
        if (!InstallD3D12QueueCapture()) return false;
        if (!g_queue12.load(std::memory_order_acquire)) return false;
        if (!InitializeD3D12Renderer(g_swap, desc)) return false;
    } else {
        g_device->GetImmediateContext(&g_context);
        g_hwnd = swapWindow;
        if (!CreateRTV()) {
            if (!g_deviceFailureReported.exchange(true, std::memory_order_acq_rel)) {
                printf("[BedrockClient] could not create a render target for the Minecraft swap chain.\n");
                fflush(stdout);
            }
            ReleaseD3DResources();
            return false;
        }
        if (!gui::Init(g_hwnd, g_device, g_context)) {
            ReleaseD3DResources();
            return false;
        }
    }

    SetLastError(ERROR_SUCCESS);
    LONG_PTR previousWndProc = SetWindowLongPtrW(
        g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(WndProc_h));
    if (!previousWndProc && GetLastError() != ERROR_SUCCESS) {
        printf("[BedrockClient] replacing the game window procedure failed (%lu).\n",
               GetLastError());
        gui::Shutdown();
        if (g_usingD3D12.load(std::memory_order_acquire)) {
            ReleaseD3D12Renderer();
        } else {
            ReleaseD3DResources();
        }
        return false;
    }
    oWndProc = reinterpret_cast<WndProc_t>(previousWndProc);
    return true;
}

static HRESULT WINAPI Present_h(IDXGISwapChain* sc, UINT sync, UINT flags) {
    HookCallGuard guard;
    if (g_shuttingDown.load(std::memory_order_acquire))
        return oPresent(sc, sync, flags);

    DXGI_SWAP_CHAIN_DESC desc{};
    if (FAILED(sc->GetDesc(&desc)) || desc.OutputWindow != g_hwnd)
        return oPresent(sc, sync, flags);
    g_presentSeen.store(true, std::memory_order_release);
    g_swap = sc;
    if (!g_imguiReady.load(std::memory_order_acquire) &&
        !g_imguiInitializing.test_and_set(std::memory_order_acquire)) {
        bool initialized = InitImGui();
        if (!initialized && !g_initFailureReported.exchange(true, std::memory_order_acq_rel)) {
            printf("[BedrockClient] overlay initialization failed; retrying on the next game frame.\n");
            fflush(stdout);
        }
        g_imguiReady.store(initialized, std::memory_order_release);
        g_imguiInitializing.clear(std::memory_order_release);
    }
    if (g_imguiReady.load(std::memory_order_acquire)) {
        PollHotkeys();
        auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - g_last).count();
        g_last = now;
        if (dt > 0.25f) dt = 0.25f;
        Mods().Tick(dt);
        gui::NewFrame();
        gui::Render();
        SyncZoomActive();
        Mods().Render();
        ImGui::Render();
        if (g_usingD3D12.load(std::memory_order_acquire)) {
            RenderD3D12(sc);
        } else {
            g_context->OMSetRenderTargets(1, &g_rtv, nullptr);
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        }
    }
    return oPresent(sc, sync, flags);
}

static HRESULT WINAPI ResizeBuffers_h(IDXGISwapChain* sc, UINT n, UINT w, UINT h,
                                      DXGI_FORMAT f, UINT fl) {
    HookCallGuard guard;
    if (g_shuttingDown.load(std::memory_order_acquire))
        return oResizeBuffers(sc, n, w, h, f, fl);

    if (sc != g_swap) return oResizeBuffers(sc, n, w, h, f, fl);
    if (g_usingD3D12.load(std::memory_order_acquire)) {
        WaitForD3D12QueueIdle();
        ReleaseD3D12BackBuffers();
        HRESULT result = oResizeBuffers(sc, n, w, h, f, fl);
        if (SUCCEEDED(result)) {
            DXGI_SWAP_CHAIN_DESC desc{};
            if (SUCCEEDED(sc->GetDesc(&desc)) &&
                !CreateD3D12BackBuffers(sc, desc)) {
                printf("[BedrockClient] failed to recreate Direct3D 12 back buffers after resize.\n");
                fflush(stdout);
            }
        }
        return result;
    }

    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    HRESULT r = oResizeBuffers(sc, n, w, h, f, fl);
    if (g_device && !CreateRTV())
        printf("[BedrockClient] failed to recreate the Direct3D render target after resize.\n");
    return r;
}

bool Install() {
    printf("[BedrockClient] finding the game window...\n");
    fflush(stdout);
    HWND gameWindow = FindGameWindow();
    if (!gameWindow) {
        printf("[BedrockClient] no visible game window was found.\n");
        fflush(stdout);
        return false;
    }
    printf("[BedrockClient] game window found; initializing MinHook...\n");
    fflush(stdout);
    MH_STATUS status = MH_Initialize();
    if (status != MH_OK) {
        printf("[BedrockClient] MH_Initialize failed (%d).\n", static_cast<int>(status));
        fflush(stdout);
        return false;
    }
    bool fovSignatureFound = false;
    MH_STATUS fovHookStatus = MH_OK;
    for (const char* signature : cfg::Sig_GetFov) {
        uintptr_t fovTarget = mem::ScanMainModule(signature);
        if (!fovTarget) continue;

        fovSignatureFound = true;
        fovHookStatus = MH_CreateHook(
            reinterpret_cast<void*>(fovTarget), GetFov_h,
            reinterpret_cast<void**>(&oGetFov));
        if (fovHookStatus == MH_OK) {
            g_fovHookAvailable.store(true, std::memory_order_release);
            printf("[BedrockClient] camera FOV hook created at 0x%llX.\n",
                   static_cast<unsigned long long>(fovTarget));
            break;
        }
    }
    if (!g_fovHookAvailable.load(std::memory_order_acquire)) {
        uintptr_t moduleBase = mem::GetMainModuleBase();
        size_t moduleSize = mem::GetMainModuleSize();
        if (!fovSignatureFound)
            printf("[BedrockClient] no supported camera FOV signature matched (game module 0x%llX, %zu bytes); Zoom is unavailable.\n",
                   static_cast<unsigned long long>(moduleBase), moduleSize);
        else
            printf("[BedrockClient] camera FOV hook creation failed (%d); Zoom is unavailable.\n",
                   static_cast<int>(fovHookStatus));
        fflush(stdout);
    }

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount       = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage       = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow      = gameWindow;
    sd.SampleDesc.Count  = 1;
    sd.Windowed          = TRUE;
    sd.SwapEffect        = DXGI_SWAP_EFFECT_DISCARD;

    ID3D11Device* d = nullptr;
    ID3D11DeviceContext* c = nullptr;
    IDXGISwapChain* s = nullptr;
    D3D_FEATURE_LEVEL fl{};
    printf("[BedrockClient] creating a Direct3D hook target...\n");
    fflush(stdout);
    HRESULT result = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
        D3D11_SDK_VERSION, &sd, &s, &d, &fl, &c);
    if (FAILED(result)) {
        printf("[BedrockClient] Direct3D initialization failed (0x%08lX).\n",
               static_cast<unsigned long>(result));
        fflush(stdout);
        g_fovHookAvailable.store(false, std::memory_order_release);
        MH_Uninitialize();
        return false;
    }

    void** vt = *reinterpret_cast<void***>(s);
    status = MH_CreateHook(vt[8], Present_h, reinterpret_cast<void**>(&oPresent));
    if (status == MH_OK)
        status = MH_CreateHook(vt[13], ResizeBuffers_h,
                               reinterpret_cast<void**>(&oResizeBuffers));
    if (status == MH_OK) status = MH_EnableHook(MH_ALL_HOOKS);
    s->Release(); c->Release(); d->Release();
    if (status != MH_OK) {
        g_fovHookAvailable.store(false, std::memory_order_release);
        printf("[BedrockClient] Direct3D hook setup failed (%d).\n",
               static_cast<int>(status));
        fflush(stdout);
        MH_Uninitialize();
        return false;
    }
    printf("[BedrockClient] Direct3D hooks installed; waiting for the game to render...\n");
    if (g_fovHookAvailable.load(std::memory_order_acquire))
        printf("[BedrockClient] camera FOV hook installed; Zoom wheel control is available.\n");
    fflush(stdout);
    return true;
}

static void PrintUnloadProgress(int percent, const char* step) {
    constexpr int barWidth = 20;
    int filled = percent * barWidth / 100;
    printf("[BedrockClient] [");
    for (int i = 0; i < barWidth; ++i) printf(i < filled ? "#" : "-");
    printf("] %3d%% %s\n", percent, step);
    fflush(stdout);
}

void Uninstall() {
    HWND console = GetConsoleWindow();
    if (console) {
        ShowWindow(console, SW_SHOW);
        SetForegroundWindow(console);
    }
    PrintUnloadProgress(0, "Starting unload");
    g_shuttingDown.store(true, std::memory_order_release);
    MH_STATUS status = MH_DisableHook(MH_ALL_HOOKS);
    if (status != MH_OK && status != MH_ERROR_DISABLED)
        printf("[BedrockClient] disabling hooks returned status %d.\n",
               static_cast<int>(status));
    PrintUnloadProgress(20, "Disabled hooks");
    if (g_hwnd && oWndProc)
        SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(oWndProc));
    PrintUnloadProgress(35, "Restored game window procedure");
    Sleep(50);
    while (g_activeHookCalls.load(std::memory_order_acquire) != 0)
        Sleep(1);
    PrintUnloadProgress(45, "Waited for active callbacks");
    if (g_usingD3D12.load(std::memory_order_acquire))
        ReleaseD3D12Renderer();
    else {
        gui::Shutdown();
        ReleaseD3DResources();
    }
    ReleaseD3D12Capture();
    PrintUnloadProgress(55, "Shut down menu renderer");
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    PrintUnloadProgress(75, "Released render target");
    PrintUnloadProgress(90, "Disabled hooks");
    MH_Uninitialize();
    PrintUnloadProgress(100, "Unload complete");
}

} // namespace hooks
