﻿#pragma once
#include <cstdint>
#include <string>
#include <vector>

struct Vec2 { float x, y; };

struct Vec3 {
    float x, y, z;
    Vec3 operator+(const Vec3& o) const { return {x + o.x, y + o.y, z + o.z}; }
    Vec3 operator-(const Vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    Vec3 operator*(float s) const { return {x * s, y * s, z * s}; }
    float length() const;
    Vec3 normalized() const;
};

struct AABB { Vec3 min, max; };

namespace sdk {

using Actor  = uintptr_t;
using Player = uintptr_t;
using Level  = uintptr_t;

uintptr_t GetClientInstance();
Player    GetLocalPlayer();
Level     GetLevel();
uintptr_t GetGameMode();

Vec3  GetPosition(Actor a);
void  SetPosition(Actor a, const Vec3& p);
Vec3  GetVelocity(Actor a);
void  SetVelocity(Actor a, const Vec3& v);
bool  IsOnGround(Actor a);
void  SetOnGround(Actor a, bool v);
bool  IsSprinting(Actor a);
void  SetSprinting(Actor a, bool v);
bool  IsDead(Actor a);
std::string GetNameTag(Actor a);
AABB  GetAABB(Actor a, Vec3* position = nullptr);
bool  IsLocalPlayer(Actor a);

std::vector<Actor> GetEntities(size_t maxCount = 8192);
Vec2  GetRotation(Player p);
Vec3  GetEyePosition(Player p);

void Attack(Actor target);
void DestroyBlock(const Vec3& blockCenter);

void Dump();

} // namespace sdk
