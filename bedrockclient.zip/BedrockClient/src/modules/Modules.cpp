﻿#include "Modules.hpp"
#include "Config.hpp"
#include "Hooks.hpp"
#include "Memory.hpp"
#include "Module.hpp"
#include "SDK.hpp"

#include <imgui.h>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <algorithm>

#if 0
namespace {

struct Fly : Module {
    float speed = cfg::FlySpeed;
    Fly() : Module("Fly", "Hover, Space to rise, Shift to descend", 'F') {}
    void DrawSettings() override { ImGui::SliderFloat("Speed##fly", &speed, 0.2f, 8.0f, "%.2f"); }
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        Vec3 v = sdk::GetVelocity(lp);
        v.y = 0.0f;
        if (GetAsyncKeyState(VK_SPACE) & 0x8000) v.y =  speed;
        if (GetAsyncKeyState(VK_SHIFT) & 0x8000) v.y = -speed;
        sdk::SetVelocity(lp, v);
        sdk::SetOnGround(lp, false);
    }
};

struct Speed : Module {
    float value = cfg::SpeedValue;
    Speed() : Module("Speed", "Scales horizontal velocity to a fixed value", 'G') {}
    void DrawSettings() override { ImGui::SliderFloat("Speed##spd", &value, 0.5f, 6.0f, "%.2f"); }
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        Vec3 v = sdk::GetVelocity(lp);
        float h = std::sqrt(v.x * v.x + v.z * v.z);
        if (h < 1e-3f) return;
        v.x = v.x / h * value;
        v.z = v.z / h * value;
        sdk::SetVelocity(lp, v);
    }
};

struct AutoSprint : Module {
    AutoSprint() : Module("AutoSprint", "Keeps the sprint flag set", 'V') {}
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (lp) sdk::SetSprinting(lp, true);
    }
};

struct NoFall : Module {
    NoFall() : Module("NoFall", "Cancels fall damage by grounding mid-air", 'N') {}
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        if (sdk::GetVelocity(lp).y < -0.1f) sdk::SetOnGround(lp, true);
    }
};

struct FullBright : Module {
    float gamma = 5.0f;
    FullBright() : Module("FullBright", "Writes a high gamma into game options", 'B') {}
    void DrawSettings() override { ImGui::SliderFloat("Gamma##fb", &gamma, 1.0f, 15.0f, "%.1f"); }
    void Tick(float) override {
        uintptr_t ci = sdk::GetClientInstance();
        if (!ci) return;
        uintptr_t mg = mem::Read<uintptr_t>(ci + cfg::CI_MinecraftGame);
        if (!mg) return;
        uintptr_t opt = mem::Read<uintptr_t>(mg + cfg::MG_Options);
        if (!opt) return;
        mem::Write(opt + cfg::OPT_Gamma, gamma);
    }
};

struct ESP : Module {
    bool players = true;
    bool mobs    = true;
    float col[3] = {0.15f, 1.0f, 0.4f};
    ESP() : Module("ESP", "Wall-through boxes, nametags and distance", 'X') {}
    void DrawSettings() override {
        ImGui::Checkbox("Players##esp", &players);
        ImGui::SameLine();
        ImGui::Checkbox("Mobs##esp", &mobs);
        ImGui::ColorEdit3("Box##esp", col, ImGuiColorEditFlags_NoInputs);
    }
    static bool WorldToScreen(const Vec3& w, const Vec3& eye, const Vec2& rot,
                              const ImVec2& disp, ImVec2& out);
    void Render() override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        Vec2 rot = sdk::GetRotation(lp);
        Vec3 eye = sdk::GetEyePosition(lp);
        ImVec2 disp = ImGui::GetIO().DisplaySize;
        ImDrawList* dl = ImGui::GetForegroundDrawList();
        ImU32 color = ImGui::ColorConvertFloat4ToU32({col[0], col[1], col[2], 1.0f});

        for (auto e : sdk::GetEntities()) {
            if (e == lp || sdk::IsDead(e)) continue;
            bool isPlayer = (mem::Read<int>(e + cfg::AC_TypeId) == cfg::PlayerTypeId);
            if (isPlayer && !players) continue;
            if (!isPlayer && !mobs)   continue;

            AABB box = sdk::GetAABB(e);
            Vec3 corners[8] = {
                {box.min.x, box.min.y, box.min.z}, {box.max.x, box.min.y, box.min.z},
                {box.min.x, box.max.y, box.min.z}, {box.max.x, box.max.y, box.min.z},
                {box.min.x, box.min.y, box.max.z}, {box.max.x, box.min.y, box.max.z},
                {box.min.x, box.max.y, box.max.z}, {box.max.x, box.max.y, box.max.z},
            };
            ImVec2 pts[8];
            bool visible = true;
            for (int i = 0; i < 8; ++i) {
                if (!WorldToScreen(corners[i], eye, rot, disp, pts[i])) { visible = false; break; }
            }
            if (!visible) continue;

            float minX = pts[0].x, maxX = pts[0].x, minY = pts[0].y, maxY = pts[0].y;
            for (auto& p : pts) {
                minX = std::min(minX, p.x); maxX = std::max(maxX, p.x);
                minY = std::min(minY, p.y); maxY = std::max(maxY, p.y);
            }
            dl->AddRect({minX, minY}, {maxX, maxY}, color, 0.0f, 0, 1.6f);

            Vec3 pos = sdk::GetPosition(e);
            float dist = (pos - eye).length();
            std::string nm = sdk::GetNameTag(e);
            char label[128];
            snprintf(label, sizeof(label), "%s [%.1fm]", nm.empty() ? "?" : nm.c_str(), dist);
            dl->AddText({minX, minY - 15.0f}, color, label);
        }
    }
};

struct KillAura : Module {
    float range = cfg::AuraRange;
    float cps   = cfg::AuraCPS;
    std::chrono::steady_clock::time_point last{};
    KillAura() : Module("KillAura", "Attacks the nearest entity in range", 'R') {}
    void DrawSettings() override {
        ImGui::SliderFloat("Range##ka", &range, 2.0f, 8.0f, "%.1f");
        ImGui::SliderFloat("CPS##ka",   &cps,   1.0f, 20.0f, "%.0f");
    }
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration<float>(now - last).count() < 1.0f / cps) return;
        Vec3 eye = sdk::GetEyePosition(lp);
        uintptr_t best = 0;
        float bestDist = range;
        for (auto e : sdk::GetEntities()) {
            if (e == lp || sdk::IsDead(e)) continue;
            float d = (sdk::GetPosition(e) - eye).length();
            if (d < bestDist) { bestDist = d; best = e; }
        }
        if (best) { sdk::Attack(best); last = now; }
    }
};

struct Nuker : Module {
    float range = cfg::NukerRange;
    Nuker() : Module("Nuker", "Destroys blocks in a radius around you", 'K') {}
    void DrawSettings() override { ImGui::SliderFloat("Range##nk", &range, 1.0f, 8.0f, "%.1f"); }
    void Tick(float) override {
        auto lp = sdk::GetLocalPlayer();
        if (!lp) return;
        Vec3 p = sdk::GetPosition(lp);
        int rad = static_cast<int>(range);
        int sent = 0;
        for (int dx = -rad; dx <= rad && sent < cfg::NukerPerFrame; ++dx)
        for (int dy = -rad; dy <= rad && sent < cfg::NukerPerFrame; ++dy)
        for (int dz = -rad; dz <= rad && sent < cfg::NukerPerFrame; ++dz) {
            Vec3 c{std::floor(p.x) + dx + 0.5f,
                   std::floor(p.y) + dy + 0.5f,
                   std::floor(p.z) + dz + 0.5f};
            if ((c - p).length() > range) continue;
            sdk::DestroyBlock(c);
            ++sent;
        }
    }
};

} // namespace

static void MulMat(const float A[16], const float B[16], float C[16]) {
    for (int i = 0; i < 4; ++i)
        for (int j = 0; j < 4; ++j) {
            float s = 0.0f;
            for (int k = 0; k < 4; ++k) s += A[i * 4 + k] * B[k * 4 + j];
            C[i * 4 + j] = s;
        }
}

static void LookAt(const Vec3& eye, const Vec3& f, float M[16]) {
    Vec3 F = f.normalized();
    Vec3 up{0, 1, 0};
    Vec3 S{F.y * up.z - F.z * up.y, F.z * up.x - F.x * up.z, F.x * up.y - F.y * up.x};
    S = S.normalized();
    Vec3 U{S.y * F.z - S.z * F.y, S.z * F.x - S.x * F.z, S.x * F.y - S.y * F.x};
    M[0] = S.x;  M[1] = S.y;  M[2] = S.z;  M[3] = -(S.x * eye.x + S.y * eye.y + S.z * eye.z);
    M[4] = U.x;  M[5] = U.y;  M[6] = U.z;  M[7] = -(U.x * eye.x + U.y * eye.y + U.z * eye.z);
    M[8] = -F.x; M[9] = -F.y; M[10] = -F.z; M[11] = (F.x * eye.x + F.y * eye.y + F.z * eye.z);
    M[12] = 0;   M[13] = 0;   M[14] = 0;   M[15] = 1;
}

static void Perspective(float fovDeg, float aspect, float n, float f, float M[16]) {
    constexpr float PI = 3.14159265f;
    float h = 1.0f / std::tan(fovDeg * 0.5f * PI / 180.0f);
    float w = h / aspect;
    M[0] = w;  M[1] = 0;  M[2] = 0;             M[3] = 0;
    M[4] = 0;  M[5] = h;  M[6] = 0;             M[7] = 0;
    M[8] = 0;  M[9] = 0;  M[10] = f / (n - f);  M[11] = n * f / (n - f);
    M[12] = 0; M[13] = 0; M[14] = -1;           M[15] = 0;
}

bool ESP::WorldToScreen(const Vec3& w, const Vec3& eye, const Vec2& rot,
                        const ImVec2& disp, ImVec2& out) {
    constexpr float PI = 3.14159265f;
    float yaw   = rot.x * PI / 180.0f;
    float pitch = rot.y * PI / 180.0f;
    Vec3 fwd{-std::sin(yaw) * std::cos(pitch),
             -std::sin(pitch),
              std::cos(yaw) * std::cos(pitch)};
    float V[16], P[16], VP[16];
    LookAt(eye, fwd, V);
    Perspective(70.0f, disp.x / disp.y, 0.05f, 1000.0f, P);
    MulMat(P, V, VP);

    float x  = VP[0] * w.x + VP[1] * w.y + VP[2]  * w.z + VP[3];
    float y  = VP[4] * w.x + VP[5] * w.y + VP[6]  * w.z + VP[7];
    float wc = VP[12] * w.x + VP[13] * w.y + VP[14] * w.z + VP[15];
    if (wc < 0.001f) return false;
    out.x = ((x / wc) * 0.5f + 0.5f) * disp.x;
    out.y = (0.5f - (y / wc) * 0.5f) * disp.y;
    return true;
}

#endif
namespace {

struct CameraProjection {
    Vec3 eye;
    float sinYaw;
    float cosYaw;
    float sinPitch;
    float cosPitch;
    float focal;
    ImVec2 display;

    CameraProjection(const Vec3& cameraEye, const Vec2& rotation,
                     float fovDegrees, const ImVec2& screen)
        : eye(cameraEye),
          sinYaw(std::sin(rotation.x * 0.017453292519943295f)),
          cosYaw(std::cos(rotation.x * 0.017453292519943295f)),
          sinPitch(std::sin(rotation.y * 0.017453292519943295f)),
          cosPitch(std::cos(rotation.y * 0.017453292519943295f)),
          focal(screen.y * 0.5f /
                std::tan(fovDegrees * 0.008726646259971648f)),
          display(screen) {}

    Vec3 ToCamera(const Vec3& point) const {
        Vec3 delta = point - eye;
        float forwardX = -sinYaw * cosPitch;
        float forwardY = -sinPitch;
        float forwardZ = cosYaw * cosPitch;
        return {
            cosYaw * delta.x + sinYaw * delta.z,
            -sinPitch * sinYaw * delta.x + cosPitch * delta.y +
                sinPitch * cosYaw * delta.z,
            forwardX * delta.x + forwardY * delta.y + forwardZ * delta.z
        };
    }

    bool ProjectCameraPoint(const Vec3& point, ImVec2& screen) const {
        if (point.z < 0.05f) return false;
        screen.x = display.x * 0.5f + focal * point.x / point.z;
        screen.y = display.y * 0.5f - focal * point.y / point.z;
        return std::isfinite(screen.x) && std::isfinite(screen.y);
    }

    bool DrawSegment(ImDrawList* drawList, const Vec3& start, const Vec3& end,
                     ImU32 color, float thickness) const {
        return DrawCameraSegment(drawList, ToCamera(start), ToCamera(end),
                                 color, thickness);
    }

    bool DrawCameraSegment(ImDrawList* drawList, Vec3 a, Vec3 b,
                           ImU32 color, float thickness) const {
        constexpr float nearPlane = 0.05f;
        if (a.z < nearPlane && b.z < nearPlane) return false;
        if (a.z < nearPlane || b.z < nearPlane) {
            float t = (nearPlane - a.z) / (b.z - a.z);
            Vec3 clipped = a + (b - a) * t;
            if (a.z < nearPlane) a = clipped;
            else b = clipped;
        }

        ImVec2 screenA, screenB;
        if (!ProjectCameraPoint(a, screenA) || !ProjectCameraPoint(b, screenB))
            return false;
        drawList->AddLine(screenA, screenB, color, thickness);
        return true;
    }
};

static bool DrawAabb(ImDrawList* drawList, const CameraProjection& camera,
                     const AABB& box, ImU32 color) {
    const Vec3 worldCorners[8] = {
        {box.min.x, box.min.y, box.min.z}, {box.max.x, box.min.y, box.min.z},
        {box.min.x, box.max.y, box.min.z}, {box.max.x, box.max.y, box.min.z},
        {box.min.x, box.min.y, box.max.z}, {box.max.x, box.min.y, box.max.z},
        {box.min.x, box.max.y, box.max.z}, {box.max.x, box.max.y, box.max.z}
    };
    Vec3 corners[8];
    for (int i = 0; i < 8; ++i)
        corners[i] = camera.ToCamera(worldCorners[i]);
    constexpr int edges[12][2] = {
        {0, 1}, {0, 2}, {0, 4}, {1, 3}, {1, 5}, {2, 3},
        {2, 6}, {3, 7}, {4, 5}, {4, 6}, {5, 7}, {6, 7}
    };
    bool drawn = false;
    for (const auto& edge : edges)
        drawn = camera.DrawCameraSegment(drawList, corners[edge[0]],
                                          corners[edge[1]], color, 1.5f) || drawn;
    return drawn;
}

struct ZoomModule : Module {
    ZoomModule()
        : Module("Zoom", "Changes the game camera FOV; scroll while enabled", 'Z') {}

    void DrawSettings() override {
        if (!hooks::IsZoomAvailable()) {
            ImGui::TextColored({1.0f, 0.55f, 0.3f, 1.0f},
                               "Camera FOV hook unavailable; check startup log.");
        } else if (hooks::GetFovHookCallCount() == 0) {
            ImGui::TextColored({1.0f, 0.75f, 0.3f, 1.0f},
                               "FOV hook installed; waiting for its first call.");
        } else {
            ImGui::Text("FOV hook calls: %llu | camera FOV: %.1f degrees",
                        hooks::GetFovHookCallCount(), hooks::GetLastZoomFov());
        }

        float magnification = hooks::GetZoomMagnification();
        if (ImGui::SliderFloat("Magnification##zoom", &magnification, 1.0f, 16.0f, "%.1fx"))
            hooks::SetZoomMagnification(magnification);

        float scrollStep = hooks::GetZoomScrollStep();
        if (ImGui::SliderFloat("Wheel step##zoom", &scrollStep, 0.1f, 4.0f, "%.1fx"))
            hooks::SetZoomScrollStep(scrollStep);
        if (hooks::IsZoomAvailable())
            ImGui::TextDisabled("Scroll to change magnification; menu may stay open.");
    }
};

struct HitboxesModule : Module {
    static constexpr size_t MaxScannedEntities = 256;
    static constexpr size_t MaxDrawnEntities = 64;

    struct EntitySnapshot {
        AABB box;
        Vec2 rotation{};
        bool hasRotation = false;
        float distanceSquared = 0.0f;
    };

    bool players = true;
    bool mobs = true;
    bool includeSelf = true;
    bool showBoxes = true;
    bool showLookDirection = true;
    float lineLength = 10.0f;
    float boxColor[3] = {1.0f, 1.0f, 1.0f};
    float lookColor[3] = {0.2f, 0.45f, 1.0f};
    std::vector<EntitySnapshot> nearbyEntities;
    std::chrono::steady_clock::time_point lastSample{};
    std::chrono::steady_clock::time_point nextLocalPlayerCheck{};
    std::chrono::microseconds lastSampleDuration{0};
    std::chrono::microseconds lastRenderDuration{0};
    sdk::Player cachedLocalPlayer = 0;
    bool hasCheckedLocalPlayer = false;
    sdk::Player sampledLocalPlayer = 0;
    bool sampledPlayers = true;
    bool sampledMobs = true;
    bool sampledIncludeSelf = true;
    bool sampledLookDirection = true;
    size_t scannedEntities = 0;
    size_t boxesProjected = 0;
    size_t lookLinesProjected = 0;
    size_t outOfRangeEntities = 0;
    size_t invalidPositionEntities = 0;

    HitboxesModule()
        : Module("Hitboxes", "Shows entity hitbox outlines and look direction") {}

    void DrawSettings() override {
        ImGui::Checkbox("Players##hitboxes", &players);
        ImGui::SameLine();
        ImGui::Checkbox("Mobs / projectiles##hitboxes", &mobs);
        ImGui::Checkbox("My player##hitboxes", &includeSelf);
        ImGui::Checkbox("Hitbox outlines##hitboxes", &showBoxes);
        ImGui::Checkbox("Look direction##hitboxes", &showLookDirection);
        if (showLookDirection)
            ImGui::SliderFloat("Look line length##hitboxes", &lineLength,
                               1.0f, 50.0f, "%.0f blocks");
        if (showBoxes)
            ImGui::ColorEdit3("Hitbox color##hitboxes", boxColor,
                              ImGuiColorEditFlags_NoInputs);
        if (showLookDirection)
            ImGui::ColorEdit3("Look direction color##hitboxes", lookColor,
                              ImGuiColorEditFlags_NoInputs);
        ImGui::Text("Actors: %zu%s | nearby: %zu | boxes: %zu | lines: %zu",
                    scannedEntities,
                    scannedEntities >= MaxScannedEntities ? "+" : "",
                    nearbyEntities.size(), boxesProjected, lookLinesProjected);
        ImGui::Text("Scan: %lld us | render: %lld us | range rejected: %zu | invalid: %zu",
                    static_cast<long long>(lastSampleDuration.count()),
                    static_cast<long long>(lastRenderDuration.count()),
                    outOfRangeEntities, invalidPositionEntities);
        if (hasCheckedLocalPlayer && !cachedLocalPlayer)
            ImGui::TextColored({1.0f, 0.55f, 0.3f, 1.0f},
                               "Game client pointer unresolved; this build cannot read Hitboxes.");
        ImGui::TextDisabled("Look lines are blue by default.");
    }

    void Render() override {
        if ((!showBoxes && !showLookDirection) ||
            (!players && !mobs && !includeSelf))
            return;

        auto now = std::chrono::steady_clock::now();
        if (now >= nextLocalPlayerCheck) {
            sdk::Player currentLocalPlayer = sdk::GetLocalPlayer();
            if (currentLocalPlayer != cachedLocalPlayer) {
                cachedLocalPlayer = currentLocalPlayer;
                lastSample = {};
            }
            hasCheckedLocalPlayer = true;
            nextLocalPlayerCheck = now + std::chrono::milliseconds(500);
        }
        auto localPlayer = cachedLocalPlayer;
        if (!localPlayer) {
            nearbyEntities.clear();
            scannedEntities = 0;
            boxesProjected = 0;
            lookLinesProjected = 0;
            lastRenderDuration = std::chrono::microseconds(0);
            return;
        }

        auto sampleInterval = std::max(std::chrono::milliseconds(1000),
                                       std::chrono::duration_cast<std::chrono::milliseconds>(
                                           lastSampleDuration * 4));
        bool refresh = localPlayer != sampledLocalPlayer ||
                       players != sampledPlayers || mobs != sampledMobs ||
                       includeSelf != sampledIncludeSelf ||
                       showLookDirection != sampledLookDirection ||
                       now - lastSample >= sampleInterval;
        if (refresh) {
            auto sampleStart = std::chrono::steady_clock::now();
            nearbyEntities.clear();
            outOfRangeEntities = 0;
            invalidPositionEntities = 0;
            Vec3 localPosition = sdk::GetPosition(localPlayer);
            auto entities = sdk::GetEntities(MaxScannedEntities);
            scannedEntities = entities.size();
            if (includeSelf && players) {
                Vec3 position;
                AABB box = sdk::GetAABB(localPlayer, &position);
                EntitySnapshot snapshot{box, {}, false, 0.0f};
                if (showLookDirection) {
                    snapshot.rotation = sdk::GetRotation(localPlayer);
                    snapshot.hasRotation = true;
                }
                nearbyEntities.push_back(snapshot);
            }
            for (auto entity : entities) {
                if (entity == localPlayer) continue;
                bool isPlayer =
                    mem::Read<int>(entity + cfg::AC_TypeId) == cfg::PlayerTypeId;
                if ((isPlayer && !players) || (!isPlayer && !mobs)) continue;

                Vec3 position;
                AABB box = sdk::GetAABB(entity, &position);
                if (!std::isfinite(position.x) || !std::isfinite(position.y) ||
                    !std::isfinite(position.z)) {
                    ++invalidPositionEntities;
                    continue;
                }
                Vec3 offset = position - localPosition;
                float distanceSquared = offset.x * offset.x +
                                        offset.y * offset.y +
                                        offset.z * offset.z;
                if (!std::isfinite(distanceSquared) ||
                    distanceSquared > 900.0f) {
                    ++outOfRangeEntities;
                    continue;
                }
                if (!std::isfinite(box.min.x) || !std::isfinite(box.max.x) ||
                    !std::isfinite(box.min.y) || !std::isfinite(box.max.y) ||
                    !std::isfinite(box.min.z) || !std::isfinite(box.max.z) ||
                    box.max.x <= box.min.x || box.max.y <= box.min.y ||
                    box.max.z <= box.min.z)
                    continue;

                EntitySnapshot snapshot{box, {}, false, distanceSquared};
                if (showLookDirection) {
                    snapshot.rotation = sdk::GetRotation(entity);
                    snapshot.hasRotation = true;
                }
                nearbyEntities.push_back(snapshot);
            }
            if (nearbyEntities.size() > MaxDrawnEntities) {
                std::partial_sort(
                    nearbyEntities.begin(),
                    nearbyEntities.begin() + MaxDrawnEntities,
                    nearbyEntities.end(),
                    [](const EntitySnapshot& a, const EntitySnapshot& b) {
                        return a.distanceSquared < b.distanceSquared;
                    });
                nearbyEntities.resize(MaxDrawnEntities);
            }
            sampledLocalPlayer = localPlayer;
            sampledPlayers = players;
            sampledMobs = mobs;
            sampledIncludeSelf = includeSelf;
            sampledLookDirection = showLookDirection;
            lastSample = std::chrono::steady_clock::now();
            lastSampleDuration =
                std::chrono::duration_cast<std::chrono::microseconds>(
                    lastSample - sampleStart);
        }

        auto renderStart = std::chrono::steady_clock::now();
        ImVec2 display = ImGui::GetIO().DisplaySize;
        if (display.x <= 0.0f || display.y <= 0.0f) return;
        float fov = hooks::GetLastZoomFov();
        if (!std::isfinite(fov) || fov <= 1.0f || fov >= 179.0f)
            fov = 70.0f;

        CameraProjection camera(sdk::GetEyePosition(localPlayer),
                                sdk::GetRotation(localPlayer), fov, display);
        boxesProjected = 0;
        lookLinesProjected = 0;
        ImDrawList* drawList = ImGui::GetForegroundDrawList();
        ImU32 boxes = ImGui::ColorConvertFloat4ToU32(
            {boxColor[0], boxColor[1], boxColor[2], 1.0f});
        ImU32 look = ImGui::ColorConvertFloat4ToU32(
            {lookColor[0], lookColor[1], lookColor[2], 1.0f});

        for (const auto& entity : nearbyEntities) {
            if (showBoxes && DrawAabb(drawList, camera, entity.box, boxes))
                ++boxesProjected;

            if (showLookDirection && entity.hasRotation) {
                Vec2 rotation = entity.rotation;
                float yaw = rotation.x * 0.017453292519943295f;
                float pitch = rotation.y * 0.017453292519943295f;
                float eyeHeight = entity.box.min.y +
                                  (entity.box.max.y - entity.box.min.y) * 0.85f;
                Vec3 eye{(entity.box.min.x + entity.box.max.x) * 0.5f,
                         eyeHeight,
                         (entity.box.min.z + entity.box.max.z) * 0.5f};
                float cosPitch = std::cos(pitch);
                Vec3 end = eye + Vec3{
                    -std::sin(yaw) * cosPitch,
                    -std::sin(pitch),
                    std::cos(yaw) * cosPitch
                } * lineLength;
                if (camera.DrawSegment(drawList, eye, end, look, 2.0f))
                    ++lookLinesProjected;
            }
        }
        lastRenderDuration =
            std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::steady_clock::now() - renderStart);
    }
};

}

void RegisterModules() {
    Mods().Add(new ZoomModule());
    Mods().Add(new HitboxesModule());
    Mods().Add(new Module("Fly", "Removed; placeholder only"));
    Mods().Add(new Module("Speed", "Removed; placeholder only"));
    Mods().Add(new Module("AutoSprint", "Removed; placeholder only"));
    Mods().Add(new Module("NoFall", "Removed; placeholder only"));
    Mods().Add(new Module("FullBright", "Removed; placeholder only"));
    Mods().Add(new Module("KillAura", "Removed; placeholder only"));
    Mods().Add(new Module("Nuker", "Removed; placeholder only"));
}
