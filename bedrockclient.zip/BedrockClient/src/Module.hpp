﻿#pragma once
#include <vector>

struct Module {
    const char* name;
    const char* desc;
    int  key = 0;
    bool enabled = false;

    Module(const char* n, const char* d, int k = 0) : name(n), desc(d), key(k) {}
    virtual ~Module() = default;

    void Toggle() { enabled = !enabled; }
    virtual void Tick(float dt) {}
    virtual void Render() {}
    virtual void DrawSettings() {}
};

class ModuleManager {
public:
    void Add(Module* m) { mods_.push_back(m); }
    void Tick(float dt);
    void Render();
    void HandleKey(int vk);
    std::vector<Module*>& All() { return mods_; }
    float accent[3] = {0.35f, 0.75f, 1.0f};
private:
    std::vector<Module*> mods_;
};

ModuleManager& Mods();
