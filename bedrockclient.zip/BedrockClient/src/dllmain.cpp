﻿#include <windows.h>
#include <conio.h>
#include <cstdio>
#include <iterator>

#include "Config.hpp"
#include "Hooks.hpp"
#include "Module.hpp"
#include "SDK.hpp"
#include "modules/Modules.hpp"

static HMODULE g_self   = nullptr;
static bool    g_unload = false;
static constexpr wchar_t kInjectedWindowTitle[] =
    L"BedrockClient [Minecraft Bedrock]v1.0";

static void OpenConsole() {
    AllocConsole();
    FILE* f = nullptr;
    freopen_s(&f, "CONIN$", "r", stdin);
    freopen_s(&f, "CONOUT$", "w", stdout);
    freopen_s(&f, "CONOUT$", "w", stderr);
    SetConsoleTitleW(L"BedrockClient");
}

static void PrintModuleList() {
    printf("\n[BedrockClient] Modules\n");
    for (auto* module : Mods().All()) {
        printf("  %-18s [%c] %s\n", module->name,
               module->key ? static_cast<char>(module->key) : '-',
               module->enabled ? "ON" : "OFF");
    }
    printf("\n");
}

static char ToUpperAscii(char character) {
    return character >= 'a' && character <= 'z'
        ? static_cast<char>(character - 'a' + 'A')
        : character;
}

static bool ModuleNameMatches(const char* command, const char* name) {
    int index = 0;
    while (command[index] && name[index] &&
           ToUpperAscii(command[index]) == ToUpperAscii(name[index]))
        ++index;
    return command[index] == '\0' && name[index] == '\0';
}

static bool ToggleModuleCommand(const char* command, int commandLength) {
    for (auto* module : Mods().All()) {
        bool keyMatches = commandLength == 1 && module->key &&
                          ToUpperAscii(command[0]) == module->key;
        if (keyMatches || ModuleNameMatches(command, module->name)) {
            module->Toggle();
            printf("%s: %s\n", module->name, module->enabled ? "ON" : "OFF");
            return true;
        }
    }
    return false;
}

static DWORD WINAPI Main(LPVOID) {
    OpenConsole();
    printf("[BedrockClient] DLL loaded; initializing inside the current game process...\n");
    fflush(stdout);
    RegisterModules();
    HWND gameWindow = hooks::FindGameWindow();
    if (!gameWindow) {
        printf("[BedrockClient] no visible Minecraft window was found.\n");
        fflush(stdout);
        return 0;
    }
    hooks::g_hwnd = gameWindow;

    if (!hooks::Install()) {
        printf("[BedrockClient] hook install failed.\n");
        fflush(stdout);
        return 0;
    }

    ULONGLONG renderDeadline = GetTickCount64() + 10000;
    while (!hooks::g_imguiReady.load(std::memory_order_acquire) &&
           !g_unload && GetTickCount64() < renderDeadline) {
        if (GetAsyncKeyState(cfg::KEY_UNLOAD) & 0x8000) g_unload = true;
        Sleep(50);
    }

    wchar_t originalWindowTitle[256]{};
    bool windowTitleChanged = false;
    if (hooks::g_imguiReady.load(std::memory_order_acquire)) {
        GetWindowTextW(gameWindow, originalWindowTitle,
                       static_cast<int>(std::size(originalWindowTitle)));
        windowTitleChanged = SetWindowTextW(gameWindow, kInjectedWindowTitle) != FALSE;
        if (windowTitleChanged) {
            printf("[BedrockClient] game window title updated.\n");
        } else {
            printf("[BedrockClient] setting the game window title failed (%lu).\n",
                   GetLastError());
        }
        printf("[BedrockClient] rendering hook is active.\n");
    } else if (!g_unload && !hooks::g_presentSeen.load(std::memory_order_acquire)) {
        printf("[BedrockClient] timed out: Minecraft did not call the Direct3D Present hook.\n");
        printf("[BedrockClient] the DLL loaded, but the rendering hook is not active.\n");
    } else if (!g_unload) {
        printf("[BedrockClient] timed out: Present was called, but the overlay could not initialize; see the diagnostic above.\n");
        printf("[BedrockClient] the DLL loaded, but the rendering hook is not active.\n");
    }

    printf("  M in Minecraft = toggle panel\n");
    printf("  Type M here = list modules\n");
    printf("  Type D here = dump game pointers\n");
    printf("  Type a module name here to toggle it\n");
    printf("  Z in Minecraft = Zoom\n");
    printf("  DELETE = eject\n");
    printf("> ");
    fflush(stdout);
    char command[32]{};
    int commandLength = 0;

    while (!g_unload) {
        if (_kbhit()) {
            int keyStroke = _getch();
            if (keyStroke == 0 || keyStroke == 0xE0) {
                if (_kbhit()) _getch();
            } else if (keyStroke == '\r') {
                command[commandLength] = '\0';
                printf("\n");
                if (commandLength == 1 &&
                    (command[0] == 'm' || command[0] == 'M')) {
                    PrintModuleList();
                } else if (commandLength == 1 &&
                           (command[0] == 'd' || command[0] == 'D')) {
                    sdk::Dump();
                } else if (commandLength > 0 &&
                           ToggleModuleCommand(command, commandLength)) {
                } else if (commandLength > 0) {
                    printf("Unknown command. Use M, D, or a module name/hotkey.\n");
                }
                commandLength = 0;
                printf("> ");
                fflush(stdout);
            } else if (keyStroke == '\b' && commandLength > 0) {
                --commandLength;
                printf("\b \b");
                fflush(stdout);
            } else if (keyStroke >= 32 && keyStroke <= 126 &&
                       commandLength < static_cast<int>(sizeof(command)) - 1) {
                command[commandLength++] = static_cast<char>(keyStroke);
                putchar(keyStroke);
                fflush(stdout);
            }
        }
        if (GetAsyncKeyState(cfg::KEY_UNLOAD) & 0x8000) g_unload = true;
        Sleep(50);
    }

    if (windowTitleChanged && IsWindow(gameWindow))
        SetWindowTextW(gameWindow, originalWindowTitle);
    hooks::Uninstall();
    printf("[BedrockClient] unhooked, ejecting.\n");
    Sleep(400);
    FreeLibraryAndExitThread(g_self, 0);
    return 0;
}

extern "C" BOOL WINAPI DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h;
        DisableThreadLibraryCalls(h);
        CreateThread(nullptr, 0, Main, nullptr, 0, nullptr);
    }
    return TRUE;
}
